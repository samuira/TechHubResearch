from webservice.views.all_import import *
from rest_framework.parsers import JSONParser, FormParser, MultiPartParser
from rest_framework.renderers import JSONRenderer, BrowsableAPIRenderer, MultiPartRenderer, HTMLFormRenderer
from rest_framework import generics
from kpi import kissmetrics
from django.views.decorators.clickjacking import xframe_options_exempt
from django.shortcuts import render



class GetVisitingDemography(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetVisitingDemographySerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.visiting_demography()
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get kissmetrics visiting demography"
            responseSuccess.append({"type": "Get kissmetrics visiting demography", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetTopNvisitDemography(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetTopNvisitDemographySerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.top_n_visit_demography(5)
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get kissmetrics top n visit demography"
            responseSuccess.append({"type": "Get kissmetrics top n visit demography", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetAverageSessionLength(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetAverageSessionLengthSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.average_session_length(aggregation='Location')
        # print("############# data #################")
        # print(status, )
        if status:
            data1 = data.replace("\\", "")
            data2 = data1.replace('0096', '–')
            translatedText = data2.replace('00', '')
            responseData = json.loads(translatedText)
            # print(type(responseData))
            mobileMsg = "Get kissmetrics average session length"
            responseSuccess.append({"type": "Get kissmetrics average session length", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetMostPopularPages(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetMostPopularPagesSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.most_popular_pages(page='EntryPage', aggregation='average')
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get most popular pages"
            responseSuccess.append({"type": "Get most popular pages", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetTopEntryExitPages(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetTopEntryExitPagesSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.top_entry_exit_pages()
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get top entry exit pages"
            responseSuccess.append({"type": "Get top entry exit pages", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetBounceRate(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetBounceRateSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.bounce_rate(specifiers='country')
        # print("############# data #################")
        # print(status, )
        if status:
            data1 = data.replace("\\", "")
            data2 = data1.replace('0096', '–')
            translatedText = data2.replace('00', '')
            responseData = json.loads(translatedText)
            # print(type(responseData))
            mobileMsg = "Get bounce rate"
            responseSuccess.append({"type": "Get bounce rate", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetPageViewSemantics(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetPageViewSemanticsSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.page_view_semantics()
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get page view semantics"
            responseSuccess.append({"type": "Get page view semantics", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetConversionPath(APIView):  # conversion_path
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetConversionPathSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.conversion_path(specifiers='country')
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get converstion path"
            responseSuccess.append({"type": "Get converstion path", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetActiveUsers(APIView):  # conversion_path
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetActiveUsersSerializer")

        if finalResponse:
            return requestData

        status, data = kissmetrics.active_users(specifiers='country')
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get active users"
            responseSuccess.append({"type": "Get active users", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)

# @xframe_options_exempt

from django.contrib import admin
def modified_admin_template(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
    }
    return render(request, 'kishmetrics.html', context)
