from django.apps import AppConfig


class KissmetricsConfig(AppConfig):
    name = 'kissmetrics'
