from django.contrib import admin
from .models import Kissmetrics
from django.shortcuts import render
# Register your models here.


class MyKissmetricAdmin(admin.ModelAdmin):
    #change_form_template = 'my_change_form.html'
    #change_form_template = 'kissmetrics/change_form.html'
    #render(request, 'spain_insight.html', context)
    pass

#admin.site.register(Kissmetrics, MyKissmetricAdmin)