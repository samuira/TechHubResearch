from django.conf.urls import url
from .views import *
urlpatterns = [
            url(r'^get_visiting_demography$', GetVisitingDemography.as_view(), name='get_visiting_demography'),  # (OK)
            url(r'^get_top_n_visit_demography$', GetTopNvisitDemography.as_view(), name='get_top_n_visit_demography'),  # (OK)
            url(r'^get_average_session_length$', GetAverageSessionLength.as_view(), name='user_logout'),  # (OK)
            url(r'^get_most_popular_pages$', GetMostPopularPages.as_view(), name='get_most_popular_pages'),  # (OK)
            url(r'^get_top_entry_exit_pages$', GetTopEntryExitPages.as_view(), name='get_top_entry_exit_pages'),  # (OK)
            url(r'^get_bounce_rate$', GetBounceRate.as_view(), name='get_bounce_rate'),  # (OK)
            url(r'^page_view_semantics$', GetPageViewSemantics.as_view(), name='page_view_semantics'),  # (OK)
            url(r'^conversion_path$', GetConversionPath.as_view(), name='conversion_path'),  # (OK)
            url(r'^active_users$', GetActiveUsers.as_view(), name='active_users'),  # (OK)
        ]