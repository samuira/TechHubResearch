from django.db import models

# Create your models here.


class Kissmetrics(models.Model):
    pass

    class Meta:
        verbose_name = "Kissmetric"
        verbose_name_plural = "Kissmetrics"

