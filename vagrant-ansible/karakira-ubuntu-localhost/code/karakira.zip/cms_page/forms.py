from django import forms
from .models import CmsPage
# from ckeditor.widgets import CKEditorWidget


class CmsPageFormAdmin(forms.ModelForm):
    """docstring for CmsPageFormAdmin"""
    # content = forms.CharField(widget=CKEditorWidget(config_name='awesome_ckeditor'))

    def __init__(self, *args, **kwargs):
        super(CmsPageFormAdmin, self).__init__(*args, **kwargs)

    class Meta:
        model = CmsPage
        exclude = ('entityId', 'langId', 'createdDate', 'createdBy', 'updatedDate', 'updatedBy', 'isDeleted')
