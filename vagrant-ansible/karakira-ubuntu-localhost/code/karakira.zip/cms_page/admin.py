from django.contrib import admin
from .models import CmsPage
from .forms import CmsPageFormAdmin
# Register your models here.


class CmsPageAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'video','isDeleted')
    list_per_page = 25
    list_filter = ('slug',)
    # list_editable = ('slug',)
    search_fields = ['title', 'slug']
    sortable_field_name = "title", "slug"

    form = CmsPageFormAdmin

    def save_model(self, request, obj, form, change):
        if not change:
            obj.createdBy_id = request.user.id
            obj.updatedBy_id = request.user.id
            obj.entityId_id = 1
            obj.langId_id = 1
        else:
            obj.entityId_id = 1
            obj.updatedBy_id = request.user.id
            obj.langId_id = 1
        obj.save()

    actions = ['delete_selected']

    def delete_selected(self, request, obj):
        for o in obj.all():
            o.isDeleted = True
            o.save()
    delete_selected.short_description = 'Delete selected CMS Pages'


admin.site.register(CmsPage, CmsPageAdmin)
