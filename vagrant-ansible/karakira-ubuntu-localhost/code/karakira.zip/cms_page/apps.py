from django.apps import AppConfig


class CmsPageConfig(AppConfig):
    name = 'cms_page'
