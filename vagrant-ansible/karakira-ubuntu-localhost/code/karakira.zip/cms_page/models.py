from django.db import models
from django.utils import timezone
from django.conf import settings
from site_master.utils import SoftDeleteManager
from site_master.models import Entity, Language
from ckeditor.fields import RichTextField

# Create your models here.


class CmsPage(models.Model):
    title = models.CharField(max_length=200, blank=False)
    slug = models.CharField(max_length=20, blank=False)
    content = RichTextField(config_name='awesome_ckeditor')
    video = models.FileField(upload_to='videos/', null=True, verbose_name="Insert Video")
    entityId = models.ForeignKey(Entity, on_delete=models.CASCADE)
    langId = models.ForeignKey(Language, on_delete=models.CASCADE)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='cms_page_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='cms_page_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.title

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()
