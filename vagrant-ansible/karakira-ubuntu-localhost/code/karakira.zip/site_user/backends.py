from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model
from django.conf import settings
from django.db.models import Q

###################################
"""  DEFAULT SETTINGS + ALIAS   """
###################################


try:
	am = settings.AUTHENTICATION_METHOD
except:
	am = 'both'
try:
	cs = settings.AUTHENTICATION_CASE_SENSITIVE
except:
	cs = 'both'

#####################
"""   EXCEPTIONS  """
#####################


VALID_AM = ['username', 'email', 'both']
VALID_CS = ['username', 'email', 'both', 'none']

if (am not in VALID_AM):
	raise Exception("Invalid value for AUTHENTICATION_METHOD in project "
					"settings. Use 'username','email', or 'both'.")

if (cs not in VALID_CS):
	raise Exception("Invalid value for AUTHENTICATION_CASE_SENSITIVE in project "
					"settings. Use 'username','email', 'both' or 'none'.")

############################
"""  OVERRIDDEN METHODS  """
############################


class DualAuthentication(ModelBackend):
	"""
	This is a ModelBacked that allows authentication
	with either a username or an email address.
	"""

	def authenticate(self, username, password):
		UserProfile = get_user_model()
		try:
			user = UserProfile.objects.get(
				Q(username=username) | Q(email=username) | Q(phone_no=username)
			)
		except UserProfile.DoesNotExist:
			return None

		return user if user.check_password(password) else None

	def get_user(self, username):
		UserModel = get_user_model()
		try:
			return UserModel.objects.get(pk=username)
		except UserModel.DoesNotExist:
			return None
