from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^', include([
        url(r'^$', views.resetpasswordForm, name='form'),
    ], namespace="reset_password_form")),
]