# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.conf import settings

# Create your views here.
def resetpasswordForm(request, key):
	context = {
		'reset_pass_form_action':settings.PROTOCOL+"://"+request.META['HTTP_HOST']+"/api/password_reset/"+key
	}
	return render(request, 'reset_password_form.html', context)

def homePage(request):
	context = {
	}
	return render(request, 'home_page.html', context)