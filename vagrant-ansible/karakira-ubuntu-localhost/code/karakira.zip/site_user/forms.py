from django import forms
from .models import *
from django.conf import settings
from site_master.models import *
from django.conf import settings
from intl_tel_input.widgets import IntlTelInputWidget
from django.db.models import Q
from django.contrib.admin import widgets
from django.contrib.auth.models import Permission, Group
from django.contrib.admin.widgets import FilteredSelectMultiple
from django.utils.translation import ugettext_lazy as _

GENDER_CHOICES = [
	[1, "Male"],
	[2, "Female"]
]

def get_permissions():
	app_models_dict = {}

	for app_model in settings.GROUP_PERMISSIONS_MODELS:
		app, model = app_model.split(".")
		app_models_dict.setdefault(app, []).append(model)

	q = Q()

	for app, models in app_models_dict.items():
		q |= Q(content_type__app_label=app, content_type__model__in=models)

	if q:
		return Permission.objects.filter(q)
	else:
		return Permission.objects.all()

class BIFormAdmin(forms.ModelForm):
	widgets = {
		'phone_no': IntlTelInputWidget()
	}
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, widget=IntlTelInputWidget())
	is_active = forms.BooleanField(required=False)
	is_staff = forms.BooleanField(required=False, initial=True, widget=forms.HiddenInput())
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	user_permissions = forms.ModelMultipleChoiceField(queryset=get_permissions(), widget=FilteredSelectMultiple(_('permissions'), False))
	model = BusinessAnalyst
	# class Media:
	# 	css = {'all': ('/static/admin/css/widgets.css',),}
	# 	js = ('/admin/jsi18n',)
	def __init__(self, *args, **kwargs):
		super(BIFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user_ptr.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user_ptr.first_name
			self.initial['last_name'] = instance.user_ptr.last_name
			self.initial['email'] = instance.user_ptr.email
			self.initial['phone_no'] = instance.user_ptr.phone_no
			self.initial['age'] = instance.user_ptr.age
			self.initial['gender'] = instance.user_ptr.gender
			self.initial['is_active'] = instance.user_ptr.is_active
			self.initial['is_staff'] = instance.user_ptr.is_staff
			self.initial['nationality'] = instance.user_ptr.nationality		
			self.initial['profession'] = instance.user_ptr.profession

class BuyerFormAdmin(forms.ModelForm):
	widgets = {
		'phone_no': IntlTelInputWidget()
	}
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, widget=IntlTelInputWidget())
	is_active = forms.BooleanField(required=False)
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	agentUUID = forms.ModelChoiceField(queryset=User.objects.filter(is_staff=False), empty_label="Select Agent", required=False)
	model = Buyer

	def __init__(self, *args, **kwargs):
		super(BuyerFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user.first_name
			self.initial['last_name'] = instance.user.last_name
			self.initial['email'] = instance.user.email
			self.initial['phone_no'] = instance.user.phone_no
			self.initial['age'] = instance.user.age
			self.initial['gender'] = instance.user.gender
			self.initial['is_active'] = instance.user.is_active
			self.initial['nationality'] = instance.user.nationality		
			self.initial['profession'] = instance.user.profession		

class SellerFsboFormAdmin(forms.ModelForm):
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, min_value=7000000000, max_value=9999999999)
	is_active = forms.BooleanField(required=False)
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	model = SellerFsbo

	def __init__(self, *args, **kwargs):
		super(SellerFsboFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user.first_name
			self.initial['last_name'] = instance.user.last_name
			self.initial['email'] = instance.user.email
			self.initial['phone_no'] = instance.user.phone_no
			self.initial['age'] = instance.user.age
			self.initial['gender'] = instance.user.gender
			self.initial['is_active'] = instance.user.is_active
			self.initial['nationality'] = instance.user.nationality
			self.initial['profession'] = instance.user.profession

class SellerAgentFormAdmin(forms.ModelForm):
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, min_value=7000000000, max_value=9999999999)
	is_active = forms.BooleanField(required=False)
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	model = SellerAgent

	def __init__(self, *args, **kwargs):
		super(SellerAgentFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user.first_name
			self.initial['last_name'] = instance.user.last_name
			self.initial['email'] = instance.user.email
			self.initial['phone_no'] = instance.user.phone_no
			self.initial['age'] = instance.user.age
			self.initial['gender'] = instance.user.gender
			self.initial['is_active'] = instance.user.is_active
			self.initial['nationality'] = instance.user.nationality
			self.initial['profession'] = instance.user.profession

class RenterFormAdmin(forms.ModelForm):
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, min_value=7000000000, max_value=9999999999)
	is_active = forms.BooleanField(required=False)
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	model = Renter

	def __init__(self, *args, **kwargs):
		super(RenterFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user.first_name
			self.initial['last_name'] = instance.user.last_name
			self.initial['email'] = instance.user.email
			self.initial['phone_no'] = instance.user.phone_no
			self.initial['age'] = instance.user.age
			self.initial['gender'] = instance.user.gender
			self.initial['is_active'] = instance.user.is_active
			self.initial['nationality'] = instance.user.nationality
			self.initial['profession'] = instance.user.profession

class PropertyManagerFormAdmin(forms.ModelForm):
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, min_value=7000000000, max_value=9999999999)
	is_active = forms.BooleanField(required=False)
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	model = PropertyManager

	def __init__(self, *args, **kwargs):
		super(PropertyManagerFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user.first_name
			self.initial['last_name'] = instance.user.last_name
			self.initial['email'] = instance.user.email
			self.initial['phone_no'] = instance.user.phone_no
			self.initial['age'] = instance.user.age
			self.initial['gender'] = instance.user.gender
			self.initial['is_active'] = instance.user.is_active
			self.initial['nationality'] = instance.user.nationality
			self.initial['profession'] = instance.user.profession

class InvestorFormAdmin(forms.ModelForm):
	username = forms.CharField(required=True)
	password = forms.CharField(required=True, widget=forms.PasswordInput)
	first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid First Name'}))
	last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class':'form-control' , 'autocomplete': 'off','pattern':'[A-Za-z ]+', 'title':'Please Enter Valid Last Name'}))
	email = forms.EmailField(required=True)
	phone_no = forms.IntegerField(required=True, min_value=7000000000, max_value=9999999999)
	is_active = forms.BooleanField(required=False)
	age = forms.IntegerField(required=False, min_value=18, max_value=99)
	gender = forms.ChoiceField(choices = GENDER_CHOICES, required=True)
	profession = forms.CharField(required=False)
	nationality = forms.ModelChoiceField(queryset=Country.objects.all(), empty_label="Select Country", required=True)
	model = Investor

	def __init__(self, *args, **kwargs):
		super(InvestorFormAdmin, self).__init__(*args, **kwargs)
		instance = getattr(self, 'instance', None)
		if instance and instance.pk:
			self.initial['username'] = instance.user.username
			self.fields['username'].widget.attrs['readonly'] = 'readonly'
			self.fields['password'].required = False
			self.initial['first_name'] = instance.user.first_name
			self.initial['last_name'] = instance.user.last_name
			self.initial['email'] = instance.user.email
			self.initial['phone_no'] = instance.user.phone_no
			self.initial['age'] = instance.user.age
			self.initial['gender'] = instance.user.gender
			self.initial['is_active'] = instance.user.is_active
			self.initial['nationality'] = instance.user.nationality
			self.initial['profession'] = instance.user.profession
