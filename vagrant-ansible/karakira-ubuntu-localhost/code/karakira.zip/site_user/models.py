# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import AbstractUser
from auditlog.registry import auditlog
from auditlog.models import AuditlogHistoryField
from django.utils import timezone
from django.conf import settings
from site_master.utils import SoftDeleteManager
from site_master.models import *
from django.contrib.auth.models import Group
from django.contrib.sessions.models import Session as Django_Generic_Session
#from django.contrib.sessions.base_session import AbstractBaseSession as Django_Generic_Session
#import datetime
#from property.models import Listings
# Create your models here.


def profile_image(instance, filename):
    print(filename)
    print(instance)
    upload_to = 'static/media/user/'
    # upload_to = os.path.join(upload_to, 'header_image')
    ext = filename.split('.')[-1]
    # get filename
    if instance.pk:
        filename = '{}.{}'.format(instance.pk, ext)
    else:
        # set filename as random string
        filename = '{}.{}'.format(uuid4().hex, ext)
    # return the whole path to the file
    return os.path.join(upload_to, filename)


Group.add_to_class('slug', models.CharField(
    max_length=20, default='', blank=False))


class User(AbstractUser):
    phone_no = models.CharField(max_length=20, default="", blank=True)
    is_phone_verified = models.BooleanField(default=False)
    is_email_verified = models.BooleanField(default=False)
    social = models.CharField(max_length=254, default='', blank=True)
    wallet = models.CharField(max_length=254, default='', blank=True)
    age = models.IntegerField(default=1)
    gender = models.IntegerField(
        choices=[(1, 'Male'), (2, 'Female')], default=1)
    profession = models.CharField(max_length=254, default='', blank=True)
    nationality = models.ForeignKey(Country, on_delete=models.SET_NULL,
                                    related_name='user_nationality_country', null=True, blank=True, default=0)
    user_defined_password = models.BooleanField(default=True)
    fb_id = models.CharField(max_length=254, default='', blank=True)
    gplus_id = models.CharField(max_length=254, default='', blank=True)
    linkedin_id = models.CharField(max_length=254, default='', blank=True)
    twitter_id = models.CharField(max_length=254, default='', blank=True)
    image = models.ImageField(upload_to=profile_image,
                              null=True, blank=True, max_length=1000)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    createdBy = models.IntegerField(null=True)
    updatedBy = models.IntegerField(null=True)
    isOnline = models.BooleanField(default=False)
    isdeleted = models.BooleanField(default=False)
    history = AuditlogHistoryField()

    class Meta:
        db_table = 'auth_user'

    def get_name(self):
        return self.first_name + ' ' + self.last_name

    def __str__(self):
        return u"%s %s" % (self.first_name, self.last_name)

    def getImageUrl(self, request):
        return '' if xstr(self.image) is '' else settings.PROTOCOL + "://" + request.META['HTTP_HOST'] + "/" \
                                                 + xstr(self.image)


class BusinessAnalyst(User):
    isDeleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'BusinessAnalyst'
        verbose_name_plural = 'BusinessAnalysts'

    def __str__(self):
        return u"%s" % self.user_ptr

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class UserChat(models.Model):
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                               related_name='user_chat_sender', default='', blank=True, null=True)
    sender_type = models.ForeignKey(Group, on_delete=models.CASCADE,
                                    related_name='user_chat_sender_type', default='', blank=True, null=True)
    receiver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                 related_name='user_chat_receiver', default='', blank=True, null=True)
    receiver_type = models.ForeignKey(
        Group, on_delete=models.CASCADE, related_name='user_chat_receiver_type', default='', blank=True, null=True)

    def __str__(self):
        return u"%s" % self.sender


class Buyer(models.Model):
    user = models.OneToOneField(User, related_name='buyer_user')
    allowAnonymousSearches = models.BooleanField(default=True)
    hasAgent = models.BooleanField(default=False)
    agentUUID = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                  related_name='user_buyer_agent_user', default='', blank=True, null=True)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='buyer_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='buyer_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.user

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class SellerFsbo(models.Model):
    user = models.OneToOneField(User, related_name='seller_fsbo_user')
    fsboIdentificationSet = models.CharField(
        max_length=254, default='', blank=True)
    identificationDocumentsReceivedCount = models.IntegerField(
        null=True, default=0)
    identificationDocumentsVerifiedCount = models.IntegerField(
        null=True, default=0)
    isKaraKiraCertified = models.BooleanField(default=False)
    mlsActiveListings = models.CharField(
        max_length=254, default='', blank=True)
    mlsActiveListingsCount = models.IntegerField(null=True, default=0)
    propertyDocumentationSet = models.CharField(
        max_length=254, default='', blank=True)
    propertyDocumentsReceivedCount = models.IntegerField(null=True, default=0)
    propertyDocumentsVerifiedCount = models.IntegerField(null=True, default=0)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='seller_fsbo_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='seller_fsbo_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.user

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class SellerAgent(models.Model):
    user = models.OneToOneField(User, related_name='seller_agent_user')
    emailCompany = models.CharField(max_length=254, default='', blank=True)
    phoneLandline = models.CharField(max_length=20, default="", blank=True)
    agent = models.BooleanField(default=False)
    licensed = models.BooleanField(default=False)
    commercial = models.BooleanField(default=False)
    residential = models.BooleanField(default=False)
    rentals = models.BooleanField(default=False)
    manager = models.BooleanField(default=False)
    owner = models.BooleanField(default=False)
    #location = models.CharField(max_length=255, default="", blank=True)
    agentIdentificationSet = models.CharField(
        max_length=254, default='', blank=True)
    identificationDocumentsReceivedCount = models.IntegerField(
        null=True, default=0)
    identificationDocumentsVerifiedCount = models.IntegerField(
        null=True, default=0)
    isKaraKiraCertified = models.BooleanField(default=False)
    mlsActiveListingsCount = models.IntegerField(null=True, default=0)
    propertyDocumentationSet = models.CharField(
        max_length=254, default='', blank=True)
    propertyDocumentsReceivedCount = models.IntegerField(null=True, default=0)
    propertyDocumentsVerifiedCount = models.IntegerField(null=True, default=0)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='seller_agent_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='seller_agent_updated_by_user')
    zip_code = models.IntegerField(default=0)  # zipcode for agent
    upload_certificate = models.FileField(
        upload_to='agent/file', null=True, blank=True, help_text="Upload your certificate")  # Agent certificate
    upload_prop_pic = models.ImageField(
        upload_to='agent/pic', null=True, blank=True, help_text="Upload property pic")  # property picture
    upload_prop_video = models.FileField(
        upload_to='agent/video', null=True, blank=True, help_text="Upload property video")  # property video

    location = models.CharField(
        max_length=255, default="", blank=True, help_text="Enter city name")  # City name
    state = models.CharField(max_length=30, default="",
                             blank=True, help_text="Enter state name")
    # Creation of dropdown for languages in which an agent is conversant to speak
    ENGLISH = 'English'
    SPANISH = 'Spanish'
    FRENCH = 'French'
    RUSSIAN = 'Russian'
    GERMAN = 'German'
    LANGUAGE_KNOWN = ((ENGLISH, 'English'), (SPANISH, 'Spanish'),
                      (FRENCH, 'French'), (RUSSIAN, 'Russian'), (GERMAN, 'German'))
    # language_known = models.CharField(max_length=10, choices=LANGUAGE_KNOWN, default=ENGLISH)
    language_known = models.CharField(max_length=500, default="")
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return "SellerAgent ID : " + "-----" + str(self.user.id)

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class AgentReviewsandRatings(models.Model):
    agent = models.ForeignKey(SellerAgent, on_delete=models.CASCADE, related_name='review_rating_to_agent_by_user')
    reviews = models.TextField(default='', blank=True)
    ratings = models.IntegerField(default=1, help_text="Rating value in (1-5)")
    given_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                 related_name='who_provide_review_and_rating')

    def __str__(self):
        return self.given_by.username + " wrote about seller agent " + self.agent.user.username

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class Renter(models.Model):
    user = models.OneToOneField(User, related_name='renter_user')
    propertyDocumentationSet = models.CharField(
        max_length=254, default='', blank=True)
    propertyDocumentsReceivedCount = models.IntegerField(null=True, default=0)
    propertyDocumentsVerifiedCount = models.IntegerField(null=True, default=0)
    renterIdentificationSet = models.CharField(
        max_length=254, default='', blank=True)
    identificationDocumentsReceivedCount = models.IntegerField(
        null=True, default=0)
    identificationDocumentsVerifiedCount = models.IntegerField(
        null=True, default=0)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='renter_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='renter_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.user

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class Rentee(models.Model):
    user = models.OneToOneField(User, related_name='rentee_user')
    isDeleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'Rentee'
        verbose_name_plural = 'Rentee'

    def __str__(self):
        return u"%s" % self.user

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class PropertyManager(models.Model):
    user = models.OneToOneField(User, related_name='property_manager_user')
    emailCompany = models.CharField(max_length=254, default='', blank=True)
    phoneLandline = models.CharField(max_length=20, default="", blank=True)
    propertyDocumentationSet = models.CharField(
        max_length=254, default='', blank=True)
    propertyDocumentsReceivedCount = models.IntegerField(null=True, default=0)
    propertyDocumentsVerifiedCount = models.IntegerField(null=True, default=0)
    propertyManagerIdentificationSet = models.CharField(
        max_length=254, default='', blank=True)
    identificationDocumentsReceivedCount = models.IntegerField(
        null=True, default=0)
    identificationDocumentsVerifiedCount = models.IntegerField(
        null=True, default=0)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='property_manager_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='property_manager_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.user

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class Investor(models.Model):
    user = models.OneToOneField(User, related_name='investor_user')
    emailCompany = models.CharField(max_length=254, default='', blank=True)
    phoneLandline = models.CharField(max_length=20, default="", blank=True)
    investorIdentificationSet = models.CharField(
        max_length=254, default='', blank=True)
    identificationDocumentsReceivedCount = models.IntegerField(
        null=True, default=0)
    identificationDocumentsVerifiedCount = models.IntegerField(
        null=True, default=0)
    city = models.CharField(max_length=255, default="", blank=True)
    state = models.CharField(max_length=255, default="", blank=True)
    country = models.CharField(max_length=255, default="", blank=True)
    zip_code = models.IntegerField(default=0)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='investor_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='investor_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    location = models.CharField(max_length=50, default="")  # If no location is mentioned by investor
                                                        # during project searching then we consider investor's location.
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.user

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class EmailVerification(models.Model):
    user = models.OneToOneField(User, related_name='email_verify')
    activation_key = models.CharField(max_length=40)
    key_expires = models.DateTimeField()


class PagesVisitedHistory(models.Model):
    url = models.CharField(max_length=255, default='', blank=False)
    datetime = models.DateTimeField(default=timezone.now, null=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='auth_user_unique_id')

    def __str__(self):
        return u"%s" % self.url


# Following class is used for user session handling
class UserSession(models.Model):
    user = models.ForeignKey(User, null=True)
    session_info = models.CharField(max_length=255, default="")
    browser_info = models.TextField(default="")
    IP = models.CharField(max_length=255, default="")
    def __str__(self):
        return "User {} with session {} from IP {} with browser {}".format(str(self.user),
                                                                str(self.session_info),
                                                                str(self.IP),
                                                                self.browser_info)



class Session(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='unique_user_id')
    sessionID = models.ForeignKey(
        Django_Generic_Session, on_delete=models.CASCADE, related_name='django_encoded_session_data')
    seesionToken = models.CharField(max_length=40, default='', blank=False)
    sessionEncrypted = models.BooleanField(default=False)
    sessionIsFirstLogin = models.BooleanField(default=False)
    sessionIsBuyer = models.BooleanField(default=False)
    sessionIsSeller = models.BooleanField(default=False)
    sessionIsAgent = models.BooleanField(default=False)
    sessionIsManager = models.BooleanField(default=False)
    sessionIsRenter = models.BooleanField(default=False)
    sessionIsInvestor = models.BooleanField(default=False)
    sessionIsAmbassador = models.BooleanField(default=False)
    sessionIsRegionalSalesManager = models.BooleanField(default=False)
    sessionIsEmployee = models.BooleanField(default=False)
    sessionIsGuest = models.BooleanField(default=False)
    sessionIsSubscribed = models.BooleanField(default=False)
    sessionIsActive = models.BooleanField(default=False)
    sessionIsOnline = models.BooleanField(default=False)
    sessionAppState = models.CharField(max_length=255, default='', blank=True)
    sessionLastLogOnTime = models.DateTimeField(
        default=timezone.now, blank=True)
    sessionLastLogOffTime = models.DateTimeField(
        default=timezone.now, blank=True)
    sessionLastSessionDuration = models.DateTimeField(
        default=timezone.now, blank=True)
    sessionLogOnTime = models.DateTimeField(default=timezone.now, blank=True)
    sessionLogOffTime = models.DateTimeField(default=timezone.now, blank=True)
    sessionBrowserType = models.CharField(
        max_length=255, blank=True, default='')
    sessionBrowserVersion = models.FloatField(blank=False)
    sessionOSType = models.CharField(max_length=255, default='', blank=True)
    sessionOSVersion = models.FloatField(blank=False)
    sessionDeviceCategory = models.CharField(
        max_length=255, default='', blank=True)
    sessionDeviceMake = models.CharField(
        max_length=255, default='', blank=True)
    sessionDeviceModel = models.CharField(
        max_length=255, default='', blank=True)
    # Listings, on_delete=models.CASCADE, related_name='listing_details')
    listOnMouseoverHistory = models.TextField(blank=True)
    # Listings, on_delete=models.CASCADE, related_name='listing_details')
    listOnClickHistory = models.TextField(blank=True)
    listPagesVisitedHistory = models.TextField(blank=True)
    sessionSrcIPAddress = models.GenericIPAddressField(
        protocol='both', unpack_ipv4=False, blank=False)
    sessionSrcCountry = models.CharField(
        max_length=255, default='', blank=True)
    sessionSrcLocation = models.CharField(
        max_length=255, default='', blank=True)
    sessionDatetime = models.CharField(
        max_length=255, default=timezone.now, blank=False)
    # ForeignKey(settings.GPS_MODEL,on_delete=models.CASCADE,related_name='geoIp_coords_history')
    listGeoipHistory = models.TextField(blank=True)
    # ForeignKey(settings.GPS_MODEL,on_delete=models.CASCADE,related_name='geoIp_location_history')
    listUserLocationHistory = models.TextField(blank=True)
    # ForeignKey(settings.Viewer_History_MODEL,on_delete=models.CASCAD,related_name='viewer_history')
    listPropertyViewed = models.TextField(blank=True)
    # ForeignKey(settings.Search_History_MODEL,on_delete=models.CASCAD,related_name='search_history')
    listSearchHistory = models.TextField(blank=True)
    # ForeignKey(settings.Search_Locations_History_MODEL,on_delete=models.CASCAD,related_name='location_history')
    listLocationsSearchedByBar = models.TextField(blank=True)
    # ForeignKey(settings.Search_Locations_History_MODEL,on_delete=models.CASCAD,related_name='location_history_using_map')
    listLocationsSearchedByMap = models.TextField(blank=True)
    # ForeignKey(settings.Search_Locations_History_MODEL,on_delete=models.CASCAD,related_name='location_history_using_map')
    listMapSearchEvents = models.TextField(blank=True)
    counterActiveSearchingDays = models.IntegerField(null=True, default=0)
    userEmail = models.CharField(max_length=255, default='', blank=True)
    listUIPreferences = models.TextField(blank=True)
    listLifeStyleParametersCurrent = models.TextField(blank=True)
    listLifeStyleParametersDesired = models.TextField(blank=True)
    listSearchFeatures = models.TextField(blank=True)
    listFindAnAgentUsageHistory = models.TextField(blank=True)
    listCtaTakenToday = models.TextField(blank=True)
    listCtaTakenHistorical = models.TextField(blank=True)
    listCtaFavoritesToday = models.TextField(blank=True)
    listCtaFavoritesHistorical = models.TextField(blank=True)
    listCtaThumbsUpToday = models.TextField(blank=True)
    listCtaThumbsUpHistorical = models.TextField(blank=True)
    listCtaThumbsDownToday = models.TextField(blank=True)
    listCtaThumbsDownHistorical = models.TextField(blank=True)
    listCtaPricingToday = models.TextField(blank=True)
    listCtaPricingHistorical = models.TextField(blank=True)
    listCtaLifestyleParameterTweakingToday = models.TextField(blank=True)
    listCtaTLifestyleParameterTweakingHistorical = models.TextField(blank=True)
    listCtaGetMoreInfoClicked = models.TextField(blank=True)
    counterAVGScanRateResultSet = models.CharField(
        max_length=255, default='', blank=True)
    counterAVGClickRatePropertyPhotoSet = models.CharField(
        max_length=255, default='', blank=True)
    counterAVGTimeSpentPerPhoto = models.FloatField(blank=False)
    counterAVGTimeSpentThisPhoto = models.FloatField(blank=False, default=0)
    listPhotosInterestedIn = models.TextField(blank=True)
    listPropertiesInterestedIn = models.TextField(blank=True)
    listPropertiesReallyInterestedIn = models.TextField(blank=True)
    alarmLastPhotoClickedInSet = models.TextField(blank=True)
    alarmLessThanHalfPhotosViewed = models.BooleanField(default=False)
    alarmLessThan5SecondsSpentViewing = models.TextField(blank=True)
    alarmMostClickedPhotos = models.TextField(blank=True)
    alarmPropertyClickedMultipleTimes = models.TextField(blank=True)
    alarmNoCtaInLast20Mins = models.TextField(blank=True)
    alarmNoCtaInLast24Hours = models.TextField(blank=True)
    counterEnquiresSentToday = models.IntegerField(null=True, default=0)
    counterEnquiresSentHistorical = models.IntegerField(null=True, default=0)
    counterWebRTCCallsMadeToday = models.IntegerField(null=True, default=0)
    counterWebRTCCallsMadeHistoric = models.IntegerField(null=True, default=0)
    counterIMsMadeToday = models.IntegerField(null=True, default=0)
    counterIMsMadeHistoric = models.IntegerField(null=True, default=0)
    counterAvgIdleTime = models.CharField(
        max_length=255, default='', blank=True)
    counterPagesPerMinute = models.FloatField(blank=False)
    counterPagesClickedToday = models.FloatField(blank=False)
    counterAvgPagesClickedHistorical = models.FloatField(blank=False)
    counterAvgSearchesToday = models.FloatField(blank=False)
    counterAvgSearchesHistorical = models.FloatField(blank=False)
    counterPropertiesViewedToday = models.IntegerField(null=True, default=0)
    counterPropertiesViewedHistorical = models.IntegerField(
        null=True, default=0)
    counterVideosClickedToday = models.IntegerField(null=True, default=0)
    counterVideosClickedHistorical = models.IntegerField(null=True, default=0)
    lisOfVideosMostlyWatchedHistorical = models.TextField(blank=True)
    counterPurchasesMadeToday = models.IntegerField(null=True, default=0)
    counterPurchasesMadeHistorical = models.IntegerField(null=True, default=0)
    counterMessageBoardViews = models.TextField(blank=True)
    counterMessageBoardPosts = models.TextField(blank=True)
    counterPropertiesAddedLastMonth = models.IntegerField(null=True, default=0)
    counterPropertiesAddedThisMonth = models.IntegerField(null=True, default=0)
    counterPropertiesAddedTotal = models.IntegerField(null=True, default=0)
    counterPropertiesRemovedLastMonth = models.IntegerField(
        null=True, default=0)
    counterPropertiesRemovedThisMonth = models.IntegerField(
        null=True, default=0)
    counterPropertiesRemovedTotal = models.IntegerField(null=True, default=0)
    listNetAddsMonthlyRoC = models.TextField(blank=True)
    listAppUsageFrequency = models.TextField(blank=True)
    listWebUsageFrequency = models.TextField(blank=True)
    listResponseTimeEmail = models.TextField(blank=True)
    listAgentResponseTimeIM = models.TextField(blank=True)
    listAgentResponseTimeMessageBoard = models.TextField(blank=True)
    listDailySearchHistory = models.TextField(blank=True)
    # ForeignKey(settings.Dashboard_Usage_History_MODEL,on_delete=models.CASCADE,related_name='dashboard_usage_history_map')
    listDailyDashboardUsageHistory = models.TextField(blank=True)
    listD3jsChartEvents = models.TextField(blank=True)

    def __str__(self):
        return u"%s" % self.UUID


auditlog.register(User)
