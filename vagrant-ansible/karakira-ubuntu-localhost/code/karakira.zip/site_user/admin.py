# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import ugettext, ugettext_lazy as _
from .models import *
from .forms import BIFormAdmin, BuyerFormAdmin, SellerFsboFormAdmin, SellerAgentFormAdmin, RenterFormAdmin, PropertyManagerFormAdmin, InvestorFormAdmin
from django.utils import timezone
from django.conf import settings
from django.contrib.auth.models import Group
import sys
# Register your models here.

class SiteCustomUserAdmin(UserAdmin):
	"""docstring for SiteCustomUserAdmin"""
	fieldsets = (
		(None, {'fields': ('username', 'password')}),
		(_('Personal info'), {'fields': ('first_name', 'last_name', 'email', 'phone_no')}),
		(_('Other Info'), {'fields': ('is_active', 'is_staff', 'is_superuser',
									   'groups', 'user_permissions')}),
		(_('Important dates'), {'fields': ('last_login', 'date_joined'), 'classes': ['collapse']}),
	)	

class UserBIAdmin(admin.ModelAdmin):
	fieldsets = (
		(None, {'fields': ('username', 'password')}),
		(_('Personal info'), {'fields': ('first_name', 'last_name', 'email', 'phone_no')}),
		(_('Others info'), {'fields': ('age', 'gender', 'profession', 'nationality')}),
		(_('Permissions'), {'fields': ('is_active','is_staff','is_superuser','user_permissions')}),
	)
	form = BIFormAdmin
	add_form = BIFormAdmin
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(slug='business_analyst')
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :	
			obj.updatedBy_id = request.user.id
		if formData.get('password'):
			obj.set_password(formData.get('password'))
		obj.save()
		group.user_set.add(obj.user_ptr)

class UserBuyerAdmin(admin.ModelAdmin):
	form = BuyerFormAdmin
	change_form_template = 'admin/change_form.html'
	fieldsets = [
		[None, {'fields': ['username', 'password']}],
		[_('Personal info'), {'fields': ['first_name', 'last_name', 'email', 'phone_no', 'age', 'gender']}],
		[_('Buyer Info'), {'fields': ['allowAnonymousSearches', 'hasAgent', 'agentUUID']}],
		[_('Other Info'), {'fields': ['profession','nationality', 'is_active']}],
	]
	list_display = ['user','hasAgent']
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(name='Buyer')
		if not change:
			user = User.objects.create_user(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				username=formData.get('username'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				createdBy = request.user.id,
				updatedBy = request.user.id,
				createdDate = timezone.now(),
				updatedDate = timezone.now()
			)
			user.set_password(formData.get('password'))
			user.save()
			group.user_set.add(user)
			obj.user_id = user.id
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :
			User.objects.filter(pk=obj.user_id).update(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				updatedBy = request.user.id,
				updatedDate = timezone.now()
			)
			user = User.objects.filter(id=obj.user_id).first()
			group.user_set.add(user)
			if formData.get('password'):
				user.set_password(formData.get('password'))
			user.save()
			obj.updatedBy_id = request.user.id
		obj.save()

	def delete_model(self, request, obj):
		user_id = obj.user_id
		obj.delete()
		User.objects.filter(pk=user_id).delete()

class UserSellerFsboAdmin(admin.ModelAdmin):
	form = SellerFsboFormAdmin
	fieldsets = [
		[None, {'fields': ['username', 'password']}],
		[_('Personal info'), {'fields': ['first_name', 'last_name', 'email', 'phone_no', 'age', 'gender']}],
		[_('SellerFsbo Info'), {'fields': ['isKaraKiraCertified']}],
		[_('Other Info'), {'fields': ['profession','nationality', 'is_active']}]
	]
	list_display = ['user','fsboIdentificationSet']
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(name='Seller FSBO')
		if not change:
			user = User.objects.create_user(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				username=formData.get('username'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				createdBy = request.user.id,
				createdDate = timezone.now()
			)
			# print(user)
			user.set_password(formData.get('password'))
			user.save()
			group.user_set.add(user)
			obj.user_id = user.id
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :
			User.objects.filter(pk=obj.user_id).update(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				updatedBy = request.user.id,
				updatedDate = timezone.now()
			)
			user = User.objects.filter(id=obj.user_id).first()
			group.user_set.add(user)
			if formData.get('password'):
				user.set_password(formData.get('password'))
			user.save()
			obj.updatedBy_id = request.user.id
		obj.save()

	def delete_model(self, request, obj):
		user_id = obj.user_id
		obj.delete()
		User.objects.filter(pk=user_id).delete()

class UserSellerAgentAdmin(admin.ModelAdmin):
	form = SellerAgentFormAdmin
	fieldsets = [
		[None, {'fields': ['username', 'password']}],
		[_('Personal info'), {'fields': ['first_name', 'last_name', 'email', 'phone_no', 'age', 'gender']}],
		[_('SellerAgent Info'), {'fields': ['emailCompany', 'phoneLandline', 'agent', 'licensed', 'commercial', 'residential', 'rentals', 'manager', 'owner', 'isKaraKiraCertified']}],
		[_('Other Info'), {'fields': ['profession','nationality', 'is_active']}]
	]
	list_display = ['user','licensed']
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(name='Seller Agent')
		if not change:
			user = User.objects.create_user(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				username=formData.get('username'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				createdBy = request.user.id,
				createdDate = timezone.now()
			)
			# print(user)
			user.set_password(formData.get('password'))
			user.save()
			group.user_set.add(user)
			obj.user_id = user.id
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :
			User.objects.filter(pk=obj.user_id).update(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				updatedBy = request.user.id,
				updatedDate = timezone.now()
			)
			user = User.objects.filter(id=obj.user_id).first()
			group.user_set.add(user)
			if formData.get('password'):
				user.set_password(formData.get('password'))
			user.save()
			obj.updatedBy_id = request.user.id
		obj.save()

	def delete_model(self, request, obj):
		user_id = obj.user_id
		obj.delete()
		User.objects.filter(pk=user_id).delete()

class UserRenterAdmin(admin.ModelAdmin):
	form = RenterFormAdmin
	fieldsets = [
		[None, {'fields': ['username', 'password']}],
		[_('Personal info'), {'fields': ['first_name', 'last_name', 'email', 'phone_no', 'age', 'gender']}],
		[_('Other Info'), {'fields': ['profession','nationality', 'is_active']}]
	]
	list_display = ['user']
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(name='Renter')
		if not change:
			user = User.objects.create_user(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				username=formData.get('username'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				createdBy = request.user.id,
				createdDate = timezone.now()
			)
			# print(user)
			user.set_password(formData.get('password'))
			user.save()
			group.user_set.add(user)
			obj.user_id = user.id
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :
			User.objects.filter(pk=obj.user_id).update(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				updatedBy = request.user.id,
				updatedDate = timezone.now()
			)
			user = User.objects.filter(id=obj.user_id).first()
			group.user_set.add(user)
			if formData.get('password'):
				user.set_password(formData.get('password'))
			user.save()
			obj.updatedBy_id = request.user.id
		obj.save()

	def delete_model(self, request, obj):
		user_id = obj.user_id
		obj.delete()
		User.objects.filter(pk=user_id).delete()

class UserPropertyManagerAdmin(admin.ModelAdmin):
	form = PropertyManagerFormAdmin
	fieldsets = [
		[None, {'fields': ['username', 'password']}],
		[_('Personal info'), {'fields': ['first_name', 'last_name', 'email', 'phone_no', 'age', 'gender']}],
		[_('PropertyManager Info'), {'fields': ['emailCompany', 'phoneLandline']}],
		[_('Other Info'), {'fields': ['profession','nationality', 'is_active']}]
	]
	list_display = ['user']
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(name='Property Manager')
		if not change:
			user = User.objects.create_user(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				username=formData.get('username'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				createdBy = request.user.id,
				createdDate = timezone.now()
			)
			# print(user)
			user.set_password(formData.get('password'))
			user.save()
			group.user_set.add(user)
			obj.user_id = user.id
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :
			User.objects.filter(pk=obj.user_id).update(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				updatedBy = request.user.id,
				updatedDate = timezone.now()
			)
			user = User.objects.filter(id=obj.user_id).first()
			group.user_set.add(user)
			if formData.get('password'):
				user.set_password(formData.get('password'))
			user.save()
			obj.updatedBy_id = request.user.id
		obj.save()

	def delete_model(self, request, obj):
		user_id = obj.user_id
		obj.delete()
		User.objects.filter(pk=user_id).delete()

class UserInvestorAdmin(admin.ModelAdmin):
	form = InvestorFormAdmin
	fieldsets = [
		[None, {'fields': ['username', 'password']}],
		[_('Personal info'), {'fields': ['first_name', 'last_name', 'email', 'phone_no', 'age', 'gender']}],
		[_('Investor Info'), {'fields': ['emailCompany', 'phoneLandline']}],
		[_('Other Info'), {'fields': ['profession','nationality', 'is_active']}]
	]
	list_display = ['user']
	def save_model(self, request, obj, form, change):
		formData = form.cleaned_data
		group = Group.objects.get(name='Investor')
		if not change:
			user = User.objects.create_user(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				username=formData.get('username'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				createdBy = request.user.id,
				createdDate = timezone.now()
			)
			# print(user)
			user.set_password(formData.get('password'))
			user.save()
			group.user_set.add(user)
			obj.user_id = user.id
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
		else :
			User.objects.filter(pk=obj.user_id).update(
				email=formData.get('email'),
				phone_no=formData.get('phone_no'),
				first_name=formData.get('first_name'),
				last_name=formData.get('last_name'),
				is_active=formData.get('is_active'),
				age=formData.get('age'),
				gender=formData.get('gender'),
				is_staff=False,
				is_superuser=False,
				nationality = formData.get('nationality'),
				profession = formData.get('profession'),
				updatedBy = request.user.id,
				updatedDate = timezone.now()
			)
			user = User.objects.filter(id=obj.user_id).first()
			group.user_set.add(user)
			if formData.get('password'):
				user.set_password(formData.get('password'))
			user.save()
			obj.updatedBy_id = request.user.id
		obj.save()

	def delete_model(self, request, obj):
		user_id = obj.user_id
		obj.delete()
		User.objects.filter(pk=user_id).delete()


admin.site.register(BusinessAnalyst, UserBIAdmin)
admin.site.register(Buyer, UserBuyerAdmin)
admin.site.register(SellerFsbo, UserSellerFsboAdmin)
admin.site.register(SellerAgent, UserSellerAgentAdmin)
admin.site.register(Renter, UserRenterAdmin)
admin.site.register(PropertyManager, UserPropertyManagerAdmin)
admin.site.register(Investor, UserInvestorAdmin)
