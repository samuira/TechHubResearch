from django.contrib.admin import AdminSite
from django.http import HttpResponse
from kissmetrics.views import modified_admin_template

class MyAdminSite(AdminSite):

     def get_urls(self):
         from django.conf.urls import url
         urls = super(MyAdminSite, self).get_urls()
         urls += [
             url(r'^my_view/$', self.admin_view(self.my_view)),
             url(r'^kissmetrics/', modified_admin_template, name='modified_admin_template'),
             url(r'^kissmetrics/kissmetrics', modified_admin_template, name='modified_admin_template'),
         ]
         return urls

     def my_view(self, request):
         return HttpResponse("Hello!")

admin_site = MyAdminSite()