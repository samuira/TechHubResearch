"""karakira URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from rest_framework import routers
from webservice import views
from site_user import views as site_user_views
from kissmetrics.views import modified_admin_template
from .admin import admin_site
from rest_framework_swagger.views import get_swagger_view
from django.conf import settings
from django.conf.urls.static import static


schema_view = get_swagger_view(title='KaraKira APIs')
router = routers.DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'groups', views.GroupViewSet)

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^admin/', admin_site.urls),
    # url(r'^admin/kissmetrics/kissmetrics', modified_admin_template, name='modified_admin_template'),
    url(r'^$', site_user_views.homePage, name='home_page'),
    # url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))
    url(r'^api/', include('webservice.urls', namespace='webservice')),
    url(r'^property1/', include('property.urls', namespace='property')),
    url(r'^analytics_chart/', include('analytics.urls', namespace='analytics')),
    url(r'^wallet/', include('wallet.urls')),
    url(r'^blogs/', include('blog.urls')),
    url(r'^resetpassword/(?P<key>.+)', include('site_user.urls', namespace='resetpassword')),
    url(r'^kissmetrics/', include('kissmetrics.urls')),
    url(r'^insights/', include('insights.urls')),
    url(r'^api_list/', schema_view)
]+ static(settings.MEDIA_URL, document_root= settings.MEDIA_ROOT)
