# Karakira API

This hosts all the analytics API and integration to Machine Learning Models with the dataset.