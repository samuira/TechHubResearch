import csv

if __name__ == '__main__':
    # Writing data into temporary CSV
    expected_key_set = ['ref', 'price', 'price_freq', 'type', 'address', 'lat', 'long', 'beds', 'baths', 'pools',
                        'built', 'plot', 'desc', 'features', 'images']
    fp = open('javeaestates_xml_properties_temp.csv', 'w')
    w = csv.DictWriter(fp, expected_key_set)
    w.writeheader()
    fp = open('javeaestates_xml_properties_backup.csv', 'r')
    dict_element = csv.DictReader(fp)
    for element in dict_element:
        element['address'] = element['address'].replace(' ', '-')
        w.writerow(element)
