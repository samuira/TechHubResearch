import requests
import xmltodict
from geopy.geocoders import Nominatim
import json
import csv

final_response = list()


def find_lat_long(address=None):
    try:
        geolocator = Nominatim(user_agent="my-application")
        location = geolocator.geocode(address)
        detail_address = location.address
        latitude, longitude = location.latitude, location.longitude
    except Exception as e:
        #print(e)
        detail_address, latitude, longitude = "", "", ""
        return detail_address, latitude, longitude
    else:
        return detail_address, latitude, longitude


def parse_dict(input_dict=None, url=None):
    indv_dict = dict()
    if input_dict is None:
        return indv_dict
    else:
        print("#Ref:", input_dict['ref'])
        print("## input_dict ##", input_dict)
        for element in input_dict.keys():
            if element == "ref":
                indv_dict["ref"] = input_dict[element].replace(',', '-')
            elif "ref" not in indv_dict.keys():
                indv_dict["ref"] = ""

            if element == "price":
                indv_dict["price"] = input_dict[element]
            elif "price" not in indv_dict.keys():
                indv_dict["price"] = ""

            if element == "price_freq":
                indv_dict["price_freq"] = input_dict[element]
            elif "price_freq" not in indv_dict.keys():
                indv_dict["price_freq"] = ""

            if element == "beds":
                indv_dict["beds"] = input_dict[element]
            elif "beds" not in indv_dict.keys():
                indv_dict["beds"] = ""

            if element == "baths":
                indv_dict["baths"] = input_dict[element]
            elif "baths" not in indv_dict.keys():
                indv_dict["baths"] = ""

            if element == "pool":
                indv_dict["pools"] = input_dict[element]
            elif "pool" not in indv_dict.keys():
                indv_dict["pools"] = ""

            if element == "surface_area":
                if isinstance(input_dict[element], dict):
                    if input_dict[element].keys() is not None:
                        if "built" in input_dict[element]:
                            indv_dict["built"] = input_dict[element]["built"]
                        elif "plot" in input_dict[element]:
                            indv_dict["plot"] = input_dict[element]["plot"]
                    else:
                        indv_dict["built"] = ""
                        indv_dict["plot"] = ""
                else:
                    indv_dict["built"] = ""
                    indv_dict["plot"] = ""
            elif "surface_area" not in indv_dict.keys():
                indv_dict["built"] = ""
                indv_dict["plot"] = ""

            if element == "desc":
                if isinstance(input_dict[element], dict) and "en" in input_dict[element]:
                    indv_dict["desc"] = input_dict[element]["en"].replace(',', ';').replace('\n', '')
                else:
                    indv_dict["desc"] = ""
            elif "desc" not in indv_dict.keys():
                indv_dict["desc"] = ""

            if element == "images":
                if "image" in input_dict[element] and url in ['https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=aps&__company_serial=391', 'https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=kyr2&__company_serial=391']:
                    image_list = list()
                    if isinstance(input_dict[element]["image"], list):
                        for img_element in input_dict[element]["image"]:
                            image_info = {'image_name': img_element['title']['en'], 'image_url': img_element["url"]}
                            image_list.append(image_info["image_url"])
                        indv_dict["images"] = image_list
                    elif isinstance(input_dict[element]["image"], dict):
                        img_element = input_dict[element]["image"]
                        image_info = {'image_name': img_element['title']['en'], 'image_url': img_element["url"]}
                        image_list.append(image_info["image_url"])
                        indv_dict["images"] = image_list
                elif "image" in input_dict[element] and url in ['https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=kyr3&__company_serial=391', 'https://go.alphashare.com/3IGN4u=ZusJdS.feed']:
                    image_list = list()
                    if isinstance(input_dict[element]["image"], list):
                        for img_element in input_dict[element]["image"]:
                            image_info = {'image_url': img_element["url"]}
                            image_list.append(image_info["image_url"])
                        indv_dict["images"] = image_list
                    elif isinstance(input_dict[element]["image"], dict):
                        img_element = input_dict[element]["image"]
                        image_info = {'image_url': img_element["url"]}
                        image_list.append(image_info["image_url"])
                        indv_dict["images"] = image_list

            elif "images" not in indv_dict.keys():
                indv_dict["images"] = list()

            if element == "type" and url in ['https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=aps&__company_serial=391', 'https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=kyr2&__company_serial=391']:
                if "en" in input_dict[element] and len(input_dict[element]["en"]):
                    indv_dict["type"] = input_dict[element]["en"]
                else:
                    indv_dict["type"] = ""
            elif element == "type" and url in ['https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=kyr3&__company_serial=391', 'https://go.alphashare.com/3IGN4u=ZusJdS.feed']:
                indv_dict["type"] = input_dict[element]

            elif "type" not in indv_dict.keys():
                indv_dict["type"] = ""

            if "address" not in indv_dict:
                town = input_dict["town"]
                province = input_dict["province"]

                if len(town) or len(province):
                    if len(town):
                        formatted_addr = '{}'.format(town)
                    elif len(province):
                        formatted_addr = '{}'.format(province)
                    else:
                        formatted_addr = '{}, {}'.format(town, province)
                    #print(town, province)
                    print("formatted_address", formatted_addr)
                    address, lat, lng = find_lat_long(formatted_addr)
                    print("Address, Latitude and Longitude")
                    print(address, lat, lng)
                    indv_dict["address"] = address.replace(',', ' ')
                    indv_dict["latitude"] = lat
                    indv_dict["longitude"] = lng
                else:
                    indv_dict["address"] = ""
                    indv_dict["latitude"] = ""
                    indv_dict["longitude"] = ""

            if element == 'features':
                if isinstance(input_dict[element], dict):
                    keys = input_dict[element].keys()
                    if 'feature' in keys:
                        indv_dict['features'] = input_dict[element]['feature']
                    else:
                        indv_dict['features'] = []
                else:
                    indv_dict['features'] = []

            elif 'features' not in indv_dict:
                indv_dict['features'] = []

        return indv_dict


if __name__ == '__main__':
    expected_key_set = ['ref', 'price', 'price_freq', 'type', 'address', 'lat', 'long', 'beds', 'baths', 'pools',
                        'built', 'plot', 'desc', 'features', 'images']
    fp = open('solalbir_xml_properties.csv', 'w')
    w = csv.DictWriter(fp, expected_key_set)
    w.writeheader()
    url_list = ['https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=aps&__company_serial=391',
                'https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=kyr2&__company_serial=391',
                'https://go.alphashare.com/external/external.php?__method=external_xmlfeed&__feed=kyr3&__company_serial=391',
                'https://go.alphashare.com/3IGN4u=ZusJdS.feed'
                ]
    # Comment: URL_1, URL3

    for url in url_list:
        site = requests.get(url)
        value = site.text
        # accessing the desired list
        dict_items = xmltodict.parse(value)['root']['property']
        for dict_item in dict_items:
            json_str = json.dumps(dict_item)
            json_dict = json.loads(json_str)
            indv_result = parse_dict(json_dict, url=url)
            w.writerow({'ref': indv_result['ref'], 'price': indv_result['price'],
                        'price_freq': indv_result['price_freq'], 'type': indv_result['type'],
                        'address': indv_result['address'], 'lat': indv_result['latitude'],
                        'long': indv_result['longitude'], 'beds': indv_result['beds'], 'baths': indv_result['baths'],
                        'pools': indv_result['pools'], 'built': indv_result['built'], 'plot': indv_result['plot'],
                        'desc': indv_result['desc'],
                        'features': ';'.join(indv_result['features']),
                        'images': ';'.join(indv_result['images'])
                        })
            final_response.append(indv_result)

    print(final_response)
    fp.close()
