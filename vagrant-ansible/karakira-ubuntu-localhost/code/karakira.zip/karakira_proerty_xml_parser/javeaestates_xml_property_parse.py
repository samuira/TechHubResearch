import requests
import xmltodict
import json, re
import csv
from geopy.geocoders import Nominatim
from googlemaps import Client as GoogleMaps
#gmap_api_key = 'AIzaSyAN-T0GpRBmSzqAAx2n0W1GyZNfHy-wu7E'
modified_dict = dict()


def find_lat_long(address=None):
    try:
        geolocator = Nominatim(user_agent="my-application")
        location = geolocator.geocode(address)
        detail_address = location.address
        latitude, longitude = location.latitude, location.longitude
    except Exception as e:
        #print(e)
        detail_address, latitude, longitude = "", "", ""
        return detail_address, latitude, longitude
    else:
        return detail_address, latitude, longitude

# def find_lat_long(city_name):
#     gmaps = GoogleMaps(gmap_api_key)
#     try:
#         result = gmaps.geocode(city_name)
#         formatted_address = result[0]['formatted_address']
#         placemark = result[0]['geometry']
#     except Exception as e:
#         raise e
#     else:
#         lat = placemark['location']['lat']  # Note these are backwards from usual
#         lng = placemark['location']['lng']
#         return formatted_address, lat, lng


def parse_xml(json_dict=None):
    KEYS = list(json_dict.keys())
    print("KEYS: ", KEYS)
    if 'ref' in KEYS:
        modified_dict['ref'] = json_dict['ref']
    elif 'ref' not in KEYS:
        modified_dict['ref'] = ""

    if 'price' in KEYS:
        modified_dict['price'] = json_dict['price']
    elif 'price' not in KEYS:
        modified_dict['price'] = 0.0

    if 'price_freq' in KEYS:
        modified_dict['price_freq'] = json_dict['price_freq']
    elif 'price_freq' not in KEYS:
        modified_dict['price_freq'] = ""

    if 'type' in KEYS:
        modified_dict['type'] = json_dict['type']['en']
    elif 'type' not in KEYS:
        modified_dict['type'] = ""

    if 'town' in KEYS:
        try:
            formatted_address, lat, lng = find_lat_long(json_dict['town'])
            modified_dict['address'] = formatted_address.replace(',', ' ')
            modified_dict['lat'] = lat
            modified_dict['lng'] = lng
            #print(formatted_address, lat, lng)
        except Exception:
            modified_dict['address'] = ""
            modified_dict['lat'] = ""
            modified_dict['lng'] = ""

    elif 'town' not in KEYS:
        modified_dict['address'] = ""
        modified_dict['lat'] = ""
        modified_dict['lng'] = ""

    if 'beds' in KEYS:
        modified_dict['beds'] = json_dict['beds']
    elif 'beds' not in KEYS:
        modified_dict['beds'] = 0

    if 'baths' in KEYS:
        modified_dict['baths'] = json_dict['baths']
    elif 'baths' not in KEYS:
        modified_dict['baths'] = 0

    if 'pools' in KEYS:
        modified_dict['pools'] = json_dict['pools']
    elif 'pools' not in KEYS:
        modified_dict['pools'] = 0

    if 'surface_area' in KEYS:
        keys = json_dict['surface_area'].keys()
        if 'build' in keys:
            modified_dict['build'] = json_dict['surface_area']['build']
        else:
            modified_dict['build'] = 0
        if 'plot' in keys:
            modified_dict['plot'] = json_dict['surface_area']['plot']
        else:
            modified_dict['plot'] = 0
    elif 'surface_area' not in KEYS:
        modified_dict['build'] = 0
        modified_dict['plot'] = 0

    if 'features' in KEYS:
        if isinstance(json_dict['features'], dict):
            keys = json_dict['features'].keys()
            if 'feature' in keys:
                modified_dict['features'] = json_dict['features']['feature']
            else:
                modified_dict['features'] = []
        else:
            modified_dict['features'] = []
    elif 'features' not in KEYS:
        modified_dict['features'] = []

    if 'images' in KEYS:
        image_list = list()
        keys = json_dict['images'].keys()
        if 'image' in keys:
            for item in json_dict['images']['image']:
                KEYS_1 = item.keys()
                if 'url' in KEYS_1:
                    image_list.append(item['url'])
                else:
                    pass
            modified_dict['image_list'] = image_list
        else:
            modified_dict['image_list'] = image_list
    elif 'images' not in KEYS:
        modified_dict['features'] = []

    # if 'desc' in KEYS:
    #     # desc = re.search('English:([A-Z|a-z| \,\.\/\-])+', json_dict['desc']['en'])
    #     desc = json_dict['desc']['en'].replace(',', ';').replace('\n', '')
    #     # if desc.find('English - Español - Deutsch - Français English '):
    #     #     print("I am here 1")
    #     #     modified_dict['desc'] = desc.replace('English - Español - Deutsch - Français English ', '')
    #     # elif desc.find('English – Español – Deutsch – Français  English: '):
    #     #     print("I am here 2")
    #     #     modified_dict['desc'] = desc.replace('English - Español - Deutsch - Français English: ', '')
    #     # else:
    #     modified_dict['desc'] = desc
    #     #modified_dict['desc'] = desc.group(0).split(':')[1]
    # elif 'desc' not in KEYS:
    #     modified_dict['desc'] = ""
    modified_dict['desc'] = ""


if __name__ == '__main__':
    # Writing data into CSV
    expected_key_set = ['ref', 'price', 'price_freq', 'type', 'address', 'lat', 'long', 'beds', 'baths', 'pools',
                        'built', 'plot', 'desc', 'features', 'images']
    fp = open('javeaestates_xml_properties.csv', 'w')
    w = csv.DictWriter(fp, expected_key_set)
    w.writeheader()
    url = 'http://javeaestates.com/index.php?option=com_iproperty&view=feed&layout=kyero-sales-direct&format=xml'
    site = requests.get(url)
    value = site.text
    new_val = value[value.find('<property'): value.find('<property')]

    # accessing the desired list
    dict_items = xmltodict.parse(value)['root']['property']
    result_list = list()
    for dict_item in dict_items:
        json_str = json.dumps(dict_item)
        json_dict = json.loads(json_str)
        parse_xml(json_dict=json_dict)
        w.writerow({'ref': modified_dict['ref'], 'price': modified_dict['price'],
                    'price_freq': modified_dict['price_freq'], 'type': modified_dict['type'],
                    'address': modified_dict['address'], 'lat': modified_dict['lat'],
                    'long': modified_dict['lng'], 'beds': modified_dict['beds'], 'baths': modified_dict['baths'],
                    'pools': modified_dict['pools'], 'built': modified_dict['build'], 'plot': modified_dict['plot'],
                    'desc': modified_dict['desc'],
                    'features': ';'.join(modified_dict['features']),
                    'images': ';'.join(modified_dict['image_list'])
                    })
        result_list.append(modified_dict)
    print(result_list)
    fp.close()
