import time
import datetime
import socket
import json
from django.views.decorators.clickjacking import xframe_options_exempt
from django.utils.decorators import method_decorator
from django.views import generic
from django.http import HttpResponse
from django.shortcuts import (render, render_to_response, redirect, get_object_or_404)
from django.core.mail import (send_mail, BadHeaderError)
from django.core.exceptions import ObjectDoesNotExist
from django.template import RequestContext
from django.conf import settings
from django.db.models import (Q, Count)

from blog.models import *
from blog.forms import ContactForm
from blog.utils.paginator import GenericPaginator

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .models import MyComments

def handler400(request):
    response = render_to_response('error_page.html', {'title': '400 Bad Request', 'message': '400'},
                                  context_instance=RequestContext(request))
    response.status_code = 400
    return response


def handler403(request):
    response = render_to_response('error_page.html', {'title': '403 Permission Denied', 'message': '403'},
                                  context_instance=RequestContext(request))
    response.status_code = 403
    return response


def handler404(request):
    response = render_to_response('error_page.html', {'title': '404 Not Found', 'message': '404'},
                                  context_instance=RequestContext(request))
    response.status_code = 404
    return response


def handler500(request):
    response = render_to_response('error_page.html', {'title': '500 Server Error', 'message': '500'},
                                  context_instance=RequestContext(request))
    response.status_code = 500
    return response


@method_decorator(xframe_options_exempt, name='dispatch')
class HomepageView(generic.ListView):
    queryset = Post.objects.published()
    template_name = 'blog/blog_home.html'
    paginate_by = 10
    
    def get_context_data(self, **kwargs):  # Used for transfering any context data to template for doing any operation from front end.
        context_data = super(HomepageView, self).get_context_data(**kwargs)
        ##################
        results = list(MyComments.objects.all())[:5]
        print(results)
        L = list()
        for comment in results:
            d = {"Author":comment.commenter_name, "Comment":comment.comment_text, "Avatar":json.dumps("/media/"+str(comment.avatar))}
            L.append(d)
        #context = dict()
        #context["Comments"] = L
        #print(context)
        
        
        ######################
        context_data["Comments"] = L
        context_data['page_range'] = GenericPaginator(
            self.queryset,
            self.paginate_by,
            self.request.GET.get('page')
        ).get_page_range()
        # print(context_data)
        context = context_data
        return context


@method_decorator(xframe_options_exempt, name='dispatch')
class DetailPostView(generic.DetailView):
    model = Post
    template_name = 'blog/blog_detail.html'

    def get_client_ip(self):
        ip = self.request.META.get("HTTP_X_FORWARDED_FOR", None)
        if ip:
            ip = ip.split(", ")[0]
        else:
            ip = self.request.META.get("REMOTE_ADDR", "")
        return ip

    def visitorCounter(self):
        try:
            Visitor.objects.get(
                post=self.object, # title of the post as per __str__()
                ip=self.request.META['REMOTE_ADDR'] # if 127.0.0.1 
            )
        except ObjectDoesNotExist:
            dns = str(socket.getfqdn(
                self.request.META['REMOTE_ADDR']
            )).split('.')[-1]
            try:
                # trying for localhost: str(dns) == 'localhost',
                # trying for production: int(dns)
                if str(dns) == 'localhost':
                    visitor = Visitor(
                        post=self.object,
                        ip=self.request.META['REMOTE_ADDR'] # if localhost
                    )
                    visitor.save()
                else:
                    pass
            except ValueError:
                pass
        return Visitor.objects.filter(post=self.object).count()

    def dispatch(self, request, *args, **kwargs):
        obj = self.get_object() # Object of Post()
        if obj.publish == False:
            if request.user.is_anonymous() or \
                    request.user != obj.author.user:
                return redirect('homepage')
            else:
                return super(DetailPostView, self).dispatch(
                    request, *args, **kwargs
                )
        elif request.GET.get('format') == 'json':
            get_cover = lambda obj: None if obj.cover == None \
                or obj.cover == '' \
                else 'https://{0}{1}{2}'.format(
                    request.get_host(),
                    settings.MEDIA_URL,
                    obj.cover
                )
            data = dict(
                title=obj.title,
                url='https://{0}/blog/{1}'.format(
                    request.get_host(),
                    obj.slug
                ),
                cover=get_cover(obj),
                author=obj.author.user.username,
                created=str(obj.created)[:19],
                modified=str(obj.modified)[:19],
                tags=[
                    {'title': t.title, 'slug': t.slug}
                    for t in obj.tags.all()
                ],
                description=obj.description,
                visitors=obj.total_visitors
            )
            return HttpResponse(
                json.dumps(data),
                content_type='application/json'
            )
        else:
            return super(DetailPostView, self).dispatch(
                request, *args, **kwargs
            )

    def get_context_data(self, **kwargs):
        context_data = super(DetailPostView, self).get_context_data(**kwargs)
        related_posts = Post.objects.filter(
            tags__in=list(self.object.tags.all())
        ).exclude(id=self.object.id).distinct()    # Check related blog posts based on tag name.
        context_data['related_posts'] = related_posts[:5]  # limit for post
        context_data['get_client_ip'] = self.get_client_ip()
        context_data['visitor_counter'] = self.visitorCounter()
        return context_data


@method_decorator(xframe_options_exempt, name='dispatch')
class SearchPostsView(generic.ListView): # Search blog post based on title, description, keywords and meta_description
    template_name = 'blog/blog_search.html'
    paginate_by = 10
	# imp link on get_queryset() and/or get_context_data() in Django (https://stackoverflow.com/questions/25277099/how-to-define-get-queryset-get-context-data-in-a-django-view)
	
    def get_queryset(self):
        self.query = self.request.GET.get('q')
        try:
            search_posts = Post.objects.published().filter(
				Q(tags__icontains=self.query) |
                Q(title__icontains=self.query) |
                Q(description__icontains=self.query) |
                Q(keywords__icontains=self.query) |
                Q(meta_description__icontains=self.query) 
            ).order_by('-created').order_by('-id')
            return search_posts
        except:
            return Post.objects.published()

    def get_context_data(self, **kwargs):
        context_data = super(SearchPostsView, self).get_context_data(**kwargs)
        context_data['query'] = self.query
        context_data['page_range'] = GenericPaginator(
            self.get_queryset(),
            self.paginate_by,
            self.request.GET.get('page')
        ).get_page_range()
        return context_data


@method_decorator(xframe_options_exempt, name='dispatch')
class AuthorPostsView(generic.ListView):
    template_name = 'blog/blog_posts_author.html'
    paginate_by = 10

    def get_queryset(self):
        username = self.kwargs['username']
        self.author = get_object_or_404(Author, user__username=username)
        posts_author = Post.objects.published().filter(
            author=self.author
        ).order_by('-created').order_by('-id')
        return posts_author

    def get_context_data(self, **kwargs):
        context_data = super(AuthorPostsView, self).get_context_data(**kwargs) # Due to override it gets context_data['post_author'] data as context for template
        context_data['author'] = self.author # get author details in context
        context_data['page_range'] = GenericPaginator(
            self.get_queryset(),
            self.paginate_by,
            self.request.GET.get('page')
        ).get_page_range() 
        return context_data


@method_decorator(xframe_options_exempt, name='dispatch')
class TagPostsView(generic.ListView):
    template_name = 'blog/blog_posts_tag.html'
    paginate_by = 10

    def get_queryset(self):
        slug = self.kwargs['slug']
        self.tag = get_object_or_404(Tag, slug=slug)
        results_filter = Post.objects.published().filter(
            tags=self.tag
        ).order_by('-created').order_by('-id')
        return results_filter

    def get_context_data(self, **kwargs):
        context_data = super(TagPostsView, self).get_context_data(**kwargs)
        context_data['tag'] = self.tag
        context_data['page_range'] = GenericPaginator(
            self.get_queryset(),
            self.paginate_by,
            self.request.GET.get('page')
        ).get_page_range()
        return context_data


@method_decorator(xframe_options_exempt, name='dispatch')
class DetailPageView(generic.DetailView):
    model = Page
    template_name = 'blog/blog_page.html'


@method_decorator(xframe_options_exempt, name='dispatch')
class SitemapView(generic.ListView):
    queryset = Post.objects.published()
    template_name = 'blog/blog_sitemap.html'
    paginate_by = 30

    def get_context_data(self, **kwargs):
        context_data = super(SitemapView, self).get_context_data(**kwargs)
        context_data['page_range'] = GenericPaginator(
            self.queryset,
            self.paginate_by,
            self.request.GET.get('page')
        ).get_page_range()
        return context_data


@method_decorator(xframe_options_exempt, name='dispatch')
class ContactView(generic.TemplateView):
    template_name = 'blog/blog_contact.html'

    def post(self, request, *args, **kwargs):
        context = self.get_context_data()
        if context['form'].is_valid():
            cd = context['form'].cleaned_data
            subject = cd['subject']
            from_email = cd['email']
            message = cd['message']

            try:
                send_mail(
                    subject + " from {}".format(from_email),
                    message,
                    from_email,
                    [settings.EMAIL_HOST_USER]
                )
            except BadHeaderError:
                return HttpResponse('Invalid header found.')

            ctx = {
                'success': """Thankyou, We appreciate that you've
                taken the time to write us.
                We'll get back to you very soon.
                Please come back and see us often."""
            }
            return render(request, self.template_name, ctx)
        return super(generic.TemplateView, self).render_to_response(context)

    def get_context_data(self, **kwargs):
        context = super(ContactView, self).get_context_data(**kwargs)
        form = ContactForm(self.request.POST or None)
        context['form'] = form
        return context


@method_decorator(xframe_options_exempt, name='dispatch')
class TrendingPostsView(generic.ListView):
    template_name = 'blog/blog_trending_posts.html'

    def get_queryset(self):
        posts = Post.objects.published()
        top_posts = Visitor.objects.filter(post__in=posts)\
            .values('post').annotate(visit=Count('post__id'))\
            .order_by('-visit')

        list_pk_top_posts = [pk['post'] for pk in top_posts]
        print(list_pk_top_posts)
        filter_posts = list(Post.objects.published().filter(pk__in=list_pk_top_posts))  # Blog posts (published) those are visited by visitor
        sorted_posts = sorted(filter_posts, key=lambda i: list_pk_top_posts.index(i.pk))

        self.get_filter = self.request.GET.get('filter')
        now_year = time.strftime("%Y")
        now_month = time.strftime("%m")
        now_date = datetime.date.today()
        start_week = now_date - datetime.timedelta(7)
        end_week = start_week + datetime.timedelta(7) # week range is of +/- 7 days of current date.

        if self.get_filter == 'week':
            filter_posts = list(Post.objects.published().filter(pk__in=list_pk_top_posts))
            filter_posts_week = list()
            for post in filter_posts: 
	            created_val = post.created.date()
	            if start_week <= created_val <= end_week:
		            filter_posts_week.append(post) 
            print(filter_posts_week)
            sorted_posts = sorted(filter_posts_week, reverse=True, key = lambda post : (post.created.date(), filter_posts_week))
            #sorted_posts = sorted(filter_posts_week, key=lambda i: list_pk_top_posts.index(i.pk))
            
		
        elif self.get_filter == 'month':
            filter_posts = list(Post.objects.published().filter(pk__in=list_pk_top_posts))
            filter_posts_month = list()
            for post in filter_posts:
                created_val = post.created.date()
                if str(created_val.year) == now_year and str(created_val.month) == now_month:
                    filter_posts_month.append(post)
            sorted_posts = sorted(filter_posts_month, reverse=True, key = lambda post : (post.created.date().month, filter_posts_month))
            #sorted_posts = sorted(filter_posts_month, key=lambda i: list_pk_top_posts.index(i.pk))

        elif self.get_filter == 'year':
            filter_posts = list(Post.objects.published().filter(pk__in=list_pk_top_posts))
            filter_posts_year = list()
            for post in filter_posts:
                created_val = post.created.date()
                if str(created_val.year) == now_year:
                    filter_posts_year.append(post)
            sorted_posts = sorted(filter_posts_year, reverse=True, key = lambda post : (post.created.date().year, filter_posts_year))
            #sorted_posts = sorted(filter_posts_year, key=lambda i: list_pk_top_posts.index(i.pk))

        else:
            self.get_filter == 'global'
            latest_posts = sorted_posts
            sorted_posts = sorted(latest_posts, reverse=True, key = lambda post : (post.created.date(), latest_posts))
        return sorted_posts[:20]  # Return 20 posts only

    def get_context_data(self, **kwargs):
        context_data = super(TrendingPostsView, self).get_context_data(**kwargs)
        context_data['filter'] = self.get_filter
        return context_data

@csrf_exempt
def AddComment(request,slug=None):
	if request.method == 'POST':
		slug_val = request.POST.get('slug')
		comment_body = request.POST.get('comment')
		#result = Post.objects.get(slug=slug_val)
		#print(result,type(result))
		#result.created = datetime.datetime.now()
		#result.modified = datetime.datetime.now()
		#result.comment_text = comment_body
		commenter_name = User.objects.filter(id=request.user.id).values()[0]["username"]
		commenter_pic = Author.objects.get(user_id=request.user.id).avatar
		#print(commenter_pic)
		comment_obj = MyComments(slug_txt=slug_val,comment_text = comment_body,commenter_name=commenter_name,avatar=commenter_pic)
		comment_obj.save()
		#author_name = User.objects.filter(id=result.author_id).values()[0]["username"]
		#print(author_name)
		context = {'slug':slug_val,'comment':comment_body,'commenter_name':commenter_name,'commenter_pic':json.dumps("/media/"+str(commenter_pic))}
		#del(commentor_list)
		return JsonResponse(context)
		
@csrf_exempt
def LoadComment(request,slug=None):
	if request.method == 'GET':
		slug_val = request.GET.get('slug')
		#post_detail = Post.objects.filter(slug=slug_val).values()
		#print(post_detail)
		results = list(MyComments.objects.filter(slug_txt=slug_val))[:5]
		#print(results)
		L = list()
		for comment in results:
			#post_author_id = Post.objects.filter(id=comment.post_id).values()[0]['author_id']
			#print(request.user.get)
			#author_name = User.objects.filter(id=request.user.id).values()[0]["username"]
			d = {"Author":comment.commenter_name, "Comment":comment.comment_text, "Avatar":json.dumps("/media/"+str(comment.avatar))}
			L.append(d)
		#print(L)
		context = {"Comments":L}
		#del(commentor_list)
		return JsonResponse(context)

@csrf_exempt   
def LoadRecentComment(request,slug=None):
	if request.method == 'GET':
		slug_val = request.GET.get('slug')
		print(type(slug_val))
		if slug_val:
			results = list(MyComments.objects.filter(slug_txt=slug_val))[:5]
			print(results)
			L = list()
			for comment in results:
				d = {"Author":comment.commenter_name, "Comment":comment.comment_text, "Avatar":json.dumps("/media/"+str(comment.avatar))}
				L.append(d)
			
			context = {"Comments":L}
			print(context)
			return JsonResponse(context)
		
@csrf_exempt   
def HomeRecentComment(request,slug=None):
	results = list(MyComments.objects.all())[:5]
	print(results)
	L = list()
	for comment in results:
		d = {"Author":comment.commenter_name, "Comment":comment.comment_text, "Avatar":json.dumps("/media/"+str(comment.avatar))}
		L.append(d)
	context = {"Comments":L}
	print(context)
	return JsonResponse(context)		
	   

 
