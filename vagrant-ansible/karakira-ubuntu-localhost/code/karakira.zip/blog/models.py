from uuid import uuid4
from django.db import models
from django.utils import timezone
from site_user.models import User
from django.core.urlresolvers import reverse
from ckeditor.fields import RichTextField
from redactor.fields import RedactorField
from django.utils.text import slugify
import os
from django.conf import settings
from django.db.models import Q

def xstr(s):
    return '' if s is None else str(s)

# format('%Y-%m-%d %I:%M %p'),
class TimeStampedModel(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Author(models.Model):
    user = models.OneToOneField(User, related_name='author')  # An Author is a user.
    # But here, a limitation is a single user plays role of two authors.
    # avatar = models.ImageField(upload_to='gallery/avatar/%Y/%m/%d',
    #                            null=True,
    #                            blank=True,
    #                            help_text="Upload your photo for Avatar")  # picture of an Author
    # Here, we consider avatar of user.
    about = models.TextField(blank=True)  # Details of an Author
    website = models.URLField(max_length=200, blank=True, null=True)  # Website of an Author

    def __str__(self):
        return self.user.username + "user id"+ str(self.user.id)

    # def get_absolute_url(self):  # When we click Author's username (href link) then
    #     # redirect to blogs for that Author (author/(?P<username>[\w\-]+)/)
    #     return reverse('author_posts_page',
    #                    kwargs={'username': self.user.username})

    class Meta:
        verbose_name = 'Detail Author'
        verbose_name_plural = 'Authors'


class Tag(models.Model):
    title = models.CharField(max_length=200)  # Title for Tag (like: OOPs, Exception handling, I/O files etc.)
    slug = models.SlugField(max_length=200, unique=True, default="")  # slug for title

    def __str__(self):
        return self.title

    @property
    def get_total_posts(self):  # due to @property we use Tag model obj.get_total_posts
        # instead of Tag model obj.get_total_posts()
        return Post.objects.filter(tags__pk=self.pk).count()

    def get_post(self):  # Get blogs where this tag is used
        return Post.objects.filter(tags__pk=self.pk)

    def save(self, *args, **kwargs):
        if not self.id:
            # Newly created object, so set slug
            self.slug = slugify(self.title)
        super(Tag, self).save(*args, **kwargs)

    class Meta:
        verbose_name = 'Detail Tag'
        verbose_name_plural = 'Tags'


class PostQuerySet(models.QuerySet):

    def published(self):
        return self.filter(publish=True)


def blog_image(instance, filename):
    upload_to = 'static/media/blog'
    ext = filename.split('.')[-1]
    # get filename
    if instance.slug:
        f_name = str(instance.slug)+str("something")
        filename = '{}.{}'.format(f_name, ext)
    else:
        # set filename as random string
        filename = '{}.{}'.format(uuid4().hex, ext)
    # return the whole path to the file
    return os.path.join(upload_to, filename)


class Post(TimeStampedModel):  # TimeStampedModel is used to get creation and modification time of post
    author = models.ForeignKey(Author, related_name='author_post')  # Author info
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    cover = models.ImageField(upload_to=blog_image,
                              null=True, blank=True, max_length=1000)

    # cover = models.ImageField(upload_to='gallery/covers/%Y/%m/%d',
    #                           null=True,
    #                           blank=True,
    #                           help_text='Optional cover post')
    description = models.TextField(blank=True)   # Same as ckeditor
    tags = models.ManyToManyField('Tag')  # Tag for blog post
    keywords = models.CharField(max_length=200, null=True, blank=True,
                                help_text='Keywords sparate by comma.')
    meta_description = models.TextField(null=True, blank=True)

    publish = models.BooleanField(default=True)
    objects = PostQuerySet.as_manager()

    def get_absolute_url(self):  # When we click Post title (href link) then redirect to blogs for
        # that Author (blog/(?P<slug>[\w\-]+)/)
        return reverse('detail_post_page', kwargs={'slug': self.slug})

    @property
    def total_visitors(self):  # due to @property we use Post model obj.total_visitors instead of Tag model
        # obj.total_visitors()
        return Visitor.objects.filter(post__pk=self.pk).count()

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.id:
            # Newly created object, so set slug
            self.slug = slugify(self.title)
        super(Post, self).save(*args, **kwargs)

    def getImageUrl(self, request):
        return '' if xstr(self.cover) is '' else settings.PROTOCOL + "://" + request.META['HTTP_HOST'] + "/" \
                                                 + xstr(self.cover)

    def isPublished(self):
        status = self.publish
        if status:
            return True
        else:
            return False

    def getTags(self):
        tagList = list()
        for t in self.tags.all():
            tagList.append(t.slug)
        print(tagList)
        return tagList

    def getComments(self, request):
        comments = MyComments.objects.filter(slug_txt=self.slug)[:5]
        comments_list = list()
        for c in comments:
            comments_list.append({'Commentor': c.user.id,
                                  'Commentor_image': c.user.getImageUrl(request),
                                  'Comment': c.comment_text,
                                  'Comment_date': c.created,
                                  })
        return comments_list

    def getRelatedPosts(self):
        post_set = set()
        posts = Post.objects.filter(~Q(id=self.id))
        if posts.exists():
            for p in posts:
                temp_set = set(self.tags.all()).intersection(set(p.tags.all()))
                if len(temp_set):
                    post_set.add(p.slug)
                    del temp_set
        return post_set

    def getVisitHistory(self, ip):
        obj, created = Visitor.objects.get_or_create(post=self, ip=ip)
        if obj:
            obj.nvisit += 1
            obj.save()
        history = {"IP Address": obj.ip, "no. of visit": obj.nvisit}
        return history

    class Meta:
        verbose_name = 'Detail Post'
        verbose_name_plural = 'Posts'
        ordering = ["-created"]


class Page(TimeStampedModel):  # TimeStampedModel is used to get creation and modification time of page.
    author = models.ForeignKey(Author, related_name='author_page')
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    description = models.TextField(blank=True)  # Same as ckeditor
    publish = models.BooleanField(default=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.id:
            # Newly created object, so set slug
            self.slug = slugify(self.title)
        super(Page, self).save(*args, **kwargs)

    # this will be an error in /admin
    # def get_absolute_url(self):
    #    return reverse("page_detail", kwargs={"slug": self.slug})

    class Meta:
        verbose_name = "Detail Page"
        verbose_name_plural = "Pages"
        ordering = ["-created"]


class Gallery(TimeStampedModel):
    title = models.CharField(max_length=200)
    attachment = models.FileField(upload_to='gallery/attachment/%Y/%m/%d')

    def __str__(self):
        return self.title

    def check_if_image(self):
        if self.attachment.name.split('.')[-1].lower() \
                in ['jpg', 'jpeg', 'gif', 'png']:
            return '<img height="40" width="60" src="%s"/>' % self.attachment.url
        return '<img height="40" width="60" src="/static/assets/icons/file-icon.png"/>'
    check_if_image.short_description = 'Attachment'
    check_if_image.allow_tags = True

    class Meta:
        verbose_name = 'Detail Gallery'
        verbose_name_plural = 'Galleries'
        ordering = ['-created']


class Visitor(TimeStampedModel):
    post = models.ForeignKey(Post, related_name='post_visitor')
    ip = models.CharField(max_length=40)
    nvisit = models.IntegerField(default=0)

    def __str__(self):
        return self.post.title

    class Meta:
        verbose_name = 'Detail Visitor'
        verbose_name_plural = 'Visitors'
        ordering = ['-created']


class MyComments(TimeStampedModel):
    slug_txt = models.SlugField(max_length=200, default="")
    comment_text = models.TextField(blank=True)
    user = models.ForeignKey(User, related_name='commentor_user', null=True, default="")


    def __str__(self):
        return self.slug_txt + ": with comment:: "+str(self.comment_text)

    # def save(self, *args, **kwargs):
    #     if not self.id:
    #         # Newly created object, so set slug
    #         self.slug_txt = slugify(self.user.id)
    #     super(MyComments, self).save(*args, **kwargs)

    class Meta:
        db_table = 'my_comments'
        verbose_name = 'Detail Comment'
        verbose_name_plural = 'Commentors'
        ordering = ['-created']
