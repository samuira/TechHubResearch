from django.contrib.syndication.views import Feed
from django.utils.feedgenerator import Rss201rev2Feed
from django.core.urlresolvers import reverse
from blog.models import Post
from django.conf import settings

class CorrectMimeTypeFeed(Rss201rev2Feed):
    mime_type = 'application/xml'


class LatestPosts(Feed):
    feed_type = CorrectMimeTypeFeed

    title = "Feed Blog Posts"
    
    link = '/feed/' 
    description = "Latest Feed Blog Posts"



    def items(self):
        return Post.objects.published()[:10]

    def item_title(self, item):
	    print(item)
	    print(item.title)
	    return item.title

    def item_description(self, item):
	    print(item.description)
	    return item.description

    def item_author_name(self, item):
        print(item.author)
        return item.author

    def item_link(self, item):
	    print(item.get_absolute_url())
	    #return reverse('comment', args=[item.slug]) # kwargs = {'object_pk':item.pk} args=[item.slug]
	    return reverse('detail_post_page', kwargs={'slug':item.slug}) # kwargs = {'object_pk':item.pk} args=[item.slug]
        
		
    def item_pubdate(self, item):
        return item.modified
