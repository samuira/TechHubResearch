from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^national_price_tally$', views.national_price_tally_details, name='national_price_tally'),  # (OK)
    url(r'^price_range$', views.price_range_details, name='price_range'),  # (OK)
    url(r'^property_discounts$', views.property_discounts_details, name='property_discounts'),  # (OK)
    url(r'^property_price_stats$', views.property_price_stats_details, name='property_price_stats'),  # (OK)
    url(r'^history_user_stats$', views.history_user_stats_details, name='history_user_stats'),  # ( Not OK)
    url(r'^history_property_search$', views.history_property_search_details, name='history_property_search'),  # (OK)
    url(r'^visitor_stats$', views.visitor_stats_details, name='visitor_stats'),  # (OK)
    url(r'^call_to_action$', views.call_to_action_details, name='call_to_action'),  # (OK)
    url(r'^average_search_time$', views.average_search_time_details, name='call_to_action'),  # (OK)

    url(r'^insight/bercelona$', views.bercelona_insights_details, name='insight_bercelona'),  # (OK)
    url(r'^insight/madrid$', views.madrid_insights_details, name='insight_madrid'),  # (OK)
    url(r'^insight/seville$', views.seville_insights_details, name='insight_seville'),  # (OK)
    url(r'^insight/spain$', views.spain_insights_details, name='insight_spain'),  # (OK)
    url(r'^insight/valencia$', views.valencia_insights_details, name='insight_valencia'),  # (OK)
]
