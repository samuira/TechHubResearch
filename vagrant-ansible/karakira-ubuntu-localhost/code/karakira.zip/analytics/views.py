from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt
from django.conf import settings
# Create your views here.


@xframe_options_exempt
def national_price_tally_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'nationalprice.html', context)


@xframe_options_exempt
def price_range_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'price_range.html', context)


@xframe_options_exempt
def property_discounts_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'pricediscount.html', context)

@xframe_options_exempt
def property_price_stats_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'property_price_stats_static.html', context)

@xframe_options_exempt
def history_user_stats_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'historyuserstatus.html', context)


@xframe_options_exempt
def history_property_search_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'historypropertysearch.html', context)


@xframe_options_exempt
def visitor_stats_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'visitorstatus.html', context)


@xframe_options_exempt
def call_to_action_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'call_to_action_static.html', context)


@xframe_options_exempt
def average_search_time_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'averagesearchtime.html', context)


@xframe_options_exempt
def bercelona_insights_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'bercelona_insight.html', context)


@xframe_options_exempt
def madrid_insights_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'madrid_insight.html', context)


@xframe_options_exempt
def seville_insights_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'seville_insight.html', context)


@xframe_options_exempt
def spain_insights_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'spain_insight.html', context)


@xframe_options_exempt
def valencia_insights_details(request):
    settings.BASE_URL = request.get_host()
    context = {
        'baseUrl': settings.BASE_URL,
        #'token': request.GET['token']
    }
    # print(context)
    return render(request, 'valencia_insight.html', context)

