from django import forms
from .models import Country,State,City,Entity,Language,Currency

class CountryFormAdmin(forms.ModelForm):
	"""docstring for CountryFormAdmin"""
	def __init__(self, *args, **kwargs):
		super(CountryFormAdmin, self).__init__(*args,**kwargs)
	class Meta:
		model = Country
		exclude = ('entityId','langId','createdDate','createdBy','updatedDate','updatedBy','isDeleted')

class StateFormAdmin(forms.ModelForm):
	"""docstring for StateFormAdmin"""
	def __init__(self, *args, **kwargs):
		super(StateFormAdmin, self).__init__(*args,**kwargs)
	class Meta:
		model = State
		exclude = ('entityId','langId','createdDate','createdBy','updatedDate','updatedBy','isDeleted')

class CityFormAdmin(forms.ModelForm):
	"""docstring for CityFormAdmin"""
	def __init__(self, *args, **kwargs):
		super(CityFormAdmin, self).__init__(*args,**kwargs)
	class Meta:
		model = City
		exclude = ('entityId','langId','createdDate','createdBy','updatedDate','updatedBy','isDeleted')

class EntityFormAdmin(forms.ModelForm):
	"""docstring for EntityFormAdmin"""
	def __init__(self, *args, **kwargs):
		super(EntityFormAdmin, self).__init__(*args,**kwargs)
	class Meta:
		model = Entity
		exclude = ('createdDate','createdBy','updatedDate','updatedBy','isDeleted')

class LanguageFormAdmin(forms.ModelForm):
	"""docstring for LanguageFormAdmin"""
	def __init__(self, *args, **kwargs):
		super(LanguageFormAdmin, self).__init__(*args,**kwargs)
	class Meta:
		model = Language
		exclude = ('createdDate','createdBy','updatedDate','updatedBy','isDeleted')

class CurrencyFormAdmin(forms.ModelForm):
	"""docstring for CurrencyFormAdmin"""
	def __init__(self, *args, **kwargs):
		super(CurrencyFormAdmin, self).__init__(*args,**kwargs)
	class Meta:
		model = Currency
		exclude = ('createdDate','createdBy','updatedDate','updatedBy','isDeleted')
