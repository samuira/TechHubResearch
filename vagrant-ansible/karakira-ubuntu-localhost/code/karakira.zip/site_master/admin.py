# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Entity, Language, Country, State, City, Currency
from .forms import CountryFormAdmin,StateFormAdmin,CityFormAdmin,EntityFormAdmin,LanguageFormAdmin,CurrencyFormAdmin
# Register your models here.

class EntityAdmin(admin.ModelAdmin): 
	list_display = ('name',)
	list_per_page = 25
	#list_filter = ('state',)
	search_fields = ['name','code','state']
	sortable_field_name = "name"
   
	form = EntityFormAdmin
	def save_model(self, request, obj, form, change):
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id			
		else :	
			obj.updatedBy_id = request.user.id			
		obj.save()

	actions = ['delete_selected']
	def delete_selected(self, request, obj):
		for o in obj.all():
			o.isDeleted = True
			o.save()
	delete_selected.short_description = 'Delete selected'


class LanguageAdmin(admin.ModelAdmin):
	list_display = ('name','code')
	list_per_page = 25
	#list_filter = ('state',)
	search_fields = ['name','code']
	sortable_field_name = "name","code"
   
	form = LanguageFormAdmin
	def save_model(self, request, obj, form, change):
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id		
		else :			
			obj.updatedBy_id = request.user.id			
		obj.save()

	actions = ['delete_selected']
	def delete_selected(self, request, obj):
		for o in obj.all():
			o.isDeleted = True
			o.save()
	delete_selected.short_description = 'Delete selected'


class CountryAdmin(admin.ModelAdmin):	 
	list_display = ('title','code')
	list_per_page = 25
	#list_filter = ('status',)
	search_fields = ['title','code']
	sortable_field_name = "title","code"
   
	form = CountryFormAdmin
	def save_model(self, request, obj, form, change):
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
			obj.entityId_id  = 1
			obj.langId_id	 = 1
		else :
			obj.entityId_id  = 1
			obj.updatedBy_id = request.user.id
			obj.langId_id	  = 1
		obj.save()

	actions = ['delete_selected']
	def delete_selected(self, request, obj):
		for o in obj.all():
			o.isDeleted = True
			o.save()
	delete_selected.short_description = 'Delete selected'


class StateAdmin(admin.ModelAdmin):	 
	list_display = ('title','code','country')
	list_per_page = 25
	#list_filter = ('country',)
	search_fields = ['title','code','country']
	sortable_field_name = "title","code","country"
   
	form = StateFormAdmin
	def save_model(self, request, obj, form, change):
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
			obj.entityId_id  = 1
			obj.langId_id	 = 1
		else :
			obj.entityId_id  = 1
			obj.updatedBy_id = request.user.id
			obj.langId_id	  = 1
		obj.save()

	actions = ['delete_selected']
	def delete_selected(self, request, obj):
		for o in obj.all():
			o.isDeleted = True
			o.save()
	delete_selected.short_description = 'Delete selected'


class CityAdmin(admin.ModelAdmin):	 
	list_display = ('title','code','state')
	list_per_page = 25
	#list_filter = ('state',)
	search_fields = ['title','code','state']
	sortable_field_name = "title","code","state"
   
	form = CityFormAdmin
	def save_model(self, request, obj, form, change):
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
			obj.entityId_id  = 1
			obj.langId_id	 = 1
		else :
			obj.entityId_id  = 1
			obj.updatedBy_id = request.user.id
			obj.langId_id	  = 1
		obj.save()

	actions = ['delete_selected']
	def delete_selected(self, request, obj):
		for o in obj.all():
			o.isDeleted = True
			o.save()
	delete_selected.short_description = 'Delete selected'

class CurrencyAdmin(admin.ModelAdmin):	 
	list_display = ('currency','symbol','currencyCode')
	list_per_page = 25
	#list_filter = ('state',)
	search_fields = ['currency','symbol','currencyCode']
	sortable_field_name = "currency","symbol","currencyCode"
   
	form = CurrencyFormAdmin
	def save_model(self, request, obj, form, change):
		if not change:
			obj.createdBy_id = request.user.id
			obj.updatedBy_id = request.user.id
			obj.entityId_id  = 1
			obj.langId_id	 = 1
		else :
			obj.entityId_id  = 1
			obj.updatedBy_id = request.user.id
			obj.langId_id	  = 1
		obj.save()

	actions = ['delete_selected']
	def delete_selected(self, request, obj):
		for o in obj.all():
			o.isDeleted = True
			o.save()
	delete_selected.short_description = 'Delete selected'

admin.site.register(Country, CountryAdmin)
admin.site.register(State,StateAdmin)
admin.site.register(City,CityAdmin)
admin.site.register(Entity, EntityAdmin)
admin.site.register(Language, LanguageAdmin)
admin.site.register(Currency, CurrencyAdmin)
