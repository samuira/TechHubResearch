from django.db import models
from django.utils import timezone
from django.conf import settings
from site_master.utils import SoftDeleteManager
import os
from uuid import uuid4


def xstr(s):
    return '' if s is None else str(s)


class Entity(models.Model):
    name = models.CharField(max_length=20, blank=False)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='entity_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='entity_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    class Meta:
        verbose_name_plural = "Entities"

    def __str__(self):
        return u"%s" % self.name

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class Language(models.Model):
    name = models.CharField(max_length=20, blank=False)
    code = models.CharField(max_length=20, blank=False)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='lang_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='lang_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.name

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class Country(models.Model):
    title = models.CharField(max_length=80, verbose_name='Country name')
    code = models.CharField(max_length=80, default="", verbose_name='Country code')
    phonecode = models.CharField(max_length=80, default="", verbose_name='Country Mobile code')
    entityId = models.ForeignKey(Entity, on_delete=models.CASCADE)
    langId = models.ForeignKey(Language, on_delete=models.CASCADE)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='country_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='country_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.title

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class State(models.Model):
    title = models.CharField(max_length=80, verbose_name='State name')
    code = models.CharField(max_length=80, default="", verbose_name='State code')
    country = models.ForeignKey(Country, blank=False, null=False, verbose_name='Select Country')
    entityId = models.ForeignKey(Entity, on_delete=models.CASCADE)
    langId = models.ForeignKey(Language, on_delete=models.CASCADE)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='state_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='state_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.title

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class City(models.Model):
    title = models.CharField(max_length=80, verbose_name='City name')
    code = models.CharField(max_length=80, default="", verbose_name='City code')
    state = models.ForeignKey(State, blank=False, null=False, verbose_name='Select State')
    entityId = models.ForeignKey(Entity, on_delete=models.CASCADE)
    langId = models.ForeignKey(Language, on_delete=models.CASCADE)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='city_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='city_updated_by_user')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    class Meta:
        verbose_name_plural = 'Cities'

    def __str__(self):
        return u"%s" % self.title

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class Currency(models.Model):
    currency = models.CharField(max_length=80, verbose_name='Currency name')
    html_symbol = models.CharField(max_length=80, verbose_name='Currency HTML Symbol', default='')
    symbol = models.CharField(max_length=255)
    currencyCode = models.CharField(max_length=10)
    entityId = models.ForeignKey(Entity, on_delete=models.CASCADE)
    langId = models.ForeignKey(Language, on_delete=models.CASCADE)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='currency_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='currency_updated_by_user')
    isDeleted = models.BooleanField(default=False)

    objects = SoftDeleteManager()

    class Meta:
        verbose_name_plural = 'Currencies'

    def __str__(self):
        return u"%s" % self.currency

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()
