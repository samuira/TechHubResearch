from django.apps import AppConfig


class SiteMasterConfig(AppConfig):
    name = 'site_master'
