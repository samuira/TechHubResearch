from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import pytz
import json
from datetime import datetime
from site_user.models import User
from .models import userActivity
from django.http import JsonResponse, HttpResponse
from webservice.serializers import userActivitySerializer
from django.db.models import Q
from rest_framework.parsers import JSONParser
from webservice.views.all_import import *
from django.contrib.sessions.models import Session
from site_user.models import UserSession
from django.contrib.auth import logout
from django.core.validators import validate_ipv46_address
# from webservice.views.all_import import *

tz = pytz.timezone(settings.TIME_ZONE)


def frm_submit(user=None, session_id=None, ip=None, value=None):
    print(type(session_id))
    if user is not None:
        print(value)
        try:
            element_logged_info = userActivity.objects.get(user_info=user, element_id=value["element_id"],
                                                           session_id=session_id,
                                                           browser_info=value["browser"])

        except userActivity.DoesNotExist:
            element_logged_obj = userActivity(user_info=user,
                                              user_activity_time=value["user_activity_time"],
                                              event=value["event"],
                                              element_name=value["element"],
                                              element_id=value["element_id"],
                                              element_val=value["element_val"],
                                              page_url=value["page_url"],
                                              session_id=session_id,
                                              http_method=value["http_method"],
                                              browser_info=value["browser"]
                                              )
            element_logged_obj.save()

        else:  # Step3: element_id is logged. So update it.
            element_logged_info.page_url = value["page_url"]
            element_logged_info.element_val = value["element_val"]
            element_logged_info.save()
        USER_INFO = user.id
    else:
        print(value)
        try:
            element_logged_info = userActivity.objects.get(user_info=user, element_id=value["element_id"],
                                                           session_id=session_id,
                                                           browser_info=value["browser"],
                                                           IP=ip)
        except userActivity.DoesNotExist:
            element_logged_obj = userActivity(user_info=user,
                                              user_activity_time=value["user_activity_time"],
                                              event=value["event"],
                                              element_name=value["element"],
                                              element_id=value["element_id"],
                                              element_val=value["element_val"],
                                              page_url=value["page_url"],
                                              session_id=session_id,
                                              http_method=value["http_method"],
                                              browser_info=value["browser"],
                                              IP=ip
                                              )
            element_logged_obj.save()

        else:  # Step3: element_id is logged. So update it.
            element_logged_info.page_url = value["page_url"]
            element_logged_info.element_val = value["element_val"]
            element_logged_info.save()
        USER_INFO = user

    frm_submit_info = {"status": "True", "Form": value["element_id"], "value": value["element_val"],
                       "user": USER_INFO, "session_key": session_id, "browser": value["browser"], "IP":ip}
    return JsonResponse(frm_submit_info)


def click(user=None, session_id=None, ip=None, value=None):
    element_id = value["element_id"]
    no_of_clicks = 0
    if user is not None:
        try:
            element_logged_info = userActivity.objects.get(user_info=user, element_id=element_id,
                                                           session_id=session_id,
                                                           browser_info=value["browser"],
                                                           IP=ip)
        except userActivity.DoesNotExist:
            n_click = 1
            element_logged_obj = userActivity(user_info=user,
                                              user_activity_time=value["user_activity_time"],
                                              event=value["event"],
                                              element_name=value["element"],
                                              element_id=value["element_id"],
                                              element_val=value["element_val"],
                                              page_url=value["page_url"],
                                              element_click_count=n_click,
                                              session_id=session_id,
                                              browser_info=value["browser"],
                                              IP=ip
                                              )
            element_logged_obj.save()
            no_of_clicks = n_click
        else:
            n_click = element_logged_info.element_click_count + 1
            element_logged_info.element_click_count = n_click
            element_logged_info.page_url = value["page_url"]
            element_logged_info.element_val = value["element_val"]
            element_logged_info.save()
            no_of_clicks = n_click
        USER_INFO = user.id
    else:
        try:
            element_logged_info = userActivity.objects.get(user_info=user, element_id=element_id,
                                                           session_id=session_id,
                                                           browser_info=value["browser"],
                                                           IP=ip)
        except userActivity.DoesNotExist:
            n_click = 1
            element_logged_obj = userActivity(user_info=user,
                                              user_activity_time=value["user_activity_time"],
                                              event=value["event"],
                                              element_name=value["element"],
                                              element_id=value["element_id"],
                                              element_val=value["element_val"],
                                              page_url=value["page_url"],
                                              element_click_count=n_click,
                                              session_id=session_id,
                                              browser_info=value["browser"],
                                              IP=ip
                                              )
            element_logged_obj.save()
            no_of_clicks = n_click
        else:
            n_click = element_logged_info.element_click_count + 1
            element_logged_info.element_click_count = n_click
            element_logged_info.page_url = value["page_url"]
            element_logged_info.element_val = value["element_val"]
            element_logged_info.save()
            no_of_clicks = n_click
        USER_INFO = user
    clicks_info = {"status": "True", "clicks": no_of_clicks,
                   "value": value["element_val"], "user": USER_INFO, "session_key": session_id,
                   "browser_info": value["browser"], "IP": ip}
    return JsonResponse(clicks_info)


class createloggedActivity(APIView):
    #authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        data = JSONParser().parse(request)
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            print(x_forwarded_for)
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        print(ip)
        event_name = data['event']
        SESSION_KEY = None
        if request.user.is_authenticated():
            user_info = UserSession.objects.filter(user=request.user,
                                                   browser_info=request.META['HTTP_USER_AGENT'],
                                                   IP=ip)
            if user_info.count():
                SESSION_KEY = user_info.values()[0]['session_info']
                print("SESSION_KEY", SESSION_KEY)

            else:
                user_obj = UserSession()
                user_obj.user = request.user
                request.session.create()
                SESSION_KEY = request.session.session_key
                user_obj.session_info = SESSION_KEY
                user_obj.browser_info = request.META['HTTP_USER_AGENT']
                user_obj.IP = ip
                user_obj.save()

            if event_name == "Form_Submit":
                http_method = request.method
                page_url = request.META.get('HTTP_REFERER'), # data["element_url"], request.get_full_path
                user_activity_time = datetime.datetime.now(tz)
                element = data['element']
                element_id = data['element_id']
                element_val = data['element_val']

                val_dict = {
                    "element": element,
                    "http_method": http_method,
                    "page_url": page_url,
                    "user_activity_time": user_activity_time,
                    "element_id": element_id,
                    "element_val": element_val,
                    "event": event_name,
                    "browser": request.META['HTTP_USER_AGENT'],
                    "IP": ip
                }
                resp = frm_submit(user=request.user, session_id=SESSION_KEY, ip=ip,
                                  value=val_dict)
                return HttpResponse(resp, content_type="application/json")

            elif event_name == "Click":
                page_url = request.META.get('HTTP_REFERER'),  # request.get_full_path
                user_activity_time = datetime.datetime.now(tz)
                element = data['element']
                element_id = data['element_id']
                element_val = data['element_val']
                val_dict = {
                    "element": element,
                    "page_url": page_url,
                    "user_activity_time": user_activity_time,
                    "element_id": element_id,
                    "element_val": element_val,
                    "event": event_name,
                    "browser": request.META['HTTP_USER_AGENT'],
                    "IP": ip
                }
                resp = click(user=request.user, session_id=SESSION_KEY,ip=ip,
                             value=val_dict)
                return HttpResponse(resp, content_type="application/json")

        else:
            user_info = UserSession.objects.filter(user=None, browser_info=request.META['HTTP_USER_AGENT'], IP=ip)
            if user_info.count():
                SESSION_KEY = user_info.values()[0]['session_info']
                print("SESSION_KEY", SESSION_KEY)
            else:
                user_obj = UserSession()
                user_obj.user = None
                request.session.create()
                SESSION_KEY = request.session.session_key
                user_obj.session_info = SESSION_KEY
                user_obj.browser_info = request.META['HTTP_USER_AGENT']
                user_obj.IP = ip
                user_obj.save()

            if event_name == "Form_Submit":
                http_method = request.method
                page_url = request.META.get('HTTP_REFERER')  # request.get_full_path  # data["element_url"]
                user_activity_time = datetime.datetime.now(tz)
                element_id = data['element_id']
                element_val = data['element_val']
                val_dict = {
                    "element": data['element'],
                    "http_method": http_method,
                    "page_url": page_url,
                    "user_activity_time": user_activity_time,
                    "element_id": element_id,
                    "element_val": element_val,   # json.loads(str(element_val)),
                    "event": event_name,
                    "browser": request.META['HTTP_USER_AGENT'],
                    "IP": ip
                }
                resp = frm_submit(user=None, session_id=SESSION_KEY, ip=ip,
                                  value=val_dict)
                return HttpResponse(resp, content_type="application/json")

            elif event_name == "Click":
                page_url = request.META.get('HTTP_REFERER')  # request.get_full_path  # data["element_url"]
                user_activity_time = datetime.datetime.now(tz)
                element = data['element']
                element_id = data['element_id']
                element_val = data['element_val']
                val_dict = {
                    "element": element,
                    "page_url": page_url,
                    "user_activity_time": user_activity_time,
                    "element_id": element_id,
                    "element_val": element_val,   # json.loads(str(element_val))
                    "event": event_name,
                    "browser": request.META['HTTP_USER_AGENT'],
                    "IP": ip
                }
                resp = click(user=None, session_id=SESSION_KEY, ip=ip,
                             value=val_dict)
                return HttpResponse(resp, content_type="application/json")


class showloggedActivity(APIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            print(x_forwarded_for)
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        print(ip)

        if request.user.is_authenticated():
            try:
                user_info = UserSession.objects.get(user=request.user, browser_info=request.META['HTTP_USER_AGENT'],
                                                    IP=ip)

            except UserSession.DoesNotExist:
                msg = "No activity is logged for user : {}".format(request.user.id)
                return Response({"Message": msg})
            else:
                activities = userActivity.objects.filter(user_info=request.user, session_id=user_info.session_info,
                                                         browser_info=user_info.browser_info, IP=ip)
                serializer = userActivitySerializer(activities, many=True, allow_null=True)
                return Response(serializer.data)
        else:
            try:
                user_info = UserSession.objects.get(user=None, browser_info=request.META['HTTP_USER_AGENT'], IP=ip)
            except UserSession.DoesNotExist:
                msg = "No activity is logged for anonymous user"
                return Response({"Message":msg})
            else:
                activities = userActivity.objects.filter(user_info=None,
                                                         session_id=user_info.session_info,
                                                         browser_info=user_info.browser_info, IP=ip)
                serializer = userActivitySerializer(activities, many=True, allow_null=True)
                return Response(serializer.data)


class logout_page(APIView):
    authentication_classes = (TokenAuthentication,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            print(x_forwarded_for)
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        print(ip)
        try:
            # Remove entries for requested user from UserSession model with browser info
            user_info = UserSession.objects.get(user=request.user,
                                                browser_info=request.META['HTTP_USER_AGENT'], IP=ip)
            # Remove entries for anonymous user from UserSession model with browser info
            user_anonymous_info = UserSession.objects.get(user=None,
                                                          browser_info=request.META['HTTP_USER_AGENT'], IP=ip)
        except UserSession.DoesNotExist:
            msg = "No activity is logged for user : {}".format(request.user.id)
            logout(request)
            #return Response({"Message": msg, "status": True})
            responseData = {}
            print(type(responseData))
            mobileMsg = "User log out"
            responseSuccess.append({"type": "log out", "msg": msg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)
        else:
            user_info.delete()
            user_anonymous_info.delete()
            msg = "User {} is successfully logged out".format(request.user.id)
            logout(request)
            #return Response({"Message": msg, "status": True})
            responseData = {}
            print(type(responseData))
            mobileMsg = "User log out"
            responseSuccess.append({"type": "log out", "msg": msg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)

