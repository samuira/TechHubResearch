from django.db import models
from site_user.models import User
import datetime
from django.contrib.sessions.models import Session

class clickEvent(models.Model):
    element_click_count = models.IntegerField(default=0)

    class Meta:
        abstract = True


class scrollEvent(models.Model):
    scroll_depth_threshold = models.IntegerField(default=0)  # Here I consider 25,50,75 and 100 depth
    scroll_depth_units = models.CharField(max_length=10, default="", blank=True, null=True)
    scroll_direction = models.CharField(max_length=12, default="", blank=True, null=True)

    class Meta:
        abstract = True


class userActivity(clickEvent, scrollEvent):
    user_info = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    user_activity_time = models.DateTimeField(
        default=datetime.datetime(year=2030, month=1, day=1, hour=00, minute=00, second=00), blank=True)
    element_id = models.CharField(max_length=255, default="", blank=True, null=True)
    element_name = models.CharField(max_length=255, default="", blank=True, null=True)
    element_val = models.TextField(default="", blank=True, null=True)
    event = models.CharField(max_length=20, default="")
    http_method = models.CharField(max_length=6,default="")
    page_url = models.URLField(blank=True, null=True)
    browser_info = models.TextField(default="")
    session_id = models.CharField(max_length=255, default="")
    IP = models.CharField(max_length=255, default="")

    class Meta:
        db_table = "user_logged_activity"
        ordering = ('-user_activity_time',)



