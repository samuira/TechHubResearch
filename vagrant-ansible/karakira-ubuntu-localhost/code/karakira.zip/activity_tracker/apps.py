from django.apps import AppConfig


class ActivityTrackerConfig(AppConfig):
    name = 'activity_tracker'
