from django.conf.urls import url
from .views import *
urlpatterns = [
            url(r'^get_investment_hotspots$', GetInvestmentHotspots.as_view(), name='get_investment_hotspots'),  # (Sometimes
    # throws errors from Panda)
            url(r'^get_slashed_prices$', GetSlashedPrices.as_view(), name='get_slashed_prices'),  # (Sometimes
    # throws errors from Panda)
            url(r'^get_most_popular$', GetMostPopular.as_view(), name='get_most_popular'),  # (Sometimes
    # throws errors from Panda)
            url(r'^get_great_lifestyles$', GetGreatLifestyles.as_view(), name='get_great_lifestyles'),  # (Sometimes
    # throws errors from Panda)
        ]