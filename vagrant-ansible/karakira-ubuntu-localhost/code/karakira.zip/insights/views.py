from webservice.views.all_import import *
from rest_framework.renderers import JSONRenderer
from kpi import insights


class GetInvestmentHotspots(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetInvestmentHotspotsSerializer")

        if finalResponse:
            return requestData

        status, data = insights.get_investment_hotspots(location='Barcelona', window=3, n=10, typ='Y')
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get Investment Hotspots"
            responseSuccess.append({"type": "Get Investment Hotspots", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetSlashedPrices(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetSlashedPricesSerializer")

        if finalResponse:
            return requestData

        status, data = insights.slashed_prices(location='Barcelona', n=12)
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get Slashed Prices"
            responseSuccess.append({"type": "Get Slashed Prices", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetMostPopular(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetMostPopularSerializer")

        if finalResponse:
            return requestData

        status, data = insights.most_popular(location='Barcelona', n=8)
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get Most Popular"
            responseSuccess.append({"type": "Get Most Popular", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)


class GetGreatLifestyles(APIView):
    renderer_classes = (JSONRenderer,)
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        responseErrors = []
        responseSuccess = []
        responseData = {}
        user = request.user

        finalResponse, serializer, requestData = checkInputPayload(request, "GetGreatLifestylesSerializer")

        if finalResponse:
            return requestData

        status, data = insights.great_lifestyles(location='Barcelona', n=8)
        # print("############# data #################")
        # print(status, )
        if status:
            responseData = json.loads(data.replace("\\", ""))
            # print(type(responseData))
            mobileMsg = "Get Most Popular"
            responseSuccess.append({"type": "Get Most Popular", "msg": mobileMsg})
            return returnResponse(True, responseData, responseSuccess, responseErrors, mobileMsg)
