from django.apps import AppConfig


class InsightsConfig(AppConfig):
    name = 'insights'
