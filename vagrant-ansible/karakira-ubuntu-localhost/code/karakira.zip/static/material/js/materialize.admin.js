$(document).on('ready', function() {
  $('.button-collapse').sideNav()
  $('#slide-out').perfectScrollbar()
});
