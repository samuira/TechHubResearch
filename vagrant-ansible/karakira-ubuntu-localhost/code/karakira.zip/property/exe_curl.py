import requests
import json
from urllib.request import urlretrieve


def idealista_properties():
    url_1 = "https://api.idealista.com/oauth/token"

    payload = "grant_type=client_credentials&scope=read"
    headers = {
        'Authorization': "Basic a2xkMXFldTNiZWRmc2pwMnJtbzcwaXpqMHUxaXowOTY6WDdEeWFtTFZGUll2==",
        'Content-Type': "application/x-www-form-urlencoded",
        'Cache-Control': "no-cache",
        'Postman-Token': "bbebc031-5e9e-b642-fe2f-4f3467f3543d"
        }

    response = requests.request("POST", url_1, data=payload, headers=headers)
    bearer_token_response = json.loads(response.text.replace("\\", ""))

    url_2 = "https://api.idealista.com/3.5/es/search"

    payload = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"center\"\r\n\r\n40.430,-3.702\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"propertyType\"\r\n\r\nhomes\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"distance\"\r\n\r\n15000\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"operation\"\r\n\r\nsale\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--"
    headers = {
        'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
        'Authorization': "Bearer "+bearer_token_response['access_token'],
        'Content-Type': "multipart/form-data",
        'Cache-Control': "no-cache",
        'Postman-Token': "24141aa1-a40b-5c05-fbfb-90e4671d64c3"
        }

    response = requests.request("POST", url_2, data=payload, headers=headers)
    property_response = json.loads(response.text.replace("\\", ""))
    if 'httpStatus' in property_response and property_response['httpStatus'] == 500:
        return False, property_response
    else:
        return True, property_response['elementList']


# if __name__ == '__main__':
#     status, response = idealista_properties()
#     if 'httpStatus' in response and response['httpStatus'] == 500:
#         print(status, response)
#     else:
#         print(status, response)
#
#     image_url = "https://img3.idealista.com/blur/WEB_LISTING/0/id.pro.es.image.master/34/0a/56/260369547.jpg"
#     image_local_path = "file01.jpeg"
#     resource = urlretrieve(image_url, image_local_path)
#     print(resource)
#
#     from django.core.validators import URLValidator
#     from django.core.exceptions import ValidationError
#     #url = 'https://img3.idealista.com/blur/WEB_LISTING/0/id.pro.es.image.master/34/0a/56/260369547.jpg'
#     url = '/static/frontend/images/260369547.jpg'
#     try:
#         validate = URLValidator()
#         validate(url)
#     except ValidationError:
#         raise TypeError('Not a valid URL')

    # output = open("file01.jpg", "w")
    # output.write(resource[0])
    # output.close()
    #
    # from urllib.error import HTTPError
    #
    #
    # try:
    #     urlretrieve(image_url, image_local_path)
    # except FileNotFoundError as err:
    #     print(err)  # something wrong with local path
    # except HTTPError as err:
    #     print(err)  # something wrong with url
