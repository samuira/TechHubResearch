# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.models import AbstractUser
from auditlog.registry import auditlog
from auditlog.models import AuditlogHistoryField
from django.utils import timezone
from django.conf import settings
from site_master.utils import SoftDeleteManager
from site_master.models import *
from site_user.models import *
from django.contrib.auth.models import Group
import json
import datetime
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError
# Create your models here.


class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='static/media/analytics/')
    uploaded_at = models.DateTimeField(auto_now_add=True)


class Property_CSV_Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField()
    uploaded_at = models.DateTimeField(auto_now_add=True)


class Analytics(models.Model):
    added_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='prpoerty_added')
    location = models.CharField(max_length=255, default="")
    lat = models.FloatField(default=0.0)
    long = models.FloatField(default=0.0)
    sold = models.BooleanField(default=False)
    listing_price = models.FloatField(default=0.0)
    bank_price = models.FloatField(default=0.0)
    liked_by_user = models.IntegerField(default=0)
    searched_by_user = models.IntegerField(default=0)
    no_of_time_searched = models.IntegerField(default=0)
    removed_from_like = models.IntegerField(default=0)
    user_taken_action = models.IntegerField(default=0)
    bank_certification = models.BooleanField(default=False)
    size = models.FloatField(default=0.0)
    number_of_features = models.IntegerField(default=0)
    property_type = models.CharField(max_length=255)
    property_features = models.CharField(max_length=255)


class Listings(models.Model):
    title = models.CharField(max_length=255, default="", blank=True, null=True)
    category = models.CharField(max_length=255, default="", blank=True, null=True)  # "new build", "resales", "rent"
    description = models.CharField(max_length=10000, default="", blank=True, null=True)
    datesRegistered = models.DateTimeField(default=timezone.now, null=True)
    datesDeregistered = models.DateTimeField(default=timezone.now, null=True)
    lastActive = models.DateTimeField(default=timezone.now, null=True)
    hasFSBO = models.BooleanField(default=False)
    fsboUUID = models.ForeignKey(SellerFsbo, on_delete=models.CASCADE, related_name='listing_fsbo_user',
                                 null=True, default=None)
    hasAgent = models.BooleanField(default=False)
    agentUUID = models.ForeignKey(SellerAgent, on_delete=models.CASCADE, related_name='listing_agent_user',
                                  null=True, default=None)
    hasAmbassador = models.BooleanField(default=False)
    ambassadorUUID = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_ambassador_user',
                                       null=True, default=None)
    listingAddress = models.TextField(default="", blank=False)
    gooleAddressResponse = models.TextField(default="")
    latitude = models.CharField(max_length=255, default='', blank=True)
    longitude = models.CharField(max_length=255, default='', blank=True)
    contactName = models.CharField(max_length=255, default="", blank=True)
    contactEmail = models.CharField(max_length=60, default="", blank=True)
    contactMobile = models.CharField(max_length=255, default="", blank=True)
    photosList = models.CharField(max_length=255, default="", blank=True)
    videosList = models.CharField(max_length=255, default="", blank=True)
    vrList = models.CharField(max_length=255, default="", blank=True)
    isOpenBooking = models.BooleanField(default=False)
    isForSale = models.BooleanField(default=False)
    isForRent = models.BooleanField(default=False)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_updated')
    isDeleted = models.BooleanField(default=False)
    more_feature = models.CharField(max_length=7000, default="")
    is_spain_property = models.BooleanField(default=False)
    is_karakira_certified = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    class Meta:
        verbose_name_plural = 'listings'

    def __str__(self):
        return u"%s with ID : %s" % (self.datesRegistered, self.id)

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()

    def isFavByUser(self, user):
        # print(user)
        if UserFavListing.objects.filter(listing=self, user=user).exists():
            return True
        else:
            return False

    def detailsUrl(self):
        # return "%s/#/details/%s" % (settings.FRONTEND_URL, self.id)
        return "http://%s/property1/details/%s" % (settings.BASE_URL, self.id)

    def isRentedBy(self, user):
        if self.createdBy == user:
            return True
        else:
            return False

    def propURL(self):
        return "http://karakira.com"


class AnalyticsUserInfo(models.Model):
    #UserID = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='Analytics_user_info')
    # PropertyVisitedForBuy = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='PropertyVisitedForBuy',blank=True, null=True)
    # PropertyVisitedForRent = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='PropertyVisitedForRent',blank=True, null=True)
    UserID = models.IntegerField(default=0)
    Date = models.DateTimeField(default="", blank=True)
    PropertyVisitedForBuy = models.IntegerField(default=0)
    PropertyVisitedForRent = models.IntegerField(default=0)
    location = models.CharField(max_length=255, default="", blank=True, null=True)

    class Meta:
        db_table = "user_info_detailed"


class AnalyticsUserInfoAnother(models.Model):
    UserID = models.IntegerField(default=0)
    Session_in = models.DateTimeField(default="", blank=True)
    Session_out = models.DateTimeField(default="", blank=True)
    SearchedAs = models.CharField(max_length=255, default="")
    PropertyLiked = models.IntegerField(default=0)
    Emailed = models.IntegerField(default=0)
    Phone = models.IntegerField(default=0)
    IM = models.IntegerField(default=0)
    FaA = models.IntegerField(default=0)

    class Meta:
        db_table = "user_info"


class AnalyticsPropertySearch(models.Model):
    FirstSearchTime = models.DateTimeField(default="", blank=True)
    LastSearchTime = models.DateTimeField(default="", blank=True)
    VisitedBy = models.IntegerField(default=0)
    Location = models.CharField(max_length=255, default="")
    SearchKeywordsFeature = models.CharField(max_length=255, default="")
    SearchKeywordsType = models.CharField(max_length=255, default="")
    SearchPriceBracket = models.CharField(max_length=255, default="")
    PropertiesReturned = models.CharField(max_length=255, default="")

    class Meta:
        db_table = "property_search"


class AnalyticsPropertyVisit(models.Model):
    VisitingTimeStart = models.DateTimeField(default="", blank=True)
    VisitingTimeEnd = models.DateTimeField(default="", blank=True)
    PropertyID = models.IntegerField(default=0)
    VisitedBy = models.IntegerField(default=0)
    AddedBy = models.IntegerField(default=0)
    Converted = models.CharField(max_length=3, default="")
    Location = models.CharField(max_length=255, default="")
    Visited_from = models.CharField(max_length=255, default="")
    EntryPage = models.CharField(max_length=255, default="")
    ExitPage = models.CharField(max_length=255, default="")

    class Meta:
        db_table = "property_visits"


class AnalyticsSubscribers(models.Model):
    SubscriberID = models.IntegerField(default=0)
    AsBuyer = models.FloatField(default=0.0)
    AsFSBO = models.FloatField(default=0.0)
    AsAgent = models.FloatField(default=0.0)
    AsInvestor = models.FloatField(default=0.0)
    AsPropMngr = models.FloatField(default=0.0)
    AccountDeleted = models.CharField(default="", max_length=2)
    OnlineNow = models.CharField(default="", max_length=2)
    Location = models.CharField(default="", max_length=255)
    JoiningDate = models.CharField(default="", max_length=255)
    CancelDate = models.CharField(default="", max_length=255)
    Visited_from = models.CharField(default="", max_length=255)

    class Meta:
        db_table = "subscribers"


class AnalyticsAddPageviewandScroll(models.Model):
    UserId = models.IntegerField(default=0)
    LoginPageView = models.IntegerField(default=0)
    SearchPageView = models.IntegerField(default=0)
    ListingDetailsPageView = models.IntegerField(default=0)
    ContactPageView = models.IntegerField(default=0)
    BlogPageView = models.IntegerField(default=0)
    OtherPageView = models.IntegerField(default=0)

    class Meta:
        db_table = "page_view_and_scroll"


class AddPageviewandScrollDetails(models.Model):
    VisitedBy = models.IntegerField(default=0)
    PageViews = models.CharField(default="", max_length=255)
    CalledForAction = models.CharField(default="", max_length=2)
    SavedSearch = models.CharField(default="", max_length=2)
    FavProperties = models.CharField(default="", max_length=2)
    Visited_from = models.CharField(default="", max_length=255)

    class Meta:
        db_table = "page_view_and_scroll_details"


class AnalyticsSupplyDemandDetails(models.Model):
    Location = models.CharField(default="", max_length=255)
    Month = models.CharField(default="", max_length=12)
    PropertyAvailableforBuy = models.IntegerField(default=0)
    PropertyAvailableforRent = models.IntegerField(default=0)
    UniqueNumBuyers = models.IntegerField(default=0)
    UniqueNumRenters = models.IntegerField(default=0)
    totalNumOfViews = models.IntegerField(default=0)

    class Meta:
        db_table = "supply_demand"


class AnalyticsPriceBurndown(models.Model):
    City = models.CharField(default="", max_length=255)
    Lat = models.FloatField(default=0.0)
    Long = models.FloatField(default=0.0)
    PropertyId = models.IntegerField(default=0)
    priceOnMonth1 = models.FloatField(default=0.0)
    priceOnMonth2 = models.FloatField(default=0.0)
    priceOnMonth3 = models.FloatField(default=0.0)
    priceOnMonth4 = models.FloatField(default=0.0)
    priceOnMonth5 = models.FloatField(default=0.0)
    priceOnMonth6 = models.FloatField(default=0.0)
    priceOnMonth7 = models.FloatField(default=0.0)
    priceOnMonth8 = models.FloatField(default=0.0)
    priceOnMonth9 = models.FloatField(default=0.0)
    priceOnMonth10 = models.FloatField(default=0.0)
    priceOnMonth11 = models.FloatField(default=0.0)
    priceOnMonth12 = models.FloatField(default=0.0)
    BestLifestyle = models.CharField(default="", max_length=255)
    Size = models.FloatField(default=0.0)
    Completed = models.CharField(default="", max_length=1)
    TotalLikes = models.IntegerField(default=0)

    class Meta:
        db_table = "price_burndown"


class ListingsDetails(models.Model):
    homeType = models.CharField(max_length=255, default="", blank=True)
    isHighRise = models.BooleanField(default=False)
    bedrooms = models.IntegerField(default=0, null=False)
    baths = models.IntegerField(blank=False)
    #hoaFees = models.FloatField(blank=False)
    hoaFees = models.DecimalField(max_digits=30, decimal_places=0,blank=False)
    hoaFeesCurrency = models.ForeignKey(Currency, on_delete=models.CASCADE, related_name='listing_currency_fees')
    hasBasement = models.BooleanField(default=False)
    basementSize = models.IntegerField(default=0, null=False)
    #floorSpace = models.IntegerField(default=0, null=False)
    floorSpace = models.DecimalField(max_digits=20, decimal_places=0, blank=True)     # Built Size  as per European format
    coveredTerraceSpace = models.IntegerField(default=0, null=False)
    uncoveredTerraceSpace = models.IntegerField(default=0, null=False)
    #plotSize = models.IntegerField(default=0, null=False)
    plotSize = models.DecimalField(max_digits=20, decimal_places=0, blank=True)       # Plot Size as per European format
    yearBuilt = models.IntegerField(default=0, null=False)
    needsMinorRenovation = models.BooleanField(default=False)
    needsModerateRenovation = models.BooleanField(default=False)
    needsMajorRenovation = models.BooleanField(default=False)
    hasGarage = models.BooleanField(default=False)
    garageSize = models.IntegerField(default=0, null=False)
    hasCoveredParking = models.BooleanField(default=False)
    parkingSpaces = models.IntegerField(default=0, null=False)
    openHouseAllowed = models.BooleanField(default=False)
    appliancesIncluded = models.BooleanField(default=False)
    floorType = models.CharField(max_length=255, default="", blank=True)
    listingId = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='listing_details')
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_details_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_details_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.homeType

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsRoof(models.Model):
    tile = models.BooleanField(default=False)
    shingle = models.BooleanField(default=False)
    asphalt = models.BooleanField(default=False)
    metal = models.BooleanField(default=False)
    other = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_roof', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='roof_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='roof_updated')
    isDeleted = models.BooleanField(default=False)

    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.tile

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsExteriorFinish(models.Model):
    cement = models.BooleanField(default=False)
    brick = models.BooleanField(default=False)
    metal = models.BooleanField(default=False)
    shingle = models.BooleanField(default=False)
    stone = models.BooleanField(default=False)
    stucco = models.BooleanField(default=False)
    vinyl = models.BooleanField(default=False)
    wood = models.BooleanField(default=False)
    woodProducts = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_exterior_finish', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_exterior_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_exterior_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.cement

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsServices(models.Model):
    publicWater = models.BooleanField(default=False)
    publicSewage = models.BooleanField(default=False)
    publicGarbage = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_services', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_services_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_services_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.publicWater

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsSeparateRooms(models.Model):
    diningRoom = models.BooleanField(default=False)
    laundryRoom = models.BooleanField(default=False)
    library = models.BooleanField(default=False)
    office = models.BooleanField(default=False)
    masterBathroom = models.BooleanField(default=False)
    workshop = models.BooleanField(default=False)
    solarium = models.BooleanField(default=False)
    gardenShed = models.BooleanField(default=False)
    guestApartment = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_separate_rooms', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_separate_rooms_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_separate_rooms_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.diningRoom

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsIndoorFeatures(models.Model):
    hasBroadbandInternet = models.BooleanField(default=False)
    internetSpeed = models.IntegerField(null=False, default=0)
    hasFireplace = models.BooleanField(default=False)
    fireplaceCount = models.IntegerField(null=False, default=0)
    hasDoubleGlazing = models.BooleanField(default=False)
    hasSecuritySystemBasic = models.BooleanField(default=False)
    hasSecuritySystemAdvanced = models.BooleanField(default=False)
    smartHomeWired = models.BooleanField(default=False)
    highCeilings = models.BooleanField(default=False)
    skylights = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_indoor_features', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_indoor_features_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_indoor_features_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.hasBroadbandInternet

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsIndoorFeaturesViews(models.Model):
    mountain = models.BooleanField(default=False)
    water = models.BooleanField(default=False)
    forest = models.BooleanField(default=False)
    city = models.BooleanField(default=False)
    listingIndoorFeaturesId = models.ForeignKey(ListingsIndoorFeatures, on_delete=models.CASCADE, related_name='listing_indoor_features_views', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_indoor_features_views_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_indoor_features_views_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.mountain

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsIndoorFeaturesLocationSetting(models.Model):
    mountain = models.BooleanField(default=False)
    valley = models.BooleanField(default=False)
    coastal = models.BooleanField(default=False)
    waterfront = models.BooleanField(default=False)
    inland = models.BooleanField(default=False)
    forest = models.BooleanField(default=False)
    city = models.BooleanField(default=False)
    suburb = models.BooleanField(default=False)
    rural = models.BooleanField(default=False)
    farm = models.BooleanField(default=False)
    highrise = models.BooleanField(default=False)
    lowrise = models.BooleanField(default=False)
    peaceful = models.BooleanField(default=False)
    busy = models.BooleanField(default=False)
    international = models.BooleanField(default=False)
    local = models.BooleanField(default=False)
    forSeniors = models.BooleanField(default=False)
    forFamilies = models.BooleanField(default=False)
    listingIndoorFeaturesId = models.ForeignKey(ListingsIndoorFeatures, on_delete=models.CASCADE, related_name='listing_indoor_features_location', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_indoor_features_location_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_indoor_features_location_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.mountain

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsOutdoorFeatures(models.Model):
    guesthouse = models.BooleanField(default=False)
    swimmingPool = models.BooleanField(default=False)
    hottub = models.BooleanField(default=False)
    fence = models.BooleanField(default=False)
    gatedEntry = models.BooleanField(default=False)
    balcony = models.BooleanField(default=False)
    deck = models.BooleanField(default=False)
    terrace = models.BooleanField(default=False)
    bbqArea = models.BooleanField(default=False)
    dock = models.BooleanField(default=False)
    gardenSmall = models.BooleanField(default=False)
    gardenLarge = models.BooleanField(default=False)
    gardenAcreage = models.BooleanField(default=False)
    sauna = models.BooleanField(default=False)
    sprinkler = models.BooleanField(default=False)
    generator = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_outdoor_features', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_outdoor_features_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_outdoor_features_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.guesthouse

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsCoolingSystem(models.Model):
    electric = models.BooleanField(default=False)
    green = models.BooleanField(default=False)
    other = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_cooling_system', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_cooling_system_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_cooling_system_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.electric

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsHeatingSystem(models.Model):
    oil = models.BooleanField(default=False)
    gas = models.BooleanField(default=False)
    wood = models.BooleanField(default=False)
    electric = models.BooleanField(default=False)
    green = models.BooleanField(default=False)
    other = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_heating_system', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_heating_system_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_heating_system_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.oil

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsLifestyleFit(models.Model):
    lifestyle1 = models.TextField(blank=True)
    lifestyle2 = models.TextField(blank=True)
    lifestyle3 = models.TextField(blank=True)
    lifestyle1Weight = models.TextField(blank=True)
    lifestyle2Weight = models.TextField(blank=True)
    lifestyle3Weight = models.TextField(blank=True)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_lifestyle',
                                          blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_lifestyle_'
                                                                                                   'created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_lifestyle_'
                                                                                                   'updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.lifestyle1

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsApartmentBuilding(models.Model):
    doorman = models.BooleanField(default=False)
    intercom = models.BooleanField(default=False)
    elevator = models.BooleanField(default=False)
    floorLevel = models.IntegerField(default=0, null=False)
    sportsCourts = models.BooleanField(default=False)
    gym = models.BooleanField(default=False)
    pool = models.BooleanField(default=False)
    sauna = models.BooleanField(default=False)
    concierge = models.BooleanField(default=False)
    storage = models.BooleanField(default=False)
    nearTransportation = models.BooleanField(default=False)
    seniorCommunity = models.BooleanField(default=False)
    adultCommunity = models.BooleanField(default=False)
    familyCommunity = models.BooleanField(default=False)
    gatedEntry = models.BooleanField(default=False)
    listingsDetailsId = models.ForeignKey(ListingsDetails, on_delete=models.CASCADE, related_name='listing_apartment_building', blank=True, default=None)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_apartment_building_created')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_apartment_building_updated')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.doorman

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class ListingsImage(models.Model):
    image_name = models.CharField(max_length=200, default="", blank=True)
    image_url = models.CharField(max_length=255, default="", blank=True)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_image_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_image_updated_by_user')
    listingId = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='listing_image')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"%s" % self.listingId

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()

    def getImageUrl(self):
        try:
            validate = URLValidator()
            validate(self.image_url)
        except ValidationError:
            return "%s://%s" % (settings.PROTOCOL, settings.BASE_URL + self.image_url)
        else:
            return self.image_url


class ListingsVideo(models.Model):
    video_name = models.CharField(max_length=200, default="", blank=True)
    video_url = models.CharField(max_length=255, default="", blank=True)
    createdDate = models.DateTimeField(default=timezone.now, blank=True)
    createdBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_video_created_by_user')
    updatedDate = models.DateTimeField(default=timezone.now, null=True)
    updatedBy = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='listing_video_updated_by_user')
    listingId = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='listing_video')
    isDeleted = models.BooleanField(default=False)
    objects = SoftDeleteManager()

    def __str__(self):
        return u"listing ID: %s and Video URL %s" % (self.listingId, self.video_url)

    def getVideoUrl(self):
        try:
            validate = URLValidator()
            validate(self.video_url)
        except ValidationError:
            return None
        else:
            return self.video_url



class UserFavListing(models.Model):
    listing = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='user_fav_listing_list')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user_fav_listing_usr')

    def __str__(self):
        return u"%s" % self.user


class UserSavedSearch(models.Model):
    listingAddress = models.CharField(max_length=255, blank=False)
    title = models.CharField(max_length=255, blank=False)
    latitude = models.CharField(max_length=255, default='', blank=True)
    longitude = models.CharField(max_length=255, default='', blank=True)
    filter_attributes = models.CharField(max_length=255, default='', blank=True)
    isForSale = models.BooleanField(default=True)
    isForRent = models.BooleanField(default=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user_save_search_usr')

    def __str__(self):
        return u"%s" % self.user

    def setFilterAttributes(self, x):
        self.filter_attributes = json.dumps(x)

    def getFilterAttributes(self):
        if self.filter_attributes:
            return json.loads(self.filter_attributes)
        else:
            return []

# Gather properties for rent with Renter and Rentee details


class ForRent(models.Model):
    listing = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name='property_listing_rent')
    renter = models.ForeignKey(Renter, on_delete=models.CASCADE, related_name='property_listing_renter_user', null=True, default=None)
    rentFrom = models.DateField(blank=False)
    rentTo = models.DateField(blank=False)
    maxNoOfPersons = models.IntegerField(default=1)  # set value for YES and set NO otherwise

    def __str__(self):
        return 'Available For Rent: ' + str(self.listing.id) + " at location: " + str(self.listing.listingAddress) + \
               " --- from renter:" + str(self.renter.id)

    def availableSpace(self):
        availableSpace = self.maxNoOfPersons
        for eachRentDetails in RentDetails.objects.filter(rent_slot=self):
            availableSpace -= eachRentDetails.noOfPersons
        return availableSpace


class RentDetails(models.Model):
    rent_slot = models.ForeignKey(ForRent, on_delete=models.CASCADE, related_name='for_rent_slot_rent_rentee', null=True, default=None)
    rentee = models.ForeignKey(Rentee, on_delete=models.CASCADE, related_name='property_listing_rentee_user', null=True, default=None)
    bookingStartDate = models.DateTimeField()
    bookingEndDate = models.DateTimeField()
    noOfPersons = models.IntegerField(default=1)  # set value for YES and set NO otherwise

    def __str__(self):
        return 'Rent Booking Details: ' + str(self.rent_slot.listing.id) + " at location: " + str(self.rent_slot.listing.listingAddress) \
               + " --- staying rentee:" + str(self.rentee.id)

# Gather propertie search histories for each Rentee
# 1. A rentee can search multiple times.
# 2. A rentee can choose multiple properties from search results.
# 3. A rentee can contact with corresponding renter for final dealing.


class RentSearch(models.Model):
    rentee = models.ForeignKey(Rentee, on_delete=models.DO_NOTHING)
    listing = models.ForeignKey(Listings, on_delete=models.DO_NOTHING)

    def __str__(self):
        return "Rentee:" + str(self.rentee.id) + " searches property " + str(self.listing.id) + " from renter " + \
               str(self.listing.createdBy.id)


class VisitSchedule(models.Model):
    listing = models.ForeignKey(Listings, on_delete=models.DO_NOTHING)
    visitDate = models.DateField()
    startTime = models.TimeField()
    endTime = models.TimeField()
    maxNoOfPeople = models.IntegerField(default=1)
    byUser = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='visit_schedule_by_usr')

    def __str__(self):
        return "Seller:" + str(self.byUser) + " visit shedule " + str(self.listing.id)

    def availability(self):
        availability = self.maxNoOfPeople
        for eachVisitSchedule in VisitBooking.objects.filter(visit_slot=self):
            availability -= eachVisitSchedule.noOfPersons
        return availability


class VisitBooking(models.Model):
    visit_slot = models.ForeignKey(VisitSchedule, on_delete=models.DO_NOTHING)
    noOfPersons = models.IntegerField(default=1)
    bookedBy = models.ForeignKey(Buyer, on_delete=models.CASCADE, related_name='visit_schedule_booked_by_buyer')

    def __str__(self):
        return "Buyer:" + str(self.bookedBy) + " booked visit schedule for property " + str(self.listing.id) + \
               " which is scheduled by Seller " + str(self.visit_slot.byUser)


'''
# Note:
1. A project can have multiple properties. (OK)
2. Picture of a project must be included. (OK)
3. A seller can create a project (without property) and it will be manufactured in future. So, picture is attached. (OK)
4. An investor can see both projects with and without properties. Property with (sale + project), OR as a new project 
without an associated property. (OK)  
5. BUT,when buyers search, they will see some properties with (sale + project) with details about it.
6. In Project, please create another field called ‘CCC’ which stands for Comunidades Contra Crisis. This is going to be 
the official name of our strategy which fights against the Youth Unemployment Crisis. Every project that gets listed must 
fill in how many youths it plans to temporarily contract for the project. (OK)
7. Why CCC? Projects that plan to temporarily hire youths (but of course they may not actually do it), will get ranked higher 
in our search results list and will also get free promotions as “Featured Projects”. (OK)
8. The ones with no intention to hire youths will get ranked lower. (OK)
9. please note that the options for CCC should be fixed (implemented via a radio button or drop down list in the web 
form). The choices are 0, 1, 2, 3+
(OK)
'''


class Project(models.Model):
    CCC_LOW = '0'
    CCC_MID = '1'
    CCC_HIGH = '2'
    CCC_VERYHIGH = '3'

    RESIDENTIAL = 'Residential'
    COMMERCIAL = 'Commercial'
    MIXED = 'Residential and Commercial'
    OTHER = 'Other'
    CCC_RANK_CHOICES = (
    (CCC_LOW, 'CCC low'), (CCC_MID, 'CCC mid'), (CCC_HIGH, 'CCC high'), (CCC_VERYHIGH, 'CCC very high'))
    PROJECT_CATEGORY_CHOICE = (
        (RESIDENTIAL, 'Residential'),
        (COMMERCIAL, 'Commercial'),
        (MIXED, 'Mixed'),
    )
    name = models.CharField(max_length=50, default="")
    upload_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                  related_name='project_uploaded_by_seller')
    location = models.CharField(max_length=50, default="")
    category_of_project = models.CharField(max_length=20, choices=PROJECT_CATEGORY_CHOICE, default=RESIDENTIAL)
    const_start_time = models.DateTimeField(
        default=datetime.datetime(year=2010, month=1, day=1, hour=00, minute=00, second=00),
        blank=True)  # construction started time
    const_end_time = models.DateTimeField(
        default=datetime.datetime(year=2030, month=1, day=1, hour=00, minute=00, second=00),
        blank=True)  # construction end time
    nearby_instr_spot = models.CharField(max_length=20, default="")  # nearby interesting spots
    photo = models.ImageField(upload_to='gallery/project', null=True, blank=True, help_text="Upload photo for project")
    CCC = models.CharField(max_length=1, choices=CCC_RANK_CHOICES, default=CCC_LOW)
    holding_period = models.FloatField(default=0.0)  # Project duration. Calculate const_end_time from const_start_time
    # and holding_period
    #invested_by = models.ForeignKey(Investor, related_name='Investor_invest_to_this_project',null=True,blank=True)
    total_amount = models.FloatField(default=0.0)
    collected_amount = models.FloatField(default=0.0)
    live_offering = models.FloatField(default=0.0)
    is_visible = models.BooleanField(default=True)  # Make it False when collected_amount=total_amount and this project
    # is not visible in searching result

    class Meta:
        ordering = ["-CCC"]

    def __str__(self):
        return "Project " + str(self.id) + " at location " + self.location

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


class PropertyWithProject(models.Model):
    property_item = models.ForeignKey(Listings, on_delete=models.DO_NOTHING,blank=True, null=True)
    project = models.ForeignKey(Project, on_delete=models.DO_NOTHING, blank=True, null=True)

    def __str__(self):
        return 'Property Id:'+str(self.property_item.id)+" --- in location:"+self.property_item.listingaddress + \
               " with project ## "+str(self.project)

    def delete(self, *args, **kwargs):
        self.isDeleted = True
        self.save()


# Structure of Investment
class Investment(models.Model):
    project = models.OneToOneField(Project, on_delete=models.DO_NOTHING,blank=True, null=True)
    annual_preferred_return = models.FloatField(default=0.0)  # in percentage (like 60% as 0.60)
    estimated_IRR = models.FloatField(default=0.0)  # in percentage (like 60% as 0.60).
    any_legal_information = models.ImageField(upload_to='gallery/project_legal_info',
                                              help_text="Upload any_legal_information for project",
                                              null=True, blank=True)
    risk_outline_management_plan = models.ImageField(upload_to='gallery/project_risk_outline_management_plan',
                                                     help_text="Upload risk_outline_management_plan for project",
                                                     null=True, blank=True)
    # number_of_investors_needed = models.IntegerField(default=0)
    optional_links = models.URLField(blank=True)

    class Meta:
        ordering = ["-project__CCC"]

    def __str__(self):
        return 'Investment ID:'+str(self.id)


# Structure of Investment to Project
class Project_Investment(models.Model):
    project = models.ForeignKey(Project, on_delete=models.DO_NOTHING, blank=True, null=True)
    investor = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='Project_Investor', null=True, blank=True)
    amount = models.FloatField(default=0.0)
