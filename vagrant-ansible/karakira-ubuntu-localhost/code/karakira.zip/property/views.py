# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from .models import *
import requests
import json
import sys
import xmltodict
from django.utils import timezone
from site_user.models import *
from django.http import Http404
from webservice.views.all_import import makePropertyDetailsData
from django.views.decorators.clickjacking import xframe_options_exempt
from django.db.models import Q
from django.http import JsonResponse
from random import randint, randrange, uniform, sample, choice
import datetime
from rest_framework.response import Response
from .exe_curl import idealista_properties
from rest_framework import status
from rest_framework.decorators import renderer_classes, api_view
from rest_framework.renderers import JSONRenderer
from rest_framework import generics
from rest_framework.parsers import JSONParser, FormParser, MultiPartParser
from rest_framework.renderers import JSONRenderer, BrowsableAPIRenderer, MultiPartRenderer, HTMLFormRenderer
from rest_framework.authentication import TokenAuthentication
import csv
from rest_framework.permissions import AllowAny
from django.core.files.storage import FileSystemStorage
from webservice.serializers import DocumentSerializer

def parseResult(results, key):
    if isinstance(results, dict):
        for eachKey in results.keys():
            if isinstance(results[eachKey], str):
                print(key + " > " + eachKey + " : " + results[eachKey])
            else:
                parseResult(results[eachKey], eachKey)
# Create your views here.
# Url: http://127.0.0.1:8000/property/sync/2114+Bigelow+Ave/Seattle%2C+WA


def validateZillowData(data, requiredType='int'):
    if requiredType == 'int':
        if data is None:
            data = 0
    elif requiredType == 'float':
        if data is None:
            data = 0.0
    elif requiredType == 'char':
        if data is None:
            data = ""
        else:
            data = str(data)
    elif data is None:
        data = ""
    return data


def index(request, address, citystatezip):
    context = {
        'settings': settings
    }
    api_key = "X1-ZWz19157nv4cuj_14qhc"

    # postcode = "885"
    # area = "Oxford"
    # url = "http://api.zoopla.co.uk/api/v1/property_listings.json"

    url = "http://www.zillow.com/webservice/GetDeepSearchResults.htm"
    querystring = {"address": address,
                   "citystatezip": citystatezip, "zws-id": api_key}
    headers = {
        'cache-control': "no-cache",
    }
    response = requests.request(
        "GET", url, headers=headers, params=querystring)

    # responseData = json.loads(response.text)
    # file = urllib2.urlopen('https://www.goodreads.com/review/list/20990068.xml?key=nGvCqaQ6tn9w4HNpW8kquw&v=2&shelf=toread')
    # data = file.read()
    # file.close()

    data = xmltodict.parse(response.text)
    data = json.loads(json.dumps(data))
    resposeData = data['SearchResults:searchresults']['response']['results']['result']

    # print(resposeData)
    # results = data['SearchResults:searchresults']['response']['results']
    # parseResult(results, 'results')

    url1 = "http://www.zillow.com/webservice/GetDeepComps.htm"
    querystring1 = {
        "zpid": resposeData['zpid'], "zws-id": api_key, "count": 25}
    response = requests.request(
        "GET", url1, headers=headers, params=querystring1)
    data1 = xmltodict.parse(response.text, process_namespaces=True)
    data1 = json.loads(json.dumps(data1))
    updatedResponseData = data1['http://www.zillow.com/static/xsd/Comps.xsd:comps']['response']['properties']['comparables']['comp']

    for eachData in updatedResponseData:
        eachListingData = {}
        eachListingData['listingAddress'] = str(eachData['address']['street']) + ";" + str(
            eachData['address']['zipcode']) + ";" + str(eachData['address']['city']) + ";" + str(eachData['address']['state'])
        eachListingData['latitude'] = str(eachData['address']['latitude'])
        eachListingData['longitude'] = str(eachData['address']['longitude'])
        eachListingData['yearBuilt'] = eachData['yearBuilt']
        eachListingData['plotSize'] = eachData['lotSizeSqFt']
        eachListingData['floorSpace'] = eachData['finishedSqFt']
        eachListingData['bedrooms'] = eachData['bedrooms']
        eachListingData['baths'] = eachData['bathrooms']
        eachListingData['price'] = eachData['lastSoldPrice']['#text']

        user = User.objects.filter(username='admin').first()

        listing = Listings.objects.create(
            datesRegistered=timezone.now(),
            datesDeregistered=timezone.now(),
            lastActive=timezone.now(),
            hasFSBO=False,
            fsboUUID=None,
            hasAgent=False,
            agentUUID=None,
            hasAmbassador=False,
            ambassadorUUID=None,
            listingAddress=validateZillowData(
                eachListingData['listingAddress'], "char"),
            latitude=validateZillowData(eachListingData['latitude'], "char"),
            longitude=validateZillowData(eachListingData['longitude'], "char"),
            contactName="",
            contactEmail="",
            contactMobile="",
            photosList="",
            videosList="",
            vrList="",
            createdBy=user,
            updatedBy=user
        )
        currency = Currency.objects.filter(
            currency=resposeData['lastSoldPrice']['@currency']).first()

        listingsDetails = ListingsDetails.objects.create(
            homeType=resposeData['useCode'],
            isHighRise=False,
            bedrooms=validateZillowData(eachListingData['bedrooms']),
            baths=validateZillowData(eachListingData['baths'], "float"),
            hoaFees=validateZillowData(eachListingData['price'], "float"),
            hasBasement=False,
            basementSize=0,
            floorSpace=validateZillowData(eachListingData['floorSpace']),
            coveredTerraceSpace=0,
            uncoveredTerraceSpace=0,
            plotSize=validateZillowData(eachListingData['plotSize']),
            yearBuilt=validateZillowData(eachListingData['yearBuilt']),
            needsMinorRenovation=False,
            needsModerateRenovation=False,
            needsMajorRenovation=False,
            hasGarage=False,
            garageSize=0,
            hasCoveredParking=False,
            parkingSpaces=0,
            openHouseAllowed=False,
            appliancesIncluded=False,
            floorType='',
            listingId=listing,
            hoaFeesCurrency=currency,
            createdBy=user,
            updatedBy=user
        )

        # Roof Types List
        data, isCreated = ListingsRoof.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Exterior Types List
        data, isCreated = ListingsExteriorFinish.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Services Types List
        data, isCreated = ListingsServices.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Separate Rooms Types List
        data, isCreated = ListingsSeparateRooms.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Indoor Features List
        data, isCreated = ListingsIndoorFeatures.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Indoor Views Types List
        data1, isCreated = ListingsIndoorFeaturesViews.objects.get_or_create(
            listingIndoorFeaturesId=data,
            createdBy=user,
            updatedBy=user
        )

        # Indoor Location Settings Types List
        data1, isCreated = ListingsIndoorFeaturesLocationSetting.objects.get_or_create(
            listingIndoorFeaturesId=data,
            createdBy=user,
            updatedBy=user
        )

        # Outdoor Features List
        data, isCreated = ListingsOutdoorFeatures.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Cooling System Types List
        data, isCreated = ListingsCoolingSystem.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Heating System Types List
        data, isCreated = ListingsHeatingSystem.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Lifestylefit Types List
        data, isCreated = ListingsLifestyleFit.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

        # Apartment Building Types List
        data, isCreated = ListingsApartmentBuilding.objects.get_or_create(
            listingsDetailsId=listingsDetails,
            createdBy=user,
            updatedBy=user
        )

    return render(request, 'index.html', context)


def propertyImages(request, limit, offset):
    context = {
        'settings': settings
    }
    # http://localhost:8000/property/sync_images_only/0/5
    # limit & offset are dynamic
    # limit = 0
    # offset = 5
    Limit = int(limit)
    Offset = int(offset)

    allProperties = Listings.objects.all()[Limit:Offset]
    sampleImage = [
        {'image_name': 'image1.jpeg', 'image_url': settings.STATIC_URL +
            "frontend/images/image1.jpeg"},
        {'image_name': "image2.jpeg", 'image_url': settings.STATIC_URL +
            "frontend/images/image2.jpeg"}
    ]

    if allProperties.count() > 0:
        user = User.objects.filter(username='admin').first()
        for eachProperty in allProperties:
            listingImageQueryset = Q(listingId=eachProperty)
            if listingImageQueryset:
                data1, isCreated = ListingsImage.objects.get_or_create(
                    image_name=sampleImage[0]['image_name'],
                    image_url=sampleImage[0]['image_url'],
                    listingId=eachProperty,
                    createdBy=user,
                    updatedBy=user
                )

                data2, isCreated = ListingsImage.objects.get_or_create(
                    image_name=sampleImage[1]['image_name'],
                    image_url=sampleImage[1]['image_url'],
                    listingId=eachProperty,
                    createdBy=user,
                    updatedBy=user
                )

    return render(request, 'property_images.html', context)


@xframe_options_exempt
def propertyDetails(request, property_id):
    settings.BASE_URL = request.get_host()
    if not Listings.objects.filter(pk=property_id).exists():
        raise Http404
    else:
        property_details, mobile_property_details = makePropertyDetailsData(
            Listings.objects.get(pk=property_id), request.user, request)  #  .first()
        context = {
            'property': property_details,
            'baseUrl': settings.BASE_URL,
            'token': request.GET['token']
        }
        # print(context)
        return render(request, 'property_details.html', context)


def enter_n_prop(request):
    return render(request, 'add_properties.html')


@csrf_exempt
def add_n_prop(request):
    if request.method == 'POST':
        location = ['123 6th St.Melbourne, FL 32904', '4 Goldfield Rd.Honolulu, HI 96815',
                    '71 Pilgrim Avenue Chevy Chase, MD 20815', '44 Shirley Ave.We Chicago, IL 60185',
                    '70 Bowman St.South Windsor, CT6074']
        lat_list = ['40.273502', '38.573936', '27.994402', '39.876019', '45.367584', '44.182205']
        long_list = ['-86.126976', '-92.603760', '-81.760254', '-117.224121', '-68.972168', '-84.506836']
        sale_or_rent = [True, False]
        has_fsbo_agent = [True, False]
        has_seller_agent = [True, False]
        has_basement = [True, False]
        listing_roof_type = [True, False]  # status of tile, shingle, asphalt, metal and other
        home_type = ['SingleFamily', 'Apar', 'Apartment']
        n_prop = int(request.POST.get('num_prop'))
        user_list = [u.id for u in User.objects.all()]
        start_datetime = datetime.datetime(year=2014, month=1, day=1, hour=00, minute=00, second=00)
        numdays = 365 * 3
        created_date_list = [start_datetime + datetime.timedelta(days=x, minutes=y) for x in sample(range(5, numdays), 100)
                                                                        for y in sample(range(2, 30), 10)]
        updated_date_list = [created_date_list[i] + datetime.timedelta(days=randrange(200, 365),
                                                                       minutes=randrange(20, 60))
                             for i in range(len(created_date_list))]

        for i in range(n_prop):
            hasFSBO_flag = has_fsbo_agent[randint(0, len(has_fsbo_agent)-1)]
            hasAgent_flag = has_seller_agent[randint(0, len(has_fsbo_agent)-1)]
            lat_flag = randint(0, len(lat_list)-1)
            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            print(date_create)
            print(date_update)
            listing_obj = Listings(
                                    title="Property_"+str(i+1),
                                    hasFSBO=hasFSBO_flag,
                                    fsboUUID=SellerFsbo.objects.get(user_id=29) if hasFSBO_flag else None,
                                    hasAgent=hasAgent_flag,
                                    agentUUID=SellerAgent.objects.get(user_id=28) if hasAgent_flag else None,
                                    listingAddress=location[randrange(len(location))],
                                    latitude=lat_list[lat_flag],
                                    longitude=long_list[lat_flag],
                                    createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                    updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                    createdDate=date_create,
                                    updatedDate=date_update,
                                    isForSale=sale_or_rent[randrange(len(sale_or_rent))],
                                    isForRent=sale_or_rent[randrange(len(sale_or_rent))]
            )
            listing_obj.save()
            print(listing_obj.id)
            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_details_obj = ListingsDetails(
                                                    listingId_id=listing_obj.id,
                                                    homeType=home_type[randrange(len(home_type))],
                                                    bedrooms=randint(1, 3),
                                                    baths=float(randint(1, 3)),
                                                    hoaFees=uniform(1000.50, 10345.89),
                                                    hoaFeesCurrency=Currency.objects.get(id=1),
                                                    hasBasement=has_basement[randrange(len(has_basement))],
                                                    basementSize=randint(1000, 3000),
                                                    floorSpace=randint(100, 300),
                                                    coveredTerraceSpace=randint(100, 300),
                                                    uncoveredTerraceSpace=randint(100, 300),
                                                    plotSize=randint(1500, 3500),
                                                    yearBuilt=randint(2005, 2017),
                                                    createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                    updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                    createdDate=date_create,
                                                    updatedDate=date_update,
                                                   )
            listings_details_obj.save()
            print(listings_details_obj.id)
            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_roof_obj = ListingsRoof(
                                                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                                                tile=listing_roof_type[randrange(len(listing_roof_type))],
                                                shingle=listing_roof_type[randrange(len(listing_roof_type))],
                                                asphalt=listing_roof_type[randrange(len(listing_roof_type))],
                                                metal=listing_roof_type[randrange(len(listing_roof_type))],
                                                other=listing_roof_type[randrange(len(listing_roof_type))],
                                                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                createdDate=date_create,
                                                updatedDate=date_update,
                                            )
            listings_roof_obj.save()
            print(listings_roof_obj)
            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_exterior_finish = ListingsExteriorFinish(
                                                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                                                cement=listing_roof_type[randrange(len(listing_roof_type))],
                                                brick=listing_roof_type[randrange(len(listing_roof_type))],
                                                metal=listing_roof_type[randrange(len(listing_roof_type))],
                                                shingle=listing_roof_type[randrange(len(listing_roof_type))],
                                                stone=listing_roof_type[randrange(len(listing_roof_type))],
                                                stucco=listing_roof_type[randrange(len(listing_roof_type))],
                                                vinyl=listing_roof_type[randrange(len(listing_roof_type))],
                                                wood=listing_roof_type[randrange(len(listing_roof_type))],
                                                woodProducts=listing_roof_type[randrange(len(listing_roof_type))],
                                                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                createdDate=date_create,
                                                updatedDate=date_update,
                                                            )
            listings_exterior_finish.save()
            print(listings_exterior_finish.id)
            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_services = ListingsServices(
                                                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                                                publicWater=listing_roof_type[randrange(len(listing_roof_type))],
                                                publicSewage=listing_roof_type[randrange(len(listing_roof_type))],
                                                publicGarbage=listing_roof_type[randrange(len(listing_roof_type))],
                                                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                createdDate=date_create,
                                                updatedDate=date_update,
                                                )
            listings_services.save()
            print(listings_services.id)
            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_separate_rooms = ListingsSeparateRooms(
                                                    listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                                                    diningRoom=listing_roof_type[randrange(len(listing_roof_type))],
                                                    laundryRoom=listing_roof_type[randrange(len(listing_roof_type))],
                                                    library=listing_roof_type[randrange(len(listing_roof_type))],
                                                    office=listing_roof_type[randrange(len(listing_roof_type))],
                                                    masterBathroom=listing_roof_type[randrange(len(listing_roof_type))],
                                                    workshop=listing_roof_type[randrange(len(listing_roof_type))],
                                                    solarium=listing_roof_type[randrange(len(listing_roof_type))],
                                                    gardenShed=listing_roof_type[randrange(len(listing_roof_type))],
                                                    guestApartment=listing_roof_type[randrange(len(listing_roof_type))],
                                                    createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                    updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                                                    createdDate=date_create,
                                                    updatedDate=date_update,
                                                            )
            listings_separate_rooms.save()
            print(listings_separate_rooms.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_indoor_features = ListingsIndoorFeatures(
                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                hasBroadbandInternet=listing_roof_type[randrange(len(listing_roof_type))],
                internetSpeed=choice([256, 512, 1024, 2048]),
                hasFireplace=listing_roof_type[randrange(len(listing_roof_type))],
                fireplaceCount=choice(range(5)),
                hasDoubleGlazing=listing_roof_type[randrange(len(listing_roof_type))],
                hasSecuritySystemBasic=listing_roof_type[randrange(len(listing_roof_type))],
                hasSecuritySystemAdvanced=listing_roof_type[randrange(len(listing_roof_type))],
                smartHomeWired=listing_roof_type[randrange(len(listing_roof_type))],
                highCeilings=listing_roof_type[randrange(len(listing_roof_type))],
                skylights=listing_roof_type[randrange(len(listing_roof_type))],
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_indoor_features.save()
            print(listings_indoor_features.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_indoor_features_views = ListingsIndoorFeaturesViews(
                listingIndoorFeaturesId=ListingsIndoorFeatures.objects.get(id=listings_indoor_features.id),
                mountain=listing_roof_type[randrange(len(listing_roof_type))],
                water=listing_roof_type[randrange(len(listing_roof_type))],
                forest=listing_roof_type[randrange(len(listing_roof_type))],
                city=listing_roof_type[randrange(len(listing_roof_type))],
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_indoor_features_views.save()
            print(listings_indoor_features_views.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_indoor_features_location_setting = ListingsIndoorFeaturesLocationSetting(
                listingIndoorFeaturesId=ListingsIndoorFeatures.objects.get(id=listings_indoor_features.id),
                mountain=listing_roof_type[randrange(len(listing_roof_type))],
                waterfront=listing_roof_type[randrange(len(listing_roof_type))],
                forest=listing_roof_type[randrange(len(listing_roof_type))],
                city=listing_roof_type[randrange(len(listing_roof_type))],
                valley=listing_roof_type[randrange(len(listing_roof_type))],
                coastal=listing_roof_type[randrange(len(listing_roof_type))],
                inland=listing_roof_type[randrange(len(listing_roof_type))],
                suburb=listing_roof_type[randrange(len(listing_roof_type))],
                rural=listing_roof_type[randrange(len(listing_roof_type))],
                farm=listing_roof_type[randrange(len(listing_roof_type))],
                highrise=listing_roof_type[randrange(len(listing_roof_type))],
                lowrise=listing_roof_type[randrange(len(listing_roof_type))],
                peaceful=listing_roof_type[randrange(len(listing_roof_type))],
                busy=listing_roof_type[randrange(len(listing_roof_type))],
                international=listing_roof_type[randrange(len(listing_roof_type))],
                local=listing_roof_type[randrange(len(listing_roof_type))],
                forSeniors=listing_roof_type[randrange(len(listing_roof_type))],
                forFamilies=listing_roof_type[randrange(len(listing_roof_type))],
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_indoor_features_location_setting.save()
            print(listings_indoor_features_location_setting.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_outdoor_features = ListingsOutdoorFeatures(
                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                guesthouse=listing_roof_type[randrange(len(listing_roof_type))],
                swimmingPool=listing_roof_type[randrange(len(listing_roof_type))],
                hottub=listing_roof_type[randrange(len(listing_roof_type))],
                fence=listing_roof_type[randrange(len(listing_roof_type))],
                gatedEntry=listing_roof_type[randrange(len(listing_roof_type))],
                balcony=listing_roof_type[randrange(len(listing_roof_type))],
                deck=listing_roof_type[randrange(len(listing_roof_type))],
                terrace=listing_roof_type[randrange(len(listing_roof_type))],
                bbqArea=listing_roof_type[randrange(len(listing_roof_type))],
                dock=listing_roof_type[randrange(len(listing_roof_type))],
                gardenSmall=listing_roof_type[randrange(len(listing_roof_type))],
                gardenLarge=listing_roof_type[randrange(len(listing_roof_type))],
                gardenAcreage=listing_roof_type[randrange(len(listing_roof_type))],
                sauna=listing_roof_type[randrange(len(listing_roof_type))],
                sprinkler=listing_roof_type[randrange(len(listing_roof_type))],
                generator=listing_roof_type[randrange(len(listing_roof_type))],
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_outdoor_features.save()
            print(listings_outdoor_features.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_cooling_system = ListingsCoolingSystem(
                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                electric=listing_roof_type[randrange(len(listing_roof_type))],
                green=listing_roof_type[randrange(len(listing_roof_type))],
                other=listing_roof_type[randrange(len(listing_roof_type))],
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_cooling_system.save()
            print(listings_cooling_system.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_heating_system = ListingsHeatingSystem(
                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                gas=ListingsDetails.objects.get(id=listings_details_obj.id),
                wood=ListingsDetails.objects.get(id=listings_details_obj.id),
                electric=ListingsDetails.objects.get(id=listings_details_obj.id),
                green=ListingsDetails.objects.get(id=listings_details_obj.id),
                other=ListingsDetails.objects.get(id=listings_details_obj.id),
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_heating_system.save()
            print(listings_heating_system.id)

            date_create = choice(created_date_list)
            date_update = updated_date_list[created_date_list.index(date_create)]
            listings_life_style_fit = ListingsLifestyleFit(
                listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
                createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                createdDate=date_create,
                updatedDate=date_update,
            )
            listings_life_style_fit.save()
            print(listings_life_style_fit.id)

            # date_create = choice(created_date_list)
            # date_update = updated_date_list[created_date_list.index(date_create)]
            # listings_apartment_building = ListingsApartmentBuilding(
            #     doorman=models.BooleanField(default=False)
            # intercom = models.BooleanField(default=False)
            # elevator = models.BooleanField(default=False)
            # floorLevel = models.IntegerField(default=0, null=False)
            # sportsCourts = models.BooleanField(default=False)
            # gym = models.BooleanField(default=False)
            # pool = models.BooleanField(default=False)
            # sauna = models.BooleanField(default=False)
            # concierge = models.BooleanField(default=False)
            # storage = models.BooleanField(default=False)
            # nearTransportation = models.BooleanField(default=False)
            # seniorCommunity = models.BooleanField(default=False)
            # adultCommunity = models.BooleanField(default=False)
            # familyCommunity = models.BooleanField(default=False)
            # gatedEntry = models.BooleanField(default=False)
            #     listingsDetailsId=ListingsDetails.objects.get(id=listings_details_obj.id),
            #     createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
            #     updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
            #     createdDate=date_create,
            #     updatedDate=date_update,
            # )
            # listings_apartment_building.save()
            # print(listings_apartment_building.id)

        response_dict = {"data": n_prop}
        return JsonResponse(response_dict)


#@renderer_classes((JSONRenderer,))
@csrf_exempt
def add_prop_from_idealista(request):
    if request.method == 'POST':
        resp_status, response = idealista_properties()
        if resp_status:
            user_list = [u.id for u in User.objects.all()]
            sale_or_rent = [True, False]
            address_list = ["address", "province", "municipality", "district", "country"]

            for prop in response:
                address = ""
                for element in address_list:
                    if element in prop:
                        if address_list.index(element) != len(element) - 1:
                            address += prop[element]+", "
                        else:
                            address += prop[element]

                if "suggestedTexts" in prop:
                    if "title" in prop["suggestedTexts"]:
                        prop_title = prop["suggestedTexts"]["title"]
                    elif "suggestedTexts" in prop["suggestedTexts"]:
                        prop_title = prop["suggestedTexts"]["suggestedTexts"]
                    else:
                        prop_title = prop["title"]+", "+prop["suggestedTexts"]
                else:
                    prop_title = ""
                listing_obj = Listings(
                    title=prop_title,
                    fsboUUID=SellerFsbo.objects.get(user_id=29),
                    agentUUID=SellerAgent.objects.get(user_id=28),
                    listingAddress=address,
                    photosList=prop["numPhotos"] if "numPhotos" in prop else 0,
                    latitude=prop["latitude"] if "latitude" in prop else "",
                    longitude=prop["longitude"] if "longitude" in prop else "",
                    gooleAddressResponse=prop["district"]+", "+prop["municipality"],
                    createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                    updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                    isForSale=sale_or_rent[randrange(len(sale_or_rent))],
                    isForRent=sale_or_rent[randrange(len(sale_or_rent))]
                )
                listing_obj.save()
                listings_details_obj = ListingsDetails(
                    listingId_id=listing_obj.id,
                    homeType=prop["propertyType"] if "propertyType" in prop else "",
                    bedrooms=prop["rooms"] if "rooms" in prop else 0,
                    baths=prop["bathrooms"] if "bathrooms" in prop else 0,
                    plotSize=prop["size"] if "size" in prop else 0,
                    hoaFees=prop["price"] if "price" in prop else 0.0,
                    hasCoveredParking=prop["parkingSpace"]["hasParkingSpace"] if "parkingSpace" in prop and "hasParkingSpace" in prop["parkingSpace"] else False,
                    hoaFeesCurrency=Currency.objects.get(id=2),
                    createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                    updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                )
                listings_details_obj.save()

                listings_image_obj = ListingsImage(
                    image_url=prop["thumbnail"] if "thumbnail" in prop else "",
                    listingId=Listings.objects.get(id=listing_obj.id),
                    createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                    updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                )
                listings_image_obj.save()
            msg = {"Message": "Properties are added successfully...", "Status": resp_status}
            #return Response(msg, status=status.HTTP_200_OK) #, content_type="application/json")
            return JsonResponse(msg, status=status.HTTP_200_OK)
        else:
            msg = {"Message": response, "Status": resp_status}
            return JsonResponse(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR) #, content_type="application/json")


class add_prop_from_zillow(generics.ListCreateAPIView):
        queryset = Document.objects.all()
        serializer_class = DocumentSerializer
        authentication_classes = (TokenAuthentication,)
        permission_classes = (AllowAny,)
        parser_classes = (JSONParser, FormParser, MultiPartParser)
        renderer_classes = (JSONRenderer, BrowsableAPIRenderer, HTMLFormRenderer, MultiPartRenderer)

        def get(self, request):
            results = Document.objects.all()
            serializer = self.serializer_class(results, many=True)
            return Response(serializer.data)

        def post(self, request):
            responseErrors = []
            responseSuccess = []
            responseData = {}
            user = request.user
            user_list = [u.id for u in User.objects.all()]
            sale_or_rent = [True, False]
            ######################### API Calling parameters ########################
            import requests
            from xml.etree import ElementTree as ET
            zws_id = "X1-ZWz19157nv4cuj_14qhc"
            url = "http://www.zillow.com/webservice/GetDeepSearchResults.htm"
            image_url_list = ["https://photos.zillowstatic.com/p_h/ISmu9yf26oxqig1000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/IS6a7i49km2vgu0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISi3us2196wuau0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISi3us2196wuau0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISu8q28t7gv6200000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/IS6m40y5h117xk0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISyz1dy0law7i91000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISyn4n29os8h3f0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISalajttrvqp2a0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISap99ghfmfi8l0000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISyjpoazjgnmpu1000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISiff15luc4h270000000000.jpg",
                              "https://photos.zillowstatic.com/p_h/ISatkgcho1wnun0000000000.jpg",
                              ]
            headers = {
                'Content-Type': "application/x-www-form-urlencoded",
                'Cache-Control': "no-cache",
                'Postman-Token': "0f2d5f65-753a-2dad-734f-b7f4090e06d8"
            }
            ########################### API CALLING PARAMETERS end here ####################
            try:
                property_csv_content = request.FILES['document']
                fs = FileSystemStorage(location='static/media/zillow/')
                csv_name = fs.save(property_csv_content.name, property_csv_content)
                uploaded_csv_url = fs.url(csv_name)
                fp = open('static/media/zillow/' + uploaded_csv_url, "r")
                csv_dict = csv.DictReader(fp)
                for row in csv_dict:
                    address = row["Address"]
                    zip = row["Zip"]
                    payload = "zws-id=" + zws_id + "&address=" + address + "&citystatezip=" + zip
                    response = requests.request("POST", url, data=payload, headers=headers)
                    root = ET.fromstring(response.content)

                    ## Variables holds data for properties creation
                    address = None
                    latitude = None
                    longitude = None
                    amount = None
                    finishedSqFt = None
                    bathrooms = None
                    bedrooms = None
                    useCode = None

                    for iterator in root.getiterator():
                        if iterator.tag == "request":
                            for element in iterator:
                                if element.tag == "address":
                                    address = element.text

                        if iterator.tag == "address":
                            for element in iterator:
                                if element.tag == "latitude":
                                    latitude = element.text
                                if element.tag == "longitude":
                                    longitude = element.text

                        if iterator.tag == "zestimate":
                            for element in iterator:
                                if element.tag == "amount":
                                    amount = element.text

                        if iterator.tag == "finishedSqFt":
                            finishedSqFt = iterator.text

                        if iterator.tag == "bathrooms":
                            bathrooms = iterator.text

                        if iterator.tag == "bedrooms":
                            bedrooms = iterator.text

                        if iterator.tag == "useCode":
                            useCode = iterator.text

                    # print("address", address, type(address))
                    # print("latitude", latitude, type(latitude))
                    # print("longitude", longitude, type(latitude))
                    # print("amount", amount, type(amount))
                    # print("finishedSqFt", finishedSqFt, type(finishedSqFt))
                    # print("bathrooms", bathrooms, type(bathrooms))
                    # print("bedrooms", bedrooms, type(bedrooms))
                    # print("useCode", useCode, type(useCode))

                    listing_obj = Listings(
                        title="zillow_prop",
                        fsboUUID=SellerFsbo.objects.get(user_id=29),
                        agentUUID=SellerAgent.objects.get(user_id=28),
                        listingAddress=address if address else "",
                        latitude=latitude if latitude else "",
                        longitude=longitude if longitude else "",
                        gooleAddressResponse=address,
                        createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                        updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                        isForSale=sale_or_rent[randrange(len(sale_or_rent))],
                        isForRent=sale_or_rent[randrange(len(sale_or_rent))]
                    )
                    listing_obj.save()
                    print(listing_obj)

                    listings_details_obj = ListingsDetails(
                        listingId_id=listing_obj.id,
                        homeType=useCode if useCode else "",
                        bedrooms=int(bedrooms) if bedrooms else 0,
                        baths= int(float(bathrooms)) if bathrooms else 0,
                        plotSize=int(finishedSqFt) if finishedSqFt else 0,
                        hoaFees=float(amount) if amount else 0.0,
                        hoaFeesCurrency=Currency.objects.get(id=1),
                        createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                        updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                    )
                    listings_details_obj.save()
                    print(listings_details_obj)

                    listings_image_obj = ListingsImage(
                        image_url=image_url_list[randrange(len(image_url_list))],
                        listingId=Listings.objects.get(id=listing_obj.id),
                        createdBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                        updatedBy=User.objects.get(id=user_list[randrange(len(user_list))]),
                    )
                    listings_image_obj.save()

            except ValueError:
                msg = {"Message":ValueError, "Status": False}
                return JsonResponse(msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            else:
                msg = {"Message": "Properties are added successfully...", "Status": True}
                return JsonResponse(msg, status=status.HTTP_200_OK)

def find_indoor_features(feature):
    if 'features' not in feature.keys():
        feature = feature['desc']
    elif 'desc' not in feature.keys():
        feature = feature['features']
    else:
        feature = feature['features'] + feature['desc']

    data_dict = dict()
    if 'internet' in feature.lower():
        data_dict['hasBroadbandInternet'] = True
    else:
        data_dict['hasBroadbandInternet'] = False

    if 'fire' in feature.lower():
        data_dict['hasFireplace'] = True
    else:
        data_dict['hasFireplace'] = False

    if 'security' in feature.lower():
        data_dict['hasSecuritySystemBasic'] = True
        data_dict['hasSecuritySystemAdvanced'] = True
    else:
        data_dict['hasSecuritySystemBasic'] = False
        data_dict['hasSecuritySystemAdvanced'] = False

    if 'smart home' in feature.lower() or 'smart' in feature.lower():
        data_dict['smartHomeWired'] = True
    else:
        data_dict['smartHomeWired'] = False

    return data_dict

def find_outdoor_features(feature):
    if 'features' not in feature.keys():
        feature = feature['desc']
    elif 'desc' not in feature.keys():
        feature = feature['features']
    else:
        feature = feature['features'] + feature['desc']
    data_dict = dict()
    if 'pool' in feature.lower():
        data_dict['swimmingPool'] = True
    else:
        data_dict['swimmingPool'] = False

    if 'balcony' in feature.lower():
        data_dict['balcony'] = True
    else:
        data_dict['balcony'] = False

    if 'terrace' in feature.lower():
        data_dict['terrace'] = True
    else:
        data_dict['terrace'] = False

    if 'bbq' in feature.lower() or 'barbeque' in feature.lower():
        data_dict['bbqArea'] = True
    else:
        data_dict['bbqArea'] = False

    if 'garden' in feature.lower():
        data_dict['gardenLarge'] = True
        data_dict['gardenSmall'] = True
    else:
        data_dict['gardenLarge'] = False
        data_dict['gardenSmall'] = False

    if 'sauna' in feature.lower():
        data_dict['sauna'] = True
    else:
        data_dict['sauna'] = False

    if 'sprinkler' in feature.lower():
        data_dict['sprinkler'] = True
    else:
        data_dict['sprinkler'] = False

    if 'generator' in feature.lower():
        data_dict['generator'] = True
    else:
        data_dict['generator'] = False

    return data_dict

def find_heating_features(feature):
    if 'features' not in feature.keys():
        feature = feature['desc']
    elif 'desc' not in feature.keys():
        feature = feature['features']
    else:
        feature = feature['features'] + feature['desc']
    data_dict = dict()
    if 'air condition' in feature.lower():
        data_dict['cooling'] = True
        data_dict['heating'] = True
    elif 'hot' in feature.lower():
        data_dict['heating'] = True
    elif 'cold' in feature.lower():
        data_dict['cooling'] = True
    else:
        data_dict['heating'] = False
        data_dict['cooling'] = False

    return data_dict


def find_parking_features(feature):
    if 'features' not in feature.keys():
        feature = feature['desc']
    elif 'desc' not in feature.keys():
        feature = feature['features']
    else:
        feature = feature['features'] + feature['desc']
    data_dict = dict()
    if 'parking' in feature.lower() or 'garage' in feature.lower():
        data_dict['hasCoveredParking'] = True
    else:
        data_dict['hasCoveredParking'] = False

    return data_dict


class add_prop_from_csv(generics.ListCreateAPIView):
    queryset = Property_CSV_Document.objects.all()
    serializer_class = DocumentSerializer
    authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)
    parser_classes = (JSONParser, FormParser, MultiPartParser)
    renderer_classes = (JSONRenderer, BrowsableAPIRenderer, HTMLFormRenderer, MultiPartRenderer)

    def get(self, request):
        results = Document.objects.all()
        serializer = self.serializer_class(results, many=True)
        return Response(serializer.data)

    def post(self, request):
        msg_list = list()
        msg = ''
        video_url_list = ['https://youtu.be/FVfryjShtOw',
                          'https://youtu.be/sH12SaATIL0',
                          'https://youtu.be/Z5oW4OGyV4A',
                          'https://youtu.be/ATSgwZXOuUo',
                          'https://youtu.be/15OFyDu9GqM',
                          'https://youtu.be/jlpd0zaqKwE',
                          'https://youtu.be/RHm9ulk_W7c',
                          'https://youtu.be/daU-da75ByA',
                          'https://youtu.be/XFOYGZkr11Y',
                          'https://youtu.be/hm7nxs2To5Y',
                          'https://www.youtube.com/watch?v=TGgdGXXwAvA',
                          'https://www.youtube.com/watch?v=1sJm3GbzDQ8',
                          'https://www.youtube.com/watch?v=gBm-yU97AGE']
        try:
            property_csv_content = request.FILES['document']
            fs = FileSystemStorage(location='static/media/property_csv/')
            csv_name = fs.save(property_csv_content.name, property_csv_content)
            uploaded_csv_url = fs.url(csv_name)
            print(uploaded_csv_url)
            fp = open('static/media/property_csv/' + uploaded_csv_url.replace('/media/', ''), "r")
            if '.csv' in fp.name:
                csv_dict = csv.DictReader(fp)
                csv_cols_name = csv_dict.fieldnames
                msg1=''
                for row in csv_dict:
                    if len(row['address']):
                        print(row)
                        try:
                            prop_category, isForSale, isForRent = None, None, None
                            if row["price_freq"].lower() == 'sale':
                                prop_category = 'Resales'
                                isForSale = True
                                isForRent = False
                            elif row["price_freq"].lower() == 'month':
                                prop_category = 'Rent'
                                isForRent = True
                                isForSale = False
                            elif row["price_freq"].lower() in ['new_build', 'new build']:
                                prop_category = 'New build'
                                isForSale = True
                                isForRent = False

                            more_features, description = '', ''
                            indoor_features, outdoor_features, heating_features, parking_features = None, None, None, None
                            if 'features' in csv_cols_name or 'desc' in csv_cols_name:
                                if 'features' in csv_cols_name:
                                    more_features = row['features'].replace(';', ', ')
                                if 'desc' in csv_cols_name:
                                    description = row['desc'].replace(';', ', ').strip().replace("'\"''", "")
                                indoor_features = find_indoor_features(row)

                                outdoor_features = find_outdoor_features(row)
                                if len(row['pools']):
                                    outdoor_features['swimmingPool'] = True
                                heating_features = find_heating_features(row)
                                parking_features = find_parking_features(row)

                            beds = row['beds'] if len(row['beds']) else 0
                            baths = row['baths'] if len(row['baths']) else 0
                            build = row['built'] if len(row['built']) else 0.000
                            plot = row['plot'] if len(row['plot']) else 0.000
                            price = row["price"] if len(row["price"]) else 0.000


                            # # Get or Create Listings obj
                            listing_obj, listing_obj_status = Listings.objects.get_or_create(title="Ref #"+row["ref"], category=prop_category,
                                                                                 description=description, listingAddress=row['address'],
                                                                                 latitude=row['lat'], longitude=row['long'],
                                                                                 isForSale=isForSale, isForRent=isForRent,
                                                                                 createdBy=User.objects.get(id=choice([28, 29])),
                                                                                 updatedBy=User.objects.get(id=choice([28, 29])),
                                                                                 more_feature=more_features, is_spain_property=True,
                                                                                 fsboUUID=SellerFsbo.objects.get(user_id=29),
                                                                                 agentUUID=SellerAgent.objects.get(user_id=28))

                            if listing_obj_status:
                                # Create Video URL
                                ListingsVideo.objects.create(
                                    video_url=video_url_list[randrange(len(video_url_list))],
                                    createdBy=User.objects.get(id=choice([28, 29])),
                                    updatedBy=User.objects.get(id=choice([28, 29])),
                                    listingId=Listings.objects.get(id=listing_obj.id)
                                )
                                # Add Images
                                image_list = row['images'].split(';')
                                for image in image_list:
                                    ListingsImage.objects.create(listingId=Listings.objects.get(id=listing_obj.id),
                                                                 image_url=image,
                                                                 createdBy=User.objects.get(id=choice([28, 29])),
                                                                 updatedBy=User.objects.get(id=choice([28, 29]))
                                                                 )


                                # Get or Create ListingsDetails obj
                                listings_detail_obj, listings_detail_obj_status = ListingsDetails.objects.get_or_create(homeType=row['type'], bedrooms=beds,
                                                                                                    baths=baths, hoaFees=price,
                                                                                                    hoaFeesCurrency=Currency.objects.get(id=2),
                                                                                                    floorSpace=build, plotSize=plot,
                                                                                                    hasCoveredParking=parking_features['hasCoveredParking'],
                                                                                                    listingId=listing_obj,
                                                                                                    createdBy=User.objects.get(id=choice([28, 29])),
                                                                                                    updatedBy=User.objects.get(id=choice([28, 29]))
                                                                                                    )

                                if listings_detail_obj_status:
                                    # Add Indoor features
                                    ListingsIndoorFeatures.objects.create(hasBroadbandInternet=indoor_features['hasBroadbandInternet'],
                                                                          hasFireplace=indoor_features['hasFireplace'],
                                                                          hasSecuritySystemBasic=indoor_features['hasSecuritySystemBasic'],
                                                                          hasSecuritySystemAdvanced=indoor_features['hasSecuritySystemAdvanced'],
                                                                          smartHomeWired=indoor_features['smartHomeWired'],
                                                                          listingsDetailsId=listings_detail_obj,
                                                                          createdBy=User.objects.get(id=choice([28, 29])),
                                                                          updatedBy=User.objects.get(id=choice([28, 29]))
                                                                          )
                                    # Add Outdoor features
                                    ListingsOutdoorFeatures.objects.create(swimmingPool=outdoor_features['swimmingPool'],
                                                                           balcony=outdoor_features['balcony'],
                                                                           terrace=outdoor_features['terrace'],
                                                                           bbqArea=outdoor_features['bbqArea'],
                                                                           gardenSmall=outdoor_features['gardenSmall'],
                                                                           gardenLarge=outdoor_features['gardenLarge'],
                                                                           sauna=outdoor_features['sauna'],
                                                                           sprinkler=outdoor_features['sprinkler'],
                                                                           generator=outdoor_features['generator'],
                                                                           listingsDetailsId=listings_detail_obj,
                                                                           createdBy=User.objects.get(id=choice([28, 29])),
                                                                           updatedBy=User.objects.get(id=choice([28, 29]))
                                                                           )
                                    # Add Cooling System
                                    if heating_features['cooling']:
                                        ListingsCoolingSystem.objects.create(listingsDetailsId=listings_detail_obj,
                                                                             createdBy=User.objects.get(id=choice([28, 29])),
                                                                             updatedBy=User.objects.get(id=choice([28, 29])),
                                                                             electric=True
                                                                            )
                                    # Add Heating System
                                    if heating_features['heating']:
                                        ListingsHeatingSystem.objects.create(listingsDetailsId=listings_detail_obj,
                                                                             createdBy=User.objects.get(id=choice([28, 29])),
                                                                             updatedBy=User.objects.get(id=choice([28, 29])),
                                                                             electric=True
                                                                            )

                                    msg1 = 'listing_id:{} is created and listingDetails_id:{} is also created'.format(listing_obj.id, listings_detail_obj.id)
                                    msg_list.append(msg1)

                        except Exception as e:
                            print(e)
                fp.close()
                msg=msg_list

            else:
                fp.close()
                msg = {"Message": "Please choose CSV file !!!", "Status": False}
        except Exception as e:
            pass


        #msg = {"Message": "Properties are added successfully...", "Status": True}
        return Response(msg, status=status.HTTP_200_OK)

