from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^sync/(?P<address>.+)/(?P<citystatezip>.+)$', views.index, name='property_sync'),
    url(r'^details/(?P<property_id>.+)$', views.propertyDetails, name='property_details'),
    url(r'^sync_images_only/(?P<limit>.+)/(?P<offset>.+)$', views.propertyImages, name='property_images'),
    url(r'^n_prop$', views.enter_n_prop, name='enter_n_properties'),  # Enter how many (n) properties
    url(r'^n_prop/add$', views.add_n_prop, name='add_n_properties'),  # Create property data randomly
    url(r'^add_prop/idealista$', views.add_prop_from_idealista, name='add_properties_from_idealista'),
    url(r'^add_prop/zillow$', views.add_prop_from_zillow.as_view(), name='add_properties_from_zillow'),
    url(r'^property_bulk_upload', views.add_prop_from_csv.as_view(), name='upload_properties_from_CSV'),
]
