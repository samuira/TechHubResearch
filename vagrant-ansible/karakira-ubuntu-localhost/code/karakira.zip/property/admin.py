# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import *
from .forms import *
from django.utils.translation import ugettext, ugettext_lazy as _
import sys
# Register your models here.


class ListingsAdmin(admin.ModelAdmin):
    form = ListingsFormAdmin

    fieldsets = (
        (_('Listing'), {'fields': ('is_karakira_certified','hasFSBO', 'fsboUUID', 'hasAgent', 'agentUUID', 'hasAmbassador', 'ambassadorUUID', 'listingAddress', 'latitude', 'longitude', 'contactName', 'contactEmail', 'contactMobile', 'photosList', 'videosList', 'vrList')}),
        (_('Listing Details'), {'fields': ('homeType', 'isHighRise', 'bedrooms', 'baths', 'hoaFeesCurrency', 'hoaFees', 'hasBasement', 'basementSize', 'floorSpace', 'coveredTerraceSpace', 'uncoveredTerraceSpace', 'plotSize',
                                           'yearBuilt', 'needsMinorRenovation', 'needsModerateRenovation', 'needsMajorRenovation', 'hasGarage', 'garageSize', 'hasCoveredParking', 'parkingSpaces', 'openHouseAllowed', 'appliancesIncluded', 'floorType')}),
        (_('Roof'), {'fields': ('tile', 'roof_shingle', 'asphalt', 'roof_metal', 'roofOther')}),
        (_('Exterior Finish'), {'fields': ('cement', 'brick', 'exterior_metal', 'exterior_shingle', 'stone', 'stucco', 'vinyl', 'wood', 'woodProducts')}),
        (_('Services'), {'fields': ('publicWater', 'publicSewage', 'publicGarbage')}),
        (_('Separate Rooms'), {'fields': ('diningRoom', 'laundryRoom', 'library', 'office', 'masterBathroom', 'workshop', 'solarium', 'gardenShed', 'guestApartment')}),
        (_('Indoor Features'), {'fields': ('hasBroadbandInternet', 'internetSpeed', 'hasFireplace', 'fireplaceCount', 'hasDoubleGlazing', 'hasSecuritySystemBasic', 'hasSecuritySystemAdvanced', 'smartHomeWired', 'highCeilings', 'skylights')}),
        (_('Indoor Features Views'), {'fields': ('viewsMountain', 'viewsWater', 'viewsForest', 'viewsCity')}),
        (_('Indoor Features Location'), {'fields': ('indoorMountain', 'indoorValley', 'coastal', 'waterfront', 'inland', 'forest', 'indoorCity',
                                                    'suburb', 'rural', 'farm', 'highrise', 'lowrise', 'peaceful', 'busy', 'international', 'local', 'forSeniors', 'forFamilies')}),
        (_('Outdoor Feature'), {'fields': ('guesthouse', 'swimmingPool', 'hottub', 'fence', 'outdoorGatedEntry', 'balcony', 'deck',
                                           'terrace', 'bbqArea', 'dock', 'gardenSmall', 'gardenLarge', 'gardenAcreage', 'outdoorSauna', 'sprinkler', 'generator')}),
        (_('Cooling System'), {'fields': ('coolingElectric', 'coolingGreen', 'coolingOther')}),
        (_('Heating System'), {'fields': ('oil', 'gas', 'heatingWood', 'electric', 'green', 'other')}),
        (_('Lifestyle Fit'), {'fields': ('lifestyle1', 'lifestyle2', 'lifestyle3', 'lifestyle1Weight', 'lifestyle2Weight', 'lifestyle3Weight')}),
        (_('Apartment Building'), {'fields': ('doorman', 'intercom', 'elevator', 'floorLevel', 'sportsCourts', 'gym', 'pool', 'sauna',
                                              'concierge', 'storage', 'nearTransportation', 'seniorCommunity', 'adultCommunity', 'familyCommunity', 'gatedEntry')}),
        (_('Image'), {'fields': ('image_name', 'image_url')}),
    )

    def save_model(self, request, obj, form, change):
        formData = form.cleaned_data
        print("#form.cleaned_data", form.cleaned_data)
        user = request.user.id
        # print(user)
        # sys.exit()
        if not change:
            obj.datesRegistered = timezone.now()
            obj.datesDeregistered = timezone.now()
            obj.lastActive = timezone.now()
            obj.is_karakira_certified = formData.get('is_karakira_certified')
            obj.hasFSBO = formData.get('hasFSBO')
            obj.fsboUUID = formData.get('fsboUUID') if formData.get('fsboUUID') is not None else None
            obj.agentUUID = formData.get('agentUUID') if formData.get('agentUUID') is not None else None
            obj.ambassadorUUID = formData.get('ambassadorUUID') if formData.get('ambassadorUUID') is not None else None
            obj.listingAddress = formData.get('listingAddress')
            obj.latitude = formData.get('latitude')
            obj.longitude = formData.get('longitude')
            obj.contactName = formData.get('contactName')
            obj.contactEmail = formData.get('contactEmail')
            obj.contactMobile = formData.get('contactMobile')
            obj.createdBy_id = user
            obj.updatedBy_id = user
            obj.save()
            listingsDetails = ListingsDetails.objects.create(
                homeType=formData.get('homeType'),
                isHighRise=formData.get('isHighRise'),
                bedrooms=formData.get('bedrooms'),
                baths=formData.get('baths'),
                hoaFees=formData.get('hoaFees'),
                hasBasement=formData.get('hasBasement'),
                basementSize=formData.get('basementSize'),
                floorSpace=formData.get('floorSpace'),
                coveredTerraceSpace=formData.get('coveredTerraceSpace'),
                uncoveredTerraceSpace=formData.get('uncoveredTerraceSpace'),
                plotSize=formData.get('plotSize'),
                yearBuilt=formData.get('yearBuilt'),
                needsMinorRenovation=formData.get('needsMinorRenovation'),
                needsModerateRenovation=formData.get('needsModerateRenovation'),
                needsMajorRenovation=formData.get('needsMajorRenovation'),
                hasGarage=formData.get('hasGarage'),
                garageSize=formData.get('garageSize'),
                hasCoveredParking=formData.get('hasCoveredParking'),
                parkingSpaces=formData.get('parkingSpaces'),
                openHouseAllowed=formData.get('openHouseAllowed'),
                appliancesIncluded=formData.get('appliancesIncluded'),
                floorType=formData.get('floorType'),
                listingId=obj,
                hoaFeesCurrency=formData.get('hoaFeesCurrency'),
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsRoof.objects.create(
                tile=formData.get('tile'),
                shingle=formData.get('roof_shingle'),
                asphalt=formData.get('asphalt'),
                metal=formData.get('roof_metal'),
                other=formData.get('other'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsExteriorFinish.objects.create(
                cement=formData.get('cement'),
                brick=formData.get('brick'),
                metal=formData.get('exterior_metal'),
                shingle=formData.get('exterior_shingle'),
                stone=formData.get('stone'),
                stucco=formData.get('stucco'),
                vinyl=formData.get('vinyl'),
                wood=formData.get('wood'),
                woodProducts=formData.get('woodProducts'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsServices.objects.create(
                publicWater=formData.get('publicWater'),
                publicSewage=formData.get('publicSewage'),
                publicGarbage=formData.get('publicGarbage'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsSeparateRooms.objects.create(
                diningRoom=formData.get('diningRoom'),
                laundryRoom=formData.get('laundryRoom'),
                library=formData.get('library'),
                office=formData.get('office'),
                masterBathroom=formData.get('masterBathroom'),
                workshop=formData.get('workshop'),
                solarium=formData.get('solarium'),
                gardenShed=formData.get('gardenShed'),
                guestApartment=formData.get('guestApartment'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            listingsIndoorFeatures = ListingsIndoorFeatures.objects.create(
                hasBroadbandInternet=formData.get('hasBroadbandInternet'),
                internetSpeed=formData.get('internetSpeed'),
                hasFireplace=formData.get('hasFireplace'),
                fireplaceCount=formData.get('fireplaceCount'),
                hasDoubleGlazing=formData.get('hasDoubleGlazing'),
                hasSecuritySystemBasic=formData.get('hasSecuritySystemBasic'),
                hasSecuritySystemAdvanced=formData.get('hasSecuritySystemAdvanced'),
                smartHomeWired=formData.get('smartHomeWired'),
                highCeilings=formData.get('highCeilings'),
                skylights=formData.get('skylights'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsIndoorFeaturesViews.objects.create(
                mountain=formData.get('viewsMountain'),
                water=formData.get('viewsWater'),
                forest=formData.get('forest'),
                city=formData.get('viewsCity'),
                listingIndoorFeaturesId=listingsIndoorFeatures,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsIndoorFeaturesLocationSetting.objects.create(
                mountain=formData.get('indoorMountain'),
                valley=formData.get('indoorValley'),
                coastal=formData.get('coastal'),
                waterfront=formData.get('waterfront'),
                inland=formData.get('inland'),
                forest=formData.get('forest'),
                city=formData.get('indoorCity'),
                suburb=formData.get('suburb'),
                rural=formData.get('rural'),
                farm=formData.get('farm'),
                highrise=formData.get('highrise'),
                lowrise=formData.get('lowrise'),
                peaceful=formData.get('peaceful'),
                busy=formData.get('busy'),
                international=formData.get('international'),
                local=formData.get('local'),
                forSeniors=formData.get('forSeniors'),
                forFamilies=formData.get('forFamilies'),
                listingIndoorFeaturesId=listingsIndoorFeatures,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsOutdoorFeatures.objects.create(
                guesthouse=formData.get('guesthouse'),
                swimmingPool=formData.get('swimmingPool'),
                hottub=formData.get('hottub'),
                fence=formData.get('fence'),
                gatedEntry=formData.get('gatedEntry'),
                balcony=formData.get('balcony'),
                deck=formData.get('deck'),
                terrace=formData.get('terrace'),
                bbqArea=formData.get('bbqArea'),
                dock=formData.get('dock'),
                gardenSmall=formData.get('gardenSmall'),
                gardenLarge=formData.get('gardenLarge'),
                gardenAcreage=formData.get('gardenAcreage'),
                sauna=formData.get('sauna'),
                sprinkler=formData.get('sprinkler'),
                generator=formData.get('generator'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsCoolingSystem.objects.create(
                electric=formData.get('coolingElectric'),
                green=formData.get('coolingGreen'),
                other=formData.get('coolingOther'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsHeatingSystem.objects.create(
                oil=formData.get('oil'),
                gas=formData.get('gas'),
                wood=formData.get('heatingWood'),
                electric=formData.get('electric'),
                green=formData.get('green'),
                other=formData.get('other'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsLifestyleFit.objects.create(
                lifestyle1=formData.get('lifestyle1') if formData.get('lifestyle1') is not None else "",
                lifestyle2=formData.get('lifestyle2') if formData.get('lifestyle2') is not None else "",
                lifestyle3=formData.get('lifestyle3') if formData.get('lifestyle3') is not None else "",
                lifestyle1Weight=formData.get('lifestyle1Weight') if formData.get('lifestyle1Weight') is not None else "",
                lifestyle2Weight=formData.get('lifestyle2Weight') if formData.get('lifestyle1Weight') is not None else "",
                lifestyle3Weight=formData.get('lifestyle3Weight') if formData.get('lifestyle1Weight') is not None else "",
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
            ListingsApartmentBuilding.objects.create(
                doorman=formData.get('doorman'),
                intercom=formData.get('intercom'),
                elevator=formData.get('elevator'),
                floorLevel=formData.get('floorLevel'),
                sportsCourts=formData.get('sportsCourts'),
                gym=formData.get('gym'),
                pool=formData.get('pool'),
                sauna=formData.get('sauna'),
                concierge=formData.get('concierge'),
                storage=formData.get('storage'),
                nearTransportation=formData.get('nearTransportation'),
                seniorCommunity=formData.get('seniorCommunity'),
                adultCommunity=formData.get('adultCommunity'),
                familyCommunity=formData.get('familyCommunity'),
                gatedEntry=formData.get('gatedEntry'),
                listingsDetailsId=listingsDetails,
                createdBy=user,
                updatedBy=user,
                createdDate=timezone.now(),
                updatedDate=timezone.now()
            )
        else:
            x = formData.get('fsboUUID') if formData.get('fsboUUID') is not None else None
            y = formData.get('agentUUID') if formData.get('agentUUID') is not None else None
            z = formData.get('ambassadorUUID') if formData.get('ambassadorUUID') is not None else None

            Listings.objects.filter(id=obj.pk).update(
                datesRegistered=timezone.now(),
                datesDeregistered=timezone.now(),
                lastActive=timezone.now(),
                hasFSBO=formData.get('hasFSBO'),
                is_karakira_certified = formData.get('is_karakira_certified'),
                fsboUUID=x,
                agentUUID=y,
                ambassadorUUID=z,
                listingAddress=formData.get('listingAddress'),
                latitude=formData.get('latitude'),
                longitude=formData.get('longitude'),
                contactName=formData.get('contactName'),
                contactEmail=formData.get('contactEmail'),
                contactMobile=formData.get('contactMobile'),
                updatedBy_id=user,
            )
            listingsDetails = ListingsDetails.objects.filter(listingId_id=obj.pk).first()

            ListingsDetails.objects.filter(listingId_id=obj.pk).update(
                homeType=formData.get('homeType'),
                isHighRise=formData.get('isHighRise'),
                bedrooms=formData.get('bedrooms'),
                baths=formData.get('baths'),
                hoaFees=formData.get('hoaFees'),
                hasBasement=formData.get('hasBasement'),
                basementSize=formData.get('basementSize'),
                floorSpace=formData.get('floorSpace'),
                coveredTerraceSpace=formData.get('coveredTerraceSpace'),
                uncoveredTerraceSpace=formData.get('uncoveredTerraceSpace'),
                plotSize=formData.get('plotSize'),
                yearBuilt=formData.get('yearBuilt'),
                needsMinorRenovation=formData.get('needsMinorRenovation'),
                needsModerateRenovation=formData.get('needsModerateRenovation'),
                needsMajorRenovation=formData.get('needsMajorRenovation'),
                hasGarage=formData.get('hasGarage'),
                garageSize=formData.get('garageSize'),
                hasCoveredParking=formData.get('hasCoveredParking'),
                parkingSpaces=formData.get('parkingSpaces'),
                openHouseAllowed=formData.get('openHouseAllowed'),
                appliancesIncluded=formData.get('appliancesIncluded'),
                floorType=formData.get('floorType'),
                listingId=obj,
                hoaFeesCurrency=formData.get('hoaFeesCurrency'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsRoof.objects.filter(listingsDetailsId=listingsDetails).update(
                tile=formData.get('tile'),
                shingle=formData.get('roof_shingle'),
                asphalt=formData.get('asphalt'),
                metal=formData.get('roof_metal'),
                other=formData.get('other'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsExteriorFinish.objects.filter(listingsDetailsId=listingsDetails).update(
                cement=formData.get('cement'),
                brick=formData.get('brick'),
                metal=formData.get('exterior_metal'),
                shingle=formData.get('exterior_shingle'),
                stone=formData.get('stone'),
                stucco=formData.get('stucco'),
                vinyl=formData.get('vinyl'),
                wood=formData.get('wood'),
                woodProducts=formData.get('woodProducts'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsServices.objects.filter(listingsDetailsId=listingsDetails).update(
                publicWater=formData.get('publicWater'),
                publicSewage=formData.get('publicSewage'),
                publicGarbage=formData.get('publicGarbage'),
                updatedBy=user,
                updatedDate=timezone.now()
            )

            listingsIndoorFeatures = ListingsIndoorFeatures.objects.filter(listingsDetailsId=listingsDetails).first()

            ListingsIndoorFeaturesViews.objects.filter(listingIndoorFeaturesId=listingsIndoorFeatures).update(
                mountain=formData.get('viewsMountain'),
                water=formData.get('viewsWater'),
                forest=formData.get('forest'),
                city=formData.get('viewsCity'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsIndoorFeaturesLocationSetting.objects.filter(listingIndoorFeaturesId=listingsIndoorFeatures).update(
                mountain=formData.get('indoorMountain'),
                valley=formData.get('indoorValley'),
                coastal=formData.get('coastal'),
                waterfront=formData.get('waterfront'),
                inland=formData.get('inland'),
                forest=formData.get('forest'),
                city=formData.get('indoorCity'),
                suburb=formData.get('suburb'),
                rural=formData.get('rural'),
                farm=formData.get('farm'),
                highrise=formData.get('highrise'),
                lowrise=formData.get('lowrise'),
                peaceful=formData.get('peaceful'),
                busy=formData.get('busy'),
                international=formData.get('international'),
                local=formData.get('local'),
                forSeniors=formData.get('forSeniors'),
                forFamilies=formData.get('forFamilies'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsOutdoorFeatures.objects.filter(listingsDetailsId=listingsDetails).update(
                guesthouse=formData.get('guesthouse'),
                swimmingPool=formData.get('swimmingPool'),
                hottub=formData.get('hottub'),
                fence=formData.get('fence'),
                gatedEntry=formData.get('gatedEntry'),
                balcony=formData.get('balcony'),
                deck=formData.get('deck'),
                terrace=formData.get('terrace'),
                bbqArea=formData.get('bbqArea'),
                dock=formData.get('dock'),
                gardenSmall=formData.get('gardenSmall'),
                gardenLarge=formData.get('gardenLarge'),
                gardenAcreage=formData.get('gardenAcreage'),
                sauna=formData.get('sauna'),
                sprinkler=formData.get('sprinkler'),
                generator=formData.get('generator'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsCoolingSystem.objects.filter(listingsDetailsId=listingsDetails).update(
                electric=formData.get('coolingElectric'),
                green=formData.get('coolingGreen'),
                other=formData.get('coolingOther'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsHeatingSystem.objects.filter(listingsDetailsId=listingsDetails).update(
                oil=formData.get('oil'),
                gas=formData.get('gas'),
                wood=formData.get('heatingWood'),
                electric=formData.get('electric'),
                green=formData.get('green'),
                other=formData.get('other'),
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsLifestyleFit.objects.filter(listingsDetailsId=listingsDetails).update(
                lifestyle1=formData.get('lifestyle1') if formData.get('lifestyle1') is not None else "",
                lifestyle2=formData.get('lifestyle2') if formData.get('lifestyle2') is not None else "",
                lifestyle3=formData.get('lifestyle3') if formData.get('lifestyle3') is not None else "",
                lifestyle1Weight=formData.get('lifestyle1Weight') if formData.get('lifestyle1Weight') is not None else "",
                lifestyle2Weight=formData.get('lifestyle2Weight') if formData.get('lifestyle1Weight') is not None else "",
                lifestyle3Weight=formData.get('lifestyle3Weight') if formData.get('lifestyle1Weight') is not None else "",
                updatedBy=user,
                updatedDate=timezone.now()
            )
            ListingsApartmentBuilding.objects.filter(listingsDetailsId=listingsDetails).update(
                doorman=formData.get('doorman'),
                intercom=formData.get('intercom'),
                elevator=formData.get('elevator'),
                floorLevel=formData.get('floorLevel'),
                sportsCourts=formData.get('sportsCourts'),
                gym=formData.get('gym'),
                pool=formData.get('pool'),
                sauna=formData.get('sauna'),
                concierge=formData.get('concierge'),
                storage=formData.get('storage'),
                nearTransportation=formData.get('nearTransportation'),
                seniorCommunity=formData.get('seniorCommunity'),
                adultCommunity=formData.get('adultCommunity'),
                familyCommunity=formData.get('familyCommunity'),
                gatedEntry=formData.get('gatedEntry'),
                updatedBy=user,
                updatedDate=timezone.now()
            )


admin.site.register(Listings, ListingsAdmin)
