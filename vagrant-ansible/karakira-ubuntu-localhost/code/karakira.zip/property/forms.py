from django import forms
from .models import *
from django.conf import settings
from site_master.models import *
from django.conf import settings
from intl_tel_input.widgets import IntlTelInputWidget
from django.db.models import Q
from django.contrib.admin import widgets
from django.contrib.auth.models import Permission, Group
from django.contrib.admin.widgets import FilteredSelectMultiple
from django.utils.translation import ugettext_lazy as _

GENDER_CHOICES = [
    [1, "Male"],
    [2, "Female"]
]


class ListingsFormAdmin(forms.ModelForm):
    model = Listings
    is_karakira_certified = forms.BooleanField(required=False)
    hasFSBO = forms.BooleanField(required=False)
    fsboUUID = forms.ModelChoiceField(queryset=SellerFsbo.objects.filter(isDeleted=False), empty_label="Select Ambassador", required=False)
    hasAgent = forms.BooleanField(required=False)
    agentUUID = forms.ModelChoiceField(queryset=SellerAgent.objects.filter(agent=True, isDeleted=False), empty_label="Select Agent", required=False)
    hasAmbassador = forms.BooleanField(required=False)
    ambassadorUUID = forms.ModelChoiceField(queryset=User.objects.filter(isdeleted=False), empty_label="Select Ambassador", required=False)
    listingAddress = forms.CharField(required=False)
    latitude = forms.CharField(required=False)
    longitude = forms.CharField(required=False)
    contactName = forms.CharField(required=False)
    contactEmail = forms.CharField(required=False)
    contactMobile = forms.CharField(required=False)
    photosList = forms.CharField(required=False)
    videosList = forms.CharField(required=False)
    vrList = forms.CharField(required=False)

    homeType = forms.CharField(required=False)
    isHighRise = forms.BooleanField(required=False)
    bedrooms = forms.IntegerField(required=True)
    baths = forms.FloatField(required=True)
    hoaFees = forms.FloatField(required=True)
    hoaFeesCurrency = forms.ModelChoiceField(queryset=Currency.objects.all(), empty_label="Select Currency", required=True)
    hasBasement = forms.BooleanField(required=False)
    basementSize = forms.IntegerField(required=True)
    floorSpace = forms.IntegerField(required=True)
    coveredTerraceSpace = forms.IntegerField(required=True)
    uncoveredTerraceSpace = forms.IntegerField(required=True)
    plotSize = forms.IntegerField(required=True)
    yearBuilt = forms.IntegerField(required=True)
    needsMinorRenovation = forms.BooleanField(required=False)
    needsModerateRenovation = forms.BooleanField(required=False)
    needsMajorRenovation = forms.BooleanField(required=False)
    hasGarage = forms.BooleanField(required=False)
    garageSize = forms.IntegerField(required=True)
    hasCoveredParking = forms.BooleanField(required=False)
    parkingSpaces = forms.IntegerField(required=True)
    openHouseAllowed = forms.BooleanField(required=False)
    appliancesIncluded = forms.BooleanField(required=False)
    floorType = forms.CharField(required=False)

    tile = forms.BooleanField(required=False)
    roof_shingle = forms.BooleanField(required=False)
    asphalt = forms.BooleanField(required=False)
    roof_metal = forms.BooleanField(required=False)
    roofOther = forms.BooleanField(required=False)

    cement = forms.BooleanField(required=False)
    brick = forms.BooleanField(required=False)
    exterior_metal = forms.BooleanField(required=False)
    exterior_shingle = forms.BooleanField(required=False)
    stone = forms.BooleanField(required=False)
    stucco = forms.BooleanField(required=False)
    vinyl = forms.BooleanField(required=False)
    wood = forms.BooleanField(required=False)
    woodProducts = forms.BooleanField(required=False)

    publicWater = forms.BooleanField(required=False)
    publicSewage = forms.BooleanField(required=False)
    publicGarbage = forms.BooleanField(required=False)

    diningRoom = forms.BooleanField(required=False)
    laundryRoom = forms.BooleanField(required=False)
    library = forms.BooleanField(required=False)
    office = forms.BooleanField(required=False)
    masterBathroom = forms.BooleanField(required=False)
    workshop = forms.BooleanField(required=False)
    solarium = forms.BooleanField(required=False)
    gardenShed = forms.BooleanField(required=False)
    guestApartment = forms.BooleanField(required=False)

    hasBroadbandInternet = forms.BooleanField(required=False)
    internetSpeed = forms.IntegerField(required=True)
    hasFireplace = forms.BooleanField(required=False)
    fireplaceCount = forms.IntegerField(required=True)
    hasDoubleGlazing = forms.BooleanField(required=False)
    hasSecuritySystemBasic = forms.BooleanField(required=False)
    hasSecuritySystemAdvanced = forms.BooleanField(required=False)
    smartHomeWired = forms.BooleanField(required=False)
    highCeilings = forms.BooleanField(required=False)
    skylights = forms.BooleanField(required=False)

    viewsMountain = forms.BooleanField(required=False)
    viewsWater = forms.BooleanField(required=False)
    viewsForest = forms.BooleanField(required=False)
    viewsCity = forms.BooleanField(required=False)

    indoorMountain = forms.BooleanField(required=False)
    indoorValley = forms.BooleanField(required=False)
    coastal = forms.BooleanField(required=False)
    waterfront = forms.BooleanField(required=False)
    inland = forms.BooleanField(required=False)
    forest = forms.BooleanField(required=False)
    indoorCity = forms.BooleanField(required=False)
    suburb = forms.BooleanField(required=False)
    rural = forms.BooleanField(required=False)
    farm = forms.BooleanField(required=False)
    highrise = forms.BooleanField(required=False)
    lowrise = forms.BooleanField(required=False)
    peaceful = forms.BooleanField(required=False)
    busy = forms.BooleanField(required=False)
    international = forms.BooleanField(required=False)
    local = forms.BooleanField(required=False)
    forSeniors = forms.BooleanField(required=False)
    forFamilies = forms.BooleanField(required=False)

    guesthouse = forms.BooleanField(required=False)
    swimmingPool = forms.BooleanField(required=False)
    hottub = forms.BooleanField(required=False)
    fence = forms.BooleanField(required=False)
    outdoorGatedEntry = forms.BooleanField(required=False)
    balcony = forms.BooleanField(required=False)
    deck = forms.BooleanField(required=False)
    terrace = forms.BooleanField(required=False)
    bbqArea = forms.BooleanField(required=False)
    dock = forms.BooleanField(required=False)
    gardenSmall = forms.BooleanField(required=False)
    gardenLarge = forms.BooleanField(required=False)
    gardenAcreage = forms.BooleanField(required=False)
    outdoorSauna = forms.BooleanField(required=False)
    sprinkler = forms.BooleanField(required=False)
    generator = forms.BooleanField(required=False)

    coolingElectric = forms.BooleanField(required=False)
    coolingGreen = forms.BooleanField(required=False)
    coolingOther = forms.BooleanField(required=False)

    oil = forms.BooleanField(required=False)
    gas = forms.BooleanField(required=False)
    heatingWood = forms.BooleanField(required=False)
    electric = forms.BooleanField(required=False)
    green = forms.BooleanField(required=False)
    other = forms.BooleanField(required=False)

    lifestyle1 = forms.CharField(required=False)
    lifestyle2 = forms.CharField(required=False)
    lifestyle3 = forms.CharField(required=False)
    lifestyle1Weight = forms.CharField(required=False)
    lifestyle2Weight = forms.CharField(required=False)
    lifestyle3Weight = forms.CharField(required=False)

    doorman = forms.BooleanField(required=False)
    intercom = forms.BooleanField(required=False)
    elevator = forms.BooleanField(required=False)
    floorLevel = forms.IntegerField(required=False)
    sportsCourts = forms.BooleanField(required=False)
    gym = forms.BooleanField(required=False)
    pool = forms.BooleanField(required=False)
    sauna = forms.BooleanField(required=False)
    concierge = forms.BooleanField(required=False)
    storage = forms.BooleanField(required=False)
    nearTransportation = forms.BooleanField(required=False)
    seniorCommunity = forms.BooleanField(required=False)
    adultCommunity = forms.BooleanField(required=False)
    familyCommunity = forms.BooleanField(required=False)
    gatedEntry = forms.BooleanField(required=False)

    image_name = forms.CharField(required=False)
    image_url = forms.CharField(required=False)

    def __init__(self, *args, **kwargs):
        super(ListingsFormAdmin, self).__init__(*args, **kwargs)
        instance = getattr(self, 'instance', None)
        if instance and instance.pk:
            listingDetails = ListingsDetails.objects.filter(listingId=instance).first()
            if ListingsDetails:
                self.initial['bedrooms'] = listingDetails.bedrooms
                self.initial['baths'] = listingDetails.baths
                self.initial['homeType'] = listingDetails.homeType
                self.initial['isHighRise'] = listingDetails.isHighRise
                self.initial['hasBasement'] = listingDetails.hasBasement
                self.initial['basementSize'] = listingDetails.basementSize
                self.initial['floorSpace'] = listingDetails.floorSpace
                self.initial['coveredTerraceSpace'] = listingDetails.coveredTerraceSpace
                self.initial['uncoveredTerraceSpace'] = listingDetails.uncoveredTerraceSpace
                self.initial['plotSize'] = listingDetails.plotSize
                self.initial['yearBuilt'] = listingDetails.yearBuilt
                self.initial['needsMinorRenovation'] = listingDetails.needsMinorRenovation
                self.initial['needsModerateRenovation'] = listingDetails.needsModerateRenovation
                self.initial['needsMajorRenovation'] = listingDetails.needsMajorRenovation
                self.initial['hasGarage'] = listingDetails.hasGarage
                self.initial['garageSize'] = listingDetails.garageSize
                self.initial['hasCoveredParking'] = listingDetails.hasCoveredParking
                self.initial['parkingSpaces'] = listingDetails.parkingSpaces
                self.initial['openHouseAllowed'] = listingDetails.openHouseAllowed
                self.initial['appliancesIncluded'] = listingDetails.appliancesIncluded
                self.initial['floorType'] = listingDetails.floorType
                self.initial['hoaFeesCurrency'] = listingDetails.hoaFeesCurrency
                self.initial['hoaFees'] = listingDetails.hoaFees

            if listingDetails and listingDetails.pk:
                listingRoof = ListingsRoof.objects.filter(listingsDetailsId=listingDetails).first()
                print("############ listingRoof", listingRoof)
                if listingRoof:  # ListingsRoof
                    self.initial['tile'] = listingRoof.tile
                    self.initial['roof_shingle'] = listingRoof.shingle
                    self.initial['asphalt'] = listingRoof.asphalt
                    self.initial['roof_metal'] = listingRoof.metal
                    self.initial['roofOther'] = listingRoof.other

            if listingDetails and listingDetails.pk:
                listingExteriorFinish = ListingsExteriorFinish.objects.filter(listingsDetailsId=listingDetails).first()
                if listingExteriorFinish:   # ListingsExteriorFinish
                    self.initial['cement'] = listingExteriorFinish.cement
                    self.initial['brick'] = listingExteriorFinish.brick
                    self.initial['exterior_metal'] = listingExteriorFinish.metal
                    self.initial['exterior_shingle'] = listingExteriorFinish.shingle
                    self.initial['stone'] = listingExteriorFinish.stone
                    self.initial['stucco'] = listingExteriorFinish.stucco
                    self.initial['vinyl'] = listingExteriorFinish.vinyl
                    self.initial['wood'] = listingExteriorFinish.wood
                    self.initial['woodProducts'] = listingExteriorFinish.woodProducts

            if listingDetails and listingDetails.pk:
                listingsServices = ListingsServices.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsServices:  # ListingsServices
                    self.initial['publicWater'] = listingsServices.publicWater
                    self.initial['publicSewage'] = listingsServices.publicSewage
                    self.initial['publicGarbage'] = listingsServices.publicGarbage

            if listingDetails and listingDetails.pk:
                listingsSeparateRooms = ListingsSeparateRooms.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsSeparateRooms:  # ListingsSeparateRooms
                    self.initial['diningRoom'] = listingsSeparateRooms.diningRoom
                    self.initial['laundryRoom'] = listingsSeparateRooms.laundryRoom
                    self.initial['library'] = listingsSeparateRooms.library
                    self.initial['office'] = listingsSeparateRooms.office
                    self.initial['masterBathroom'] = listingsSeparateRooms.masterBathroom
                    self.initial['workshop'] = listingsSeparateRooms.workshop
                    self.initial['solarium'] = listingsSeparateRooms.solarium
                    self.initial['gardenShed'] = listingsSeparateRooms.gardenShed
                    self.initial['guestApartment'] = listingsSeparateRooms.guestApartment

            if listingDetails and listingDetails.pk:
                listingsIndoorFeatures = ListingsIndoorFeatures.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsIndoorFeatures:  # ListingsIndoorFeatures
                    self.initial['hasBroadbandInternet'] = listingsIndoorFeatures.hasBroadbandInternet
                    self.initial['internetSpeed'] = listingsIndoorFeatures.internetSpeed
                    self.initial['hasFireplace'] = listingsIndoorFeatures.hasFireplace
                    self.initial['fireplaceCount'] = listingsIndoorFeatures.fireplaceCount
                    self.initial['hasDoubleGlazing'] = listingsIndoorFeatures.hasDoubleGlazing
                    self.initial['hasSecuritySystemBasic'] = listingsIndoorFeatures.hasSecuritySystemBasic
                    self.initial['hasSecuritySystemAdvanced'] = listingsIndoorFeatures.hasSecuritySystemAdvanced
                    self.initial['smartHomeWired'] = listingsIndoorFeatures.smartHomeWired
                    self.initial['highCeilings'] = listingsIndoorFeatures.highCeilings
                    self.initial['skylights'] = listingsIndoorFeatures.skylights

            if listingDetails and listingDetails.pk:
                listingsIndoorFeaturesViews = ListingsIndoorFeaturesViews.objects.filter(listingIndoorFeaturesId=listingsIndoorFeatures).first()
                if listingsIndoorFeaturesViews:  # ListingsIndoorFeaturesViews
                    self.initial['viewsMountain'] = listingsIndoorFeaturesViews.mountain
                    self.initial['viewsWater'] = listingsIndoorFeaturesViews.water
                    self.initial['viewsForest'] = listingsIndoorFeaturesViews.forest
                    self.initial['viewsCity'] = listingsIndoorFeaturesViews.city

            if listingDetails and listingDetails.pk:
                listingsIndoorFeaturesLocationSetting = ListingsIndoorFeaturesLocationSetting.objects.filter(listingIndoorFeaturesId=listingsIndoorFeatures).first()
                if listingsIndoorFeaturesLocationSetting:  # ListingsIndoorFeaturesLocationSetting
                    self.initial['indoorMountain'] = listingsIndoorFeaturesLocationSetting.mountain
                    self.initial['indoorValley'] = listingsIndoorFeaturesLocationSetting.valley
                    self.initial['coastal'] = listingsIndoorFeaturesLocationSetting.coastal
                    self.initial['inland'] = listingsIndoorFeaturesLocationSetting.inland
                    self.initial['forest'] = listingsIndoorFeaturesLocationSetting.forest
                    self.initial['indoorCity'] = listingsIndoorFeaturesLocationSetting.city
                    self.initial['suburb'] = listingsIndoorFeaturesLocationSetting.suburb
                    self.initial['rural'] = listingsIndoorFeaturesLocationSetting.rural
                    self.initial['farm'] = listingsIndoorFeaturesLocationSetting.farm
                    self.initial['highrise'] = listingsIndoorFeaturesLocationSetting.highrise
                    self.initial['lowrise'] = listingsIndoorFeaturesLocationSetting.lowrise
                    self.initial['peaceful'] = listingsIndoorFeaturesLocationSetting.peaceful
                    self.initial['busy'] = listingsIndoorFeaturesLocationSetting.busy
                    self.initial['international'] = listingsIndoorFeaturesLocationSetting.international
                    self.initial['local'] = listingsIndoorFeaturesLocationSetting.local
                    self.initial['forSeniors'] = listingsIndoorFeaturesLocationSetting.forSeniors
                    self.initial['forFamilies'] = listingsIndoorFeaturesLocationSetting.forFamilies
                    self.initial['waterfront'] = listingsIndoorFeaturesLocationSetting.waterfront

            if listingDetails and listingDetails.pk:
                listingsOutdoorFeatures = ListingsOutdoorFeatures.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsOutdoorFeatures:  # ListingsOutdoorFeatures
                    self.initial['guesthouse'] = listingsOutdoorFeatures.guesthouse
                    self.initial['swimmingPool'] = listingsOutdoorFeatures.swimmingPool
                    self.initial['hottub'] = listingsOutdoorFeatures.hottub
                    self.initial['fence'] = listingsOutdoorFeatures.fence
                    self.initial['outdoorGatedEntry'] = listingsOutdoorFeatures.gatedEntry
                    self.initial['dock'] = listingsOutdoorFeatures.dock
                    self.initial['deck'] = listingsOutdoorFeatures.deck
                    self.initial['terrace'] = listingsOutdoorFeatures.terrace
                    self.initial['bbqArea'] = listingsOutdoorFeatures.bbqArea
                    self.initial['gardenSmall'] = listingsOutdoorFeatures.gardenSmall
                    self.initial['gardenLarge'] = listingsOutdoorFeatures.gardenLarge
                    self.initial['gardenAcreage'] = listingsOutdoorFeatures.gardenAcreage
                    self.initial['outdoorSauna'] = listingsOutdoorFeatures.sauna
                    self.initial['sprinkler'] = listingsOutdoorFeatures.sprinkler
                    self.initial['generator'] = listingsOutdoorFeatures.generator
                    self.initial['balcony'] = listingsOutdoorFeatures.balcony

            if listingDetails and listingDetails.pk:
                listingsCoolingSystem = ListingsCoolingSystem.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsCoolingSystem:  # ListingsCoolingSystem
                    self.initial['coolingElectric'] = listingsCoolingSystem.electric
                    self.initial['coolingGreen'] = listingsCoolingSystem.green
                    self.initial['coolingOther'] = listingsCoolingSystem.other

            if listingDetails and listingDetails.pk:
                listingsHeatingSystem = ListingsHeatingSystem.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsHeatingSystem:  # ListingsHeatingSystem
                    self.initial['oil'] = listingsHeatingSystem.oil
                    self.initial['gas'] = listingsHeatingSystem.gas
                    self.initial['heatingWood'] = listingsHeatingSystem.wood
                    self.initial['electric'] = listingsHeatingSystem.electric
                    self.initial['green'] = listingsHeatingSystem.green
                    self.initial['other'] = listingsHeatingSystem.other

            if listingDetails and listingDetails.pk:
                listingsLifestyleFit = ListingsLifestyleFit.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsLifestyleFit:
                    self.initial['lifestyle1'] = listingsLifestyleFit.lifestyle1
                    self.initial['lifestyle2'] = listingsLifestyleFit.lifestyle2
                    self.initial['lifestyle3'] = listingsLifestyleFit.lifestyle3
                    self.initial['lifestyle1Weight'] = listingsLifestyleFit.lifestyle1Weight
                    self.initial['lifestyle2Weight'] = listingsLifestyleFit.lifestyle2Weight
                    self.initial['lifestyle3Weight'] = listingsLifestyleFit.lifestyle3Weight

            if listingDetails and listingDetails.pk:
                listingsApartmentBuilding = ListingsApartmentBuilding.objects.filter(listingsDetailsId=listingDetails).first()
                if listingsApartmentBuilding:
                    self.initial['doorman'] = listingsApartmentBuilding.doorman
                    self.initial['intercom'] = listingsApartmentBuilding.intercom
                    self.initial['elevator'] = listingsApartmentBuilding.elevator
                    self.initial['floorLevel'] = listingsApartmentBuilding.floorLevel
                    self.initial['sportsCourts'] = listingsApartmentBuilding.sportsCourts
                    self.initial['gym'] = listingsApartmentBuilding.gym
                    self.initial['pool'] = listingsApartmentBuilding.pool
                    self.initial['sauna'] = listingsApartmentBuilding.sauna
                    self.initial['concierge'] = listingsApartmentBuilding.concierge
                    self.initial['storage'] = listingsApartmentBuilding.storage
                    self.initial['nearTransportation'] = listingsApartmentBuilding.nearTransportation
                    self.initial['seniorCommunity'] = listingsApartmentBuilding.seniorCommunity
                    self.initial['adultCommunity'] = listingsApartmentBuilding.adultCommunity
                    self.initial['familyCommunity'] = listingsApartmentBuilding.familyCommunity
                    self.initial['gatedEntry'] = listingsApartmentBuilding.gatedEntry

            if listingDetails and listingDetails.pk:
                listingsImage = ListingsImage.objects.filter(listingId=instance).first()
                if listingsImage:
                    self.initial['image_name'] = listingsImage.image_name
                    self.initial['image_url'] = listingsImage.image_url
