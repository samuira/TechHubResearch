
class GlobalMember:
    order_number = {}
    plan_number = {}