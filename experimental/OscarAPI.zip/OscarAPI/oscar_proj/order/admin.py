from oscar.apps.order.admin import *

# Register your models here.
