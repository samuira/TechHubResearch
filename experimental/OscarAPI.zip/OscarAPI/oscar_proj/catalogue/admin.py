#from django.contrib import admin
from oscar.apps.catalogue.admin import *

# Register your models here.
