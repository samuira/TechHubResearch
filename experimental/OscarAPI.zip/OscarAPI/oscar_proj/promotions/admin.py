#from django.contrib import admin
from oscar.apps.promotions.admin import *

# Register your models here.
