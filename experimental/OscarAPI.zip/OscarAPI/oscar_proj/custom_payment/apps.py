from django.apps import AppConfig


class CustomPaymentConfig(AppConfig):
    name = 'custom_payment'
