from django.apps import AppConfig


class CustomOscarApiConfig(AppConfig):
    name = 'custom_oscar_api'
