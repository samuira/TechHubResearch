# For place search
'''
    lat = result["results"][0]["geometry"]["location"]["lat"]
    lng = result["results"][0]["geometry"]["location"]["lng"]
    address: result["results"][0]["formatted_address"]
    icon : result["results"][0]["icon"]`
    '''
gmap = gmplot.GoogleMapPlotter(lat_list[0], lng_list[0],8) #, zoom, apikey)
    gmap.scatter(lat_list, lng_list, 'cornflowerblue', edge_width=10)
    
    for i in range(len(result["results"])):
	    gmap.marker(lat_list[i], lng_list[i], color='#FF0000', c=None, title=name_list[i]+"@"+address_list[i])
    
    del lat_list
    del lng_list
    del address_list
    del name_list
    file_name = settings.BASE_DIR + "/gis/templates/places.html"
    gmap.draw(file_name)
    
# For direction
gmaps = GoogleMaps(gmap_api_key)
		source_city = request.GET.get('source')
		print(source_city)
    dest_city = request.GET.get('destination')
    print(dest_city)
    mode = request.GET.get('mode')
    print(mode)
        
        gmaps = GoogleMaps(gmap_api_key)
        place_result = gmaps.geocode(place_name)
        placemark = place_result[0]['geometry']
        place_lat = placemark['location']['lat']# Note these are backwards from usual
        place_lng = placemark['location']['lng']
        print(place_lat,place_lng)
        
    gmaps = GoogleMaps(gmap_api_key)
    source_city = request.GET.get('source')
    print(source_city)
    dest_city = request.GET.get('destination')
    print(dest_city)
    mode = request.GET.get('mode')
    print(mode)
    
    source_result = gmaps.geocode(source_city)
    placemark = source_result[0]['geometry']
    source_lat = placemark['location']['lat']    # Note these are backwards from usual
    source_lng = placemark['location']['lng']
    print(source_lat,source_lng)
    
    dest_result = gmaps.geocode(dest_city)
    placemark = dest_result[0]['geometry']
    dest_lat = placemark['location']['lat']    # Note these are backwards from usual
    dest_lng = placemark['location']['lng']
    print(dest_lat,dest_lng)
    
    direction = gmaps.directions((source_lat,source_lng),(dest_lat,dest_lng),mode=mode)
    
    
# Path plot
    '''
    steps = direction[0]['legs'] # it is a list
    gmap = gmplot.GoogleMapPlotter(steps[0]["start_location"]["lat"],steps[0]["start_location"]["lng"],8)
    lat_list = list()
    lng_list = list()
    for i in range(len(steps)):
	    if i == 0:
		    city = gmaps.reverse_geocode({'lat': steps[i]["start_location"]["lat"], 'lng': steps[i]["start_location"]["lng"]})
		    place_title = city
		    gmap.marker(steps[i]["start_location"]["lat"],steps[i]["start_location"]["lng"], color="yellow", c=None, \
		    title=place_title)
	    elif i == len(steps) - 1:
		    city = gmaps.reverse_geocode({'lat': steps[i]["start_location"]["lat"], \
		    'lng': steps[i]["start_location"]["lng"]})
		    place_title = city
		    gmap.marker(steps[i]["start_location"]["lat"],steps[i]["start_location"]["lng"], color="cornflowerblue", c=None, title=place_title)
	    else:
		    city = gmaps.reverse_geocode({'lat': steps[i]["start_location"]["lat"],\
		    'lng': steps[i]["start_location"]["lng"]})
		    place_title = city
		    gmap.marker(steps[i]["start_location"]["lat"],steps[i]["start_location"]["lng"], \
		    color="#FF0000", c=None, title=place_title)
    file_name = settings.BASE_DIR + "/gis/templates/direction.html"
    gmap.draw(file_name)
    '''
https://stackoverflow.com/questions/10397255/how-can-i-display-country-borders-us-state-borders-and-city-borders-using-goog
