from django.apps import AppConfig


class GisConfig(AppConfig):
    name = 'gis'
