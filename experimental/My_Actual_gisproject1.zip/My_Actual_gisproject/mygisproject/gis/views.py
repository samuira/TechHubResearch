import googlemaps
from googlemaps import Client as GoogleMaps
import gmplot 
from django.conf import settings
from rest_framework.renderers import StaticHTMLRenderer,TemplateHTMLRenderer,JSONRenderer,BrowsableAPIRenderer
from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
from rest_framework.decorators import renderer_classes
from rest_framework.response import Response
from django.http import HttpResponseRedirect
from django.views.decorators import csrf
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, loader
from django.http import HttpResponseRedirect, HttpResponse
from django.http import JsonResponse
gmap_api_key = settings.API_KEY

@csrf_exempt
def index(request):
    template = loader.get_template('gis/index.html')
    html = template.render()
    return HttpResponse(html)
    
@csrf_exempt
#@renderer_classes((JSONRenderer,BrowsableAPIRenderer,))
def addcity(request,format=None):
	
	#form_class = AddcityForm 
	if request.method == 'POST':
		print("Abhisek",request.POST)
		city_name = request.POST.get('city_name')
		print(city_name)
		gmaps = GoogleMaps(gmap_api_key)
		result = gmaps.geocode(city_name)
		print(result)
		formatted_address = result[0]['formatted_address']
		print(formatted_address)
		placemark = result[0]['geometry']
		lat = placemark['location']['lat']    # Note these are backwards from usual
		lng = placemark['location']['lng']
		print(lat,lng)
		city = {
					'city_name': formatted_address,
					'city_lat': lat,
					'city_lng': lng,
				}
		return JsonResponse(city)
		
@api_view(('GET',))
@renderer_classes((JSONRenderer,BrowsableAPIRenderer,))
def search_city(request, format=None):
    """
    A view that can accept a city via. GET call paramerter and show the city on Google MAP
    """
    gmaps = GoogleMaps(gmap_api_key)
    city = request.GET.get('city')
    print(city)
    result = gmaps.geocode(city)
    print(result)
    formatted_address = result[0]['formatted_address']
    print(formatted_address)
    placemark = result[0]['geometry']
    lat = placemark['location']['lat']    # Note these are backwards from usual
    lng = placemark['location']['lng']
    print(lat,lng)
    gmap = gmplot.GoogleMapPlotter(lat,lng,8)
    lat_list = list()
    lat_list.append(lat)
    lng_list = list()
    lng_list.append(lng)
    gmap.scatter(lat_list, lng_list, 'cornflowerblue', edge_width=10)
    city_title =formatted_address
    gmap.marker(lat,lng, color='#FF0000', c=None, title=city_title)
    print(settings.BASE_DIR)
    file_name = settings.BASE_DIR + "/gis/templates/serach_city.html"
    gmap.draw(file_name)
    #fp = open(file_name,'r')
    #data = fp.read()
    #print(data) 
    del lat_list
    del lng_list
    #data = "<html><body><a href='file:///home/dat-asset-227/code/mygisproject/gis/templates/serach_city.html'>Open Google Map</a></body></html>"
    #return Response(template_name='success_serach_city.html')#data)
    return Response(result)
    
#@api_view(('GET',))
#@renderer_classes((JSONRenderer,BrowsableAPIRenderer,))
@csrf_exempt
def direction(request, format=None):
    """
    A view that can accept two cities and mode (driving,walking and transit) via. GET call paramerter and show direction on Google MAP
    """
    # Query Sample : http://127.0.0.1:8000/direction?source=Howrah&destination=Kolkata&mode=driving
    if request.method == 'POST':
        print("Abhisek",request.POST)
        source_name = request.POST.get('source')
        print(source_name)
        
        dest_name = request.POST.get('dest')
        print(dest_name)
        
        travel_mode = request.POST.get('mode')
        travel_mode_lower = travel_mode.lower()
        print(travel_mode)
        gmaps = GoogleMaps(gmap_api_key)
        
        source_result = gmaps.geocode(source_name)
        placemark = source_result[0]['geometry']
        source_lat = placemark['location']['lat']
        source_lng = placemark['location']['lng']
        print(source_lat,source_lng)
        
        dest_result = gmaps.geocode(dest_name)
        placemark = dest_result[0]['geometry']
        dest_lat = placemark['location']['lat']
        dest_lng = placemark['location']['lng']
        print(dest_lat,dest_lng)
        
        direction = gmaps.directions((source_lat,source_lng),(dest_lat,dest_lng),mode=travel_mode_lower)
        
        source_lat_lng = list()
        source_lat_lng.append(source_lat)
        source_lat_lng.append(source_lng)
        
        dest_lat_lng = list()
        dest_lat_lng.append(dest_lat)
        dest_lat_lng.append(dest_lng)
        
        Direction_dict = {'Source': source_lat_lng,'Destination': dest_lat_lng,'Direction': direction,'Mode':travel_mode}
        return JsonResponse(Direction_dict)

@csrf_exempt
def show_weather(request, format=None):
	"""
	This API shows weather of a location
	"""
	if request.method == 'POST':
		print("Abhisek",request.POST)
		location_name = request.POST.get('location')
		print(location_name)
		gmaps = GoogleMaps(gmap_api_key)
		location_result = gmaps.geocode(location_name)
		placemark = location_result[0]['geometry']
		location_lat = placemark['location']['lat']# Note these are backwards from usual
		location_lng = placemark['location']['lng']
		print(location_lat,location_lng)
		formatted_address = location_result[0]['formatted_address']
		city = {
					'city_name': formatted_address,
					'city_lat': location_lat,
					'city_lng': location_lng,
				}
		return JsonResponse(city)
		
@csrf_exempt
def draw_ploygon(request, format=None):
	"""
	This API draws polygon over a location
	"""
	if request.method == 'POST':
		print("Abhisek",request.POST)
		location_name = request.POST.get('location')
		print(location_name)
		gmaps = GoogleMaps(gmap_api_key)
		location_result = gmaps.geocode(location_name)
		placemark = location_result[0]['geometry']
		location_lat = placemark['location']['lat']# Note these are backwards from usual
		location_lng = placemark['location']['lng']
		print(location_lat,location_lng)
		formatted_address = location_result[0]['formatted_address']
		city = {
					'city_name': formatted_address,
					'city_lat': location_lat,
					'city_lng': location_lng,
				}
		return JsonResponse(city)
	
#@api_view(('GET',))
#@renderer_classes((JSONRenderer,BrowsableAPIRenderer,))
@csrf_exempt
def place(request, format=None):
    """
    A view that accepts a location and place type (restaurant,hospitals,shopping malls) via. GET call paramerter and show on Google MAP
    """
    # Query Sample : http://127.0.0.1:8000/places?place=Howrah&type=restaurant
    if request.method == 'POST':
        print("Abhisek",request.POST)
        place_name = request.POST.get('place')
        print(place_name)
        place_type = request.POST.get('type')
        gmaps = GoogleMaps(gmap_api_key)
        place_result = gmaps.geocode(place_name)
        placemark = place_result[0]['geometry']
        place_lat = placemark['location']['lat']# Note these are backwards from usual
        place_lng = placemark['location']['lng']
        print(place_lat,place_lng)
        result = gmaps.places(place_type,location=(place_lat,place_lng),radius=1000)
        lat_list = list()
        lng_list = list()
        address_list = list()
        name_list = list()
        for i in range(len(result["results"])):
            print(result["results"][i]["geometry"]["location"]["lat"])
            lat_list.append(result["results"][i]["geometry"]["location"]["lat"])
            lng_list.append(result["results"][i]["geometry"]["location"]["lng"])
            address_list.append(result["results"][i]["formatted_address"])
            name_list.append(result["results"][i]["name"])
        place_search = {'latList': lat_list,'lngList': lng_list,'addressList': address_list,'nameList': name_list}
        return JsonResponse(place_search)
		
		#return Response(result["results"])


@api_view(('GET',))
@renderer_classes((JSONRenderer,BrowsableAPIRenderer,))
def place_info(request, format=None):
    """
    A view that accepts a location ID and returns place info via. GET call paramerter and show on Google MAP
    """
    # Query Sample : http://127.0.0.1:8000/places?place=Dearborn
    gmaps = GoogleMaps(gmap_api_key)
    place = request.GET.get('place')
    print(place)
    result = gmaps.geocode(place)
    print(result)
    place_id = result[0]["place_id"]
    place_details = gmaps.place(place_id=place_id)
    
    address = place_details["result"]["address_components"][0]
    position = place_details["result"]["geometry"]["location"]
    lat = place_details["result"]["geometry"]["location"]["lat"]
    lng = place_details["result"]["geometry"]["location"]["lng"]
    
    gmap = gmplot.GoogleMapPlotter(lat, lng,8) #, zoom, apikey)
    gmap.scatter([lat], [lng], 'cornflowerblue', edge_width=10)
    gmap.marker(lat, lng, color='#FF0000', c=None, title="Address:"+str(address)+" position: "+str(position))
    file_name = settings.BASE_DIR + "/gis/templates/place_info.html"
    gmap.draw(file_name)
    return Response(place_details)
