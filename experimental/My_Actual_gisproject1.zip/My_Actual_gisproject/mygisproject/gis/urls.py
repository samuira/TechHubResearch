from django.conf.urls import url

from gis import views
#from waypoints import myviews
'''
urlpatterns = [
    url(r'^$', views.index, name='waypoints-index'),
    url(r'^addcity$', views.addcity, name='waypoints-addcity'),
    url(r'^find_distance$', views.find_distance, name='waypoints-find_distance'),
    url(r'^upload$', views.upload, name='waypoints-upload'),
    url(r'^find_lat_long$', views.find_lat_long, name='waypoints-find_lat_long')
]
'''
urlpatterns = [
	url(r'^$', views.index, name='waypoints-index'),
	url(r'^addcity$', views.addcity, name='waypoints-addcity'),
    url(r'^search_city', views.search_city, name='waypoints-search_city'),
    url(r'^direction$', views.direction, name='waypoints-direction'),
    url(r'^places$', views.place, name='waypoints-places'),
    url(r'^place_info$', views.place_info, name='waypoints-place_info'),
    url(r'^draw_ploygon$', views.draw_ploygon, name='waypoints-draw_ploygon'),
    url(r'^show_weather$', views.show_weather, name='waypoints-show_weather')
    #url(r'^find_lat_long$', views.find_lat_long, name='waypoints-find_lat_long')
]
